using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using MediatR;
using Diten.SupplyChainService.Api.Controllers;
using Diten.SupplyChainService.Application.Common;
using Diten.SupplyChainService.Application.Features.Returns;
using Diten.SupplyChainService.Application.Features.Returns.Commands;
using Diten.SupplyChainService.Application.Features.Returns.Queries;
using Diten.SupplyChainService.Domain.Features.Returns;
using Diten.SupplyChainService.Infrastructure.Features.Returns;
namespace Diten.SupplyChainService.Api.Features.Returns;
[Authorize, Route("api/shipment-bundle/returns")]
public sealed class ReturnsController(ISender sender, ReturnRequestContext context) : CustomBaseController
{
    [HttpGet, ReturnPermission(ReturnPermissions.Read)]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] string? shipmentId, CancellationToken ct) => ReturnWireResponse(await sender.Send(new GetReturnListQuery(status is null ? null : Enum.Parse<ReturnStatus>(status), shipmentId is null ? null : Guid.Parse(shipmentId)), ct));
    [HttpPost, ReturnPermission(ReturnPermissions.Create)]
    public async Task<IActionResult> Create([FromBody] JsonElement body, CancellationToken ct) => ReturnWireResponse(await sender.Send(new CreateReturnCommand(body), ct));
    // OD-F-Q65b-1 / D186-05: no endpoint-level key; the only permission gate is the target-state key
    // (ReturnPermissions.ForTarget), checked by ReturnContextMiddleware and re-checked fail-closed by the attribute.
    [HttpPost("{returnId}/transition"), ReturnPermission]
    public async Task<IActionResult> Transition(string returnId, [FromBody] JsonElement body, CancellationToken ct) => ReturnWireResponse(await sender.Send(new TransitionReturnCommand(Guid.Parse(returnId), body), ct));
    private IActionResult ReturnWireResponse<T>(Response<T> response) => StatusCode(response.StatusCode, response.ErrorCode is null ? response.Data : ReturnContractError.Create(response.StatusCode == 500 ? "INTERNAL_ERROR" : response.ErrorCode, response.StatusCode, context.CorrelationId));
}
