using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace Diten.SupplyChainService.Infrastructure.Features.Returns;
[AttributeUsage(AttributeTargets.Method)]
public sealed class ReturnPermissionAttribute(string? permission = null) : Attribute, IAuthorizationFilter
{
    // HttpContext.Items slot where ReturnContextMiddleware puts the target-state key it verified for a transition.
    public const string TargetGrantItem = "Diten.SupplyChainService.Returns.TargetGrant";
    // null = transition endpoint: the target-state key (ReturnPermissions.ForTarget) is the only permission gate.
    public string? Permission { get; } = permission;
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // Ordered middleware supplies the published envelope before MVC executes.
        // Fail-closed: with no endpoint key, a request passes only with a target-state key the middleware verified.
        var required = Permission ?? context.HttpContext.Items[TargetGrantItem] as string;
        if (context.HttpContext.User.Identity?.IsAuthenticated != true || required is null || !context.HttpContext.User.HasClaim("permission", required))
            context.Result = new StatusCodeResult(403);
    }
}
