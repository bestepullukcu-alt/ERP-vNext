# Claims HTTP composition — separate owner gate

NOT APPLIED; NOT AUTHORIZED by consumer grant. Proposed exact Program.cs patch attached for integration-owner review against baseline SHA256 7fdb5ef0d322c3b9c814fab709dcfbaf1c9a2904f3d9a39e6f90bce077f204d8. Rebase/review explicitly if Returns owner has altered shared file first; never silently overwrite.

Adds Claims persistence/scoped context,5s HttpClient, Claims middleware after authentication, exact-family invalid-model error and exclusion from generic Shipment middleware. No worker registration. Uses existing JWT authentication/authorization. Preserve existing Carrier/Loads/Shipment and /claimsXYZ behavior. Separately supply Claims:ReferenceBaseUrl through isolated execution environment; no config file change or secret needed here. Only allow same-scope published Shipment/Carrier reference endpoints.

Program.cs is unchanged. Real application Claims HTTP/JWT smoke and actual producer→Claims uptake cannot run before this separately approved composition; do not create alternative host, fake test startup wiring, JWT bypass or claim runtime PASS. Direct handler/middleware and mocked HttpMessageHandler tests are component evidence only. Real Mongo persistence/concurrency tests proceed independently. Independent VER requires writer-complete plus approved composed source hashes.
