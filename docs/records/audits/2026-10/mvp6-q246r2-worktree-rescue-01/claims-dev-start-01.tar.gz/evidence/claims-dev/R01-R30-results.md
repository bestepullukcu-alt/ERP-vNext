# R01–R30 fresh DEV evidence boundaries

All rows PARTIAL for full runtime acceptance. Source/test method names and executed case outcomes are in test-results.tsv; prefix Claim + family + Tests identifies the owned test files. E2 component evidence and actual repository/Mongo evidence are separated below. No historical model PASS adopted.

|Row|Fresh evidence family|Remaining boundary|
|---|---|---|
|R01|Reference|8state domain execution; live reference+createHTTP missing|
|R02|Reference|Carrier mock statuses/omissions/no-match; no live upstream|
|R03|Reference/Outbox|immutable snapshot implemented; source-changebetweenreadcommit network scenario not executed|
|R04|Reference|mocktimeout404invalidJSON/rooterror cases, actualHTTP envelopes missing|
|R05|Contract|decoded evidence schema tests, fullHTTP wire not run|
|R06|Amount|realMongo -0approval/retention; authenticated end-to-end missing|
|R07|Amount/Concurrency|real20duplicatecreates; financeabsence static|
|R08|Atomicity/Replay|real17MiB driverfailure503rollback and longstring2process persistence; transportbodylimits not benchmarked|
|R09|Amount/Contract|lexical validators/amountcomparison; no fullHTTP matrix|
|R10|Replay|lexical fingerprint tests plus actual receipt root-before-payload conflicts|
|R11|Lifecycle/Permission|49pair domainoracle inclWithdrawn; handler grant tests notJWT|
|R12|Lifecycle/Permission|49pairdomainoracle inclClosed; handlergrants notJWT|
|R13|Permission|countingrepository handler self-actiongrants; real JWT/wholeactorchain missing|
|R14|Isolation|directmiddleware syntheticauthenticatedprincipal; NOT signature enforcement|
|R15|Isolation/Replay|directmiddleware precedence and actualMongo receipt precedence; end-to-end errors missing|
|R16|Replay|actualMongo originalreceipt/lostresponse/changedpayload; fullHTTPresponseheader missing|
|R17|Lifecycle|49pairdomain oracle + realMongo approve/reject race; not49HTTP cases|
|R18|Contract|wire/error code static/component tests; fullstatusHTTPmatrix not executed|
|R19|Replay|realtenant/LE/softdelete originalreceipt and noadditionalwrites; signedHTTPcontext missing|
|R20|Replay|actualchangedactor replay retains audit actor; grants are handlercomponent tests|
|R21|Reference/Replay|nil persistedroot+mocksource distinction; real publishedproducer uptake NOT demonstrated|
|R22|Concurrency|realdefinite ID/number collision503 aftersoftdelete; no renumber|
|R23|Concurrency|20differentkeys sameShipment allcommit; no aggregatecap|
|R24|Concurrency|real20samekeyrace and approve/reject CAS; networkdistribution nottested|
|R25|Atomicity|4distinctpostwrite faults + precommit rollback; realpostcommitreceipt recovery. No server-injected ambiguouscommit/no-receipt outage test; remain explicit|
|R26|Outbox|realPendingoutbox exactoccurredAt/root/causation/event fields; originaleventreplay countstable|
|R27|Outbox|no worker/publisher; Pendingdocuments; nolivefinancecalls static|
|R28|source ownership|47ownedsourcefiles; Program untouched; sharedcomposition explicitly pending|
|R29|source/build/process|freshrestore/build hashes and runner/testhostPID bindings; APIprocess/request lineage not available|
|R30|publication binding|canonical3.0.0 bytes pinned; historicalisolatedproduceracceptance not finalconsumer uptake|
