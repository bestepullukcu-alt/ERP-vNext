# R01–R30 authenticated evidence matrix

| Row | Status in this handoff | Evidence / exact remaining boundary |
|---|---|---|
| R01 | PARTIAL fresh | Delivered Shipment reference → authenticated create `201`; eight-state matrix remains inherited component evidence. |
| R02 | INHERITED | Carrier mock/status cases were not rerun over HTTP; no carrier was supplied in the fresh create. |
| R03 | PARTIAL fresh | Real Shipment snapshot was consumed; source-change-between-read-and-commit was not injected. |
| R04 | PARTIAL fresh | Real producer route and fail-closed root mismatch were observed; timeout/invalid JSON/unavailable matrix remains inherited. |
| R05 | PARTIAL fresh | Create/list/transition wire bodies were captured; full missing/null/additional-property HTTP matrix was not rerun. |
| R06 | PARTIAL fresh | Decimal `125.50 USD` crossed JWT/HTTP/persistence; all amount boundary cases remain inherited. |
| R07 | INHERITED | Real Mongo duplicate-create concurrency exists in DEV v2.0 evidence; not rerun through HTTP here. |
| R08 | INHERITED | Driver-size rollback and two-process persistence evidence unchanged; transport limit was not rerun. |
| R09 | PARTIAL fresh | Changed payload produced `409`; full lexical amount relation matrix remains inherited. |
| R10 | PASS bounded fresh | Same key/body/root replay `201`; changed body `409`; mismatched root `409` with zero writes. |
| R11 | PARTIAL fresh | Open→Investigating `200` with investigate permission; all lifecycle pairs/actions remain inherited. |
| R12 | INHERITED | Close lifecycle/action matrix not rerun over HTTP. |
| R13 | PARTIAL fresh | Real JWT signature/lifetime/issuer/audience path and read/create/investigate grants passed; missing read grant returned 403. Other action-grant negatives remain open. |
| R14 | PARTIAL fresh | Mismatched tenant header returned 403; full 2-tenant × 2-LE matrix was not rerun. |
| R15 | PASS bounded fresh | Header/root enforcement failed closed; correlation mismatch body and zero-write state preserved. |
| R16 | PASS bounded fresh | Original create replay returned 201/same claim; restart replay made no additional writes. |
| R17 | INHERITED | Full lifecycle/concurrent approve-reject evidence remains component/Mongo evidence. |
| R18 | PARTIAL fresh | Actual 200/201/403/409 responses captured; complete operation error matrix not rerun. |
| R19 | PASS bounded fresh | Tenant/LE-scoped collection state persisted; restart replay left all four counts unchanged. |
| R20 | PARTIAL fresh | Audit rows retained the signed actor; changed-actor replay behavior remains inherited. |
| R21 | PASS bounded fresh | Real composed Shipment detail returned persisted authoritative root; Claims used it. No stub. |
| R22 | INHERITED | Claim ID/number collision behavior not rerun through HTTP. |
| R23 | INHERITED | Different-key same-Shipment concurrency not rerun through HTTP. |
| R24 | INHERITED | Same-key race/CAS concurrency not rerun through HTTP. |
| R25 | INHERITED | Transaction failpoints/unknown-commit evidence unchanged; no fresh server failpoint run. |
| R26 | PASS bounded fresh | Create+transition yielded exactly two scoped receipts/audits and two Pending outbox rows; replay/restart counts stable. |
| R27 | PASS bounded fresh | Outbox stayed Pending; no publisher/worker or finance call was introduced. |
| R28 | PASS scope | Claims 47-file manifest is unchanged and verifies; this lane made no product/shared edits. Concurrent Program drift is separately blocked. |
| R29 | BLOCKED | Authenticated binary/process behavior is fresh, but current-source fresh build fails because Program.cs references absent Returns sources. Existing binary provenance is inherited/content-bound, not relabeled fresh. |
| R30 | PARTIAL | Real accepted Shipment producer code path is exercised; publication/consumer rollout and final current-source build binding remain separate gates. |
