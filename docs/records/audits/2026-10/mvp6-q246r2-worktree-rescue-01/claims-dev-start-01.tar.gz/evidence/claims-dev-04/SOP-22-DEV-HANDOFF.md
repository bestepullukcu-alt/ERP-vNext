# MVP6-MOD0187-AUTHENTICATED-EVIDENCE-04 — SOP §22 DEV handoff

## Verdict

**PARTIAL / REWORK REQUIRED.** The bounded authenticated Claims behavior and real Shipment producer uptake were reproduced in the isolated environment. Current-source fresh-build provenance is blocked by a concurrent shared-composition drift: `Program.cs` changed from the approved Claims target `a28cb1ab5b7dc235cb68bb0bf7ad72cdc4889a49846ab6fdd4f01601285ab34a` to `a72a05a5e185e04d70ba221f086baacb8c8fca11ea061f289cb4b54fd430254c`, while the Claims worktree contains zero Returns source files. The fresh build therefore fails with four CS0234 errors for the Returns namespaces. This lane did not edit or restore `Program.cs`, import Returns, or fall back silently.

## Exact environment and provenance

- Worktree: `/Users/natig/.codex/worktrees/claims-dev-start-01/ERP-vNext-recovery`
- Branch: `codex/mod-0187-claims-dev-start-01`; HEAD `4a8d4d4b339528a88e6220fb8402e5a2c771136c`.
- Initial composition check and runtime launch: approved `Program.cs` SHA-256 `a28cb1ab5b7dc235cb68bb0bf7ad72cdc4889a49846ab6fdd4f01601285ab34a`.
- Executed API binary: `services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll`, SHA-256 `6784cbdfbfa728626abc759650d245c7c0d0986294c164186129404871313527`.
- That binary is content-bound by the earlier `evidence/claims-dev-02/binary-manifest.sha256` and its DEV handoff, which records a successful build against the approved target. This run did not reproduce that build after the shared drift.
- Current 47-file Claims source/test manifest: `evidence/claims-dev/source-test-manifest.sha256`; fresh check exit 0, all entries OK.
- Mongo: lane-owned replica set `claims_auth04`, `127.0.0.1:27889`, PRIMARY, database `diten_claims_auth04`. Operational 27017 was not used.
- API: `http://127.0.0.1:5063`, .NET 8 `/Users/natig/.dotnet/dotnet`.
- JWT: ephemeral HS256 key, issuer and audience; exact `sub`, `tenant_id`, `legal_entity_id`, `actor_type` and permission claims. Secret and bearer values are absent from the package.

## Fresh authenticated evidence

`raw/runtime.json` is PASS:

- authorized Claims list `200`;
- token without `supplychain.claims.read` `403 FORBIDDEN`;
- signed token with a mismatched tenant header `403 FORBIDDEN`;
- real composed Shipment detail endpoint `200`, with exact shipment ID and persisted lifecycle root;
- create `201`, same-key/same-body/same-root replay `201`, changed-body conflict `409`, Open→Investigating transition `200`, final list `200`;
- scoped Mongo state: one claim, two receipts, two audit rows, two Pending outbox rows.

`raw/failed-correlation.json` preserves the first fail-closed attempt: a valid JWT with a correlation different from the authoritative persisted root produced `409 CLAIM_CORRELATION_MISMATCH` and zero Claims writes. The harness was then corrected to send the approved same root; no product or auth policy was changed.

`raw/restart.json` is PASS after stopping and restarting the same binary against the same database and fixture. A newly issued short-lived token with the same actor/scope produced Shipment detail `200`, Claims list `200`, replay `201`, the same claim identity, and identical before/after collection counts. `raw/db-state.json` confirms Version 2 / Investigating, both durable receipts, two actor-bound audit rows, and two Pending outbox rows.

## Real producer uptake

The Shipment fixture was written directly to the isolated `sce_shipments` collection using the accepted producer document shape. The request path was the real controller route `/api/shipment-bundle/shipments/{shipmentId}` inside the composed API. The response in `runtime.json` contains the exact authoritative persisted `lifecycleCorrelationId`; Claims create subsequently called that same route with forwarded bearer and tenant/LE/correlation scope. No stub response or fixture endpoint was used.

## Build and drift finding

The fresh command recorded in `raw/fresh-build.txt` exited 1. Its only compiler failures are the missing Returns API/Application/Persistence/Infrastructure namespaces referenced by the new shared composition. `raw/program-drift.patch` records the current shared diff. The binary remained byte-identical at `6784cbdf...`; it was not rebuilt or relabeled fresh.

Exact rework owner: the single integration owner must reconcile the current Program.cs composition with an authorized, complete source set, or restore the exact approved Claims composition target. Claims consumer writers have no authority to choose or import Returns sources. After that disposition, rerun fresh build → binary hash → process/port → authenticated HTTP/DB/restart with the existing evidence harness.

## Scope and changes

Product/runtime source changes by this lane: **none**. `root_uptake/runtime_probe.py`, Program.cs, auth policy, Returns, canonical contracts, guard, gateway and operational data were not changed. New output is evidence only under `evidence/claims-dev-04/`.

## Cleanup

Both API sessions stopped. Lane Mongo 27889 received shutdown; the shell reports the expected connection-close response. Final checks found no listener on 5063 or 27889 and no matching API/mongod process. The ephemeral secret file was removed after packaging and was never archived.

## Remaining gates

- Current-source fresh build/process provenance: **OPEN — exact integration-owner blocker above**.
- Full R01–R30 runtime closure: **OPEN/PARTIAL** as listed in `acceptance-matrix.md`; this run closes the prior JWT credential/environment blocker and proves the listed HTTP rows, but it does not turn inherited component/concurrency/failpoint evidence into fresh HTTP evidence.
- Independent VER: required after integration rework and fresh provenance rerun.
- CT acceptance, canonical publication disposition, rollout, E5/G5 and full-module acceptance: not claimed.

Writer complete: **yes**. No source writer remains from this lane.
