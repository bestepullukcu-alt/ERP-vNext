# MVP6-MOD0187-RUNTIME-ENV-AND-EVIDENCE-03 — SOP §22

Verdict: **PARTIAL — composed process and isolated DB startup verified; full authenticated HTTP/producer evidence remains OPEN.**

## Source/build chain

Registered worktree: `/Users/natig/.codex/worktrees/claims-dev-start-01/ERP-vNext-recovery`.
Program.cs SHA256: `a28cb1ab5b7dc235cb68bb0bf7ad72cdc4889a49846ab6fdd4f01601285ab34a`.
API binary: `services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll`; binary SHA256 is in `binary-manifest.sha256`.
Build completed with 0 warnings and 0 errors.

## Isolated environment

- MongoDB replica set: `claims_dev02`, `127.0.0.1:27888`, state PRIMARY (`rs.status().myState = 1`). Operational 27017 was not used.
- Database: `diten_claims_dev03`.
- API: isolated `127.0.0.1:5062`, .NET 8 runtime `/Users/natig/.dotnet/dotnet`.
- JWT issuer/audience/key were ephemeral environment values; no token or secret was written to evidence.
- Processes were stopped after capture.

## Fresh HTTP evidence

- `GET /health` returned 200 from the composed binary.
- Claims request without bearer returned 401 `UNAUTHENTICATED`, `WWW-Authenticate: Bearer`, and preserved correlation `33333333-3333-4333-8333-333333333333`.
- This confirms real middleware composition and fail-closed authentication, but not authenticated JWT/RBAC success.

## Remaining OPEN criteria

R01–R30 authenticated create/list/transition, tenant/LE/RBAC positive and negative cases, producer Shipment root uptake, persistence/concurrency/failure recovery, and API restart remain OPEN. A valid actor-scoped test JWT and an accepted Shipment producer fixture/process were not available in this lane; no bypass or synthetic authorization was used. Claims reference base URL was pointed at the isolated API, but no producer fixture was seeded, so producer uptake is not claimed.

Existing model/Mongo evidence is inherited and remains clearly separate from fresh HTTP evidence. Independent VER must follow only after the missing JWT and producer inputs are provisioned.
