# Returns test-author handoff — internal DEV evidence

Writer complete: 7 authorized xUnit files + 3 authorized Python probes. No product/shared/Program.cs changes by this writer.

Final build: 0 warnings / 0 errors. Final source-bound suite: **68 passed, 0 failed, 0 skipped**. `release-target` binds 46 exact source hashes, command/exit, test binary, actual testhost process and measured five-collection counts/write stages. All 46 hashes rechecked with no drift after execution.

Test binary SHA256: `3232397c517d51f72ee40ce01e6c5efea711eaa61ef6035ee0a6bf217f2ac2d7`.

Two-process restart: `release-restart/seed` actual testhost PID48808 and `release-restart/read` PID48813; same binary; 1/1 test each. Persisted receipt/root and original 50-digit fractional quantity survive; source mock deliberately unavailable during replay. This is repository-process restart, not API server/HTTP/JWT evidence.

Covered: all64 source-target pairs/seven legal arrows, numeric quantity/instant fingerprints, Gregorian/leap/fraction edges, local rejection before source, root/ref parsing and mock GET scope, middleware already-authenticated unit matrix, actual scoped Mongo isolation/soft delete, 20 same-key concurrency, 6+6 and4+6 cap races, exactly-once release, closed retention, first snapshot drift including case-insensitive collection override, five separate reached write-stage faults/all-five rollback, postcommit loss, unresolved unknown commit503 then same-key recovery, three-number-collision bound, manualReceived audit/opaque reference/Pending events, rawCreate UUID spelling/omission preservation.

Databases: fixed `diten_returns_tests` and database-wide collation case `diten_returns_collation_tests`, per-test fresh tenant; dedicated Mongo127.0.0.1:27886 replica set returns_dev. Operational27017 untouched. No Inventory/Warehouse HTTP or source writes.

Historical intermediate runs are retained separately: initial test syntax correction;44/45 infrastructure failpoint disabled;58/60 incorrect immediate-recovery and observation-count oracles;59/60 unsupported sticky aggregate-reference oracle corrected to immutable Received audit. Pre-product-fix62/62 is not final acceptance. Current68/68 reflects raw audit/collation fixes.

Limits: mock reference and fabricated authenticated principal are not real producer/JWT uptake. No HTTP host or composition bypass was built. Program.cs remains integration-owner dependency. This writer is test author, not independent VER; CT/deployment/full-module acceptance not asserted.
