# Returns HTTP composition handoff — proposed, not applied

Integration owner owns the sole shared source change: `services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/Program.cs`.
The Returns core lane does not change this file or authorize HTTP composition. No worker is required or allowed.

## Exact integration delta

1. Add using directives for `Api.Features.Returns`, `Application.Features.Returns`, `Infrastructure.Features.Returns`, and `Persistence.Features.Returns`.
2. Register `AddScoped<ReturnRequestContext>()` (the existing AddApplication assembly scans handlers/validators but does not register this context).
3. Register `AddReturnPersistence()` using its actual registration signature, sharing the existing Mongo client/database and serializer setup.
4. Register `AddHttpClient<IReturnReferenceReader, ReturnReferenceReader>(client => client.Timeout = TimeSpan.FromSeconds(5))`. Supply `Returns:ReferenceBaseUrl` through separately authorized deployment configuration. It points to the Shipment producer; it grants no Inventory/Warehouse access.
5. In `InvalidModelStateResponseFactory`, before Shipment fallback, add an `IsReturnPath` branch producing 400 `ReturnContractError.Create("INVALID_REQUEST", 400, requestServices.GetRequiredService<ReturnRequestContext>().CorrelationId)`.
6. After `UseAuthentication` and before `UseAuthorization`, install `UseWhen(ReturnContextMiddleware.IsReturnPath, branch => branch.UseMiddleware<ReturnContextMiddleware>())`.
7. Add `!ReturnContextMiddleware.IsReturnPath(context)` to the ShipmentContextMiddleware predicate. Preserve existing Carriers/Loads and any independently approved Claims composition in the integration owner's current baseline.

No hosted Returns publisher, worker, new route, financial/stock handler, shared policy change, or alternate testhost bypass.

## Required HTTP verification after approved composition

Actual JWT parser failures must yield 401; accepted authentication with unusable/duplicate trusted context must yield 403 (duplicate-sub parser rejection can remain401). Exact header precedence, scope mismatch404, ordinary unknown query acceptance, six once-decoded ASCII scope aliases400, required/null/body/media and per-target grants must execute through Kestrel/JWT/MVC. Verify rejection-only fallback correlation versus preserved authoritative root, receipt replay/root-before-fingerprint, and no writes on rejection. A typed HttpClient mocked handler or DefaultHttpContext unit is not this evidence.

## This lane's build

Fresh API restore with .NET8 and existing references: exit0. API build: exit0; initial CS0108 helper warning corrected by renaming to ReturnWireResponse. Parent final build/test run binds final source bytes. No actual HTTP/JWT enforcement has been claimed.
