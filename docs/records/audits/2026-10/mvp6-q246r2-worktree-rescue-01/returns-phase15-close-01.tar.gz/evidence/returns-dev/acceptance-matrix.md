# R01–R11: evidence boundary

All final test cases and exact names are in `release-target/returns.trx`; executed source/binary/process binding is in `fresh-source-build-binding.json`, `release-target/execution.json`, and `repository-process.jsonl`. This is DEV evidence, not independent acceptance.

| Criterion | Fresh evidence | Remaining boundary |
|---|---|---|
| R01 | ReturnReferenceTests: required vs decision omission, root missing/null/malformed/nil, duplicate/nonpositive lines; mocked transport checks trusted scope and Shipment-only GET | Real published producer transport/authorization and full malformed-response HTTP matrix await integration |
| R02 | Actual Mongo 6+6 and 4+6 races, multi-line rollback, ordinal entitlement under case-insensitive collection default, snapshot drift | No distributed Shipment transaction is claimed |
| R03 | Actual release/replay/different-key rejection; Closed retains cap; scope/soft-delete tests | Full integrated API matrix remains VER work |
| R04 | Exact arbitrary-precision arithmetic/fingerprint, raw lexical create audit, numeric-equivalent snapshot; long decimal retained across two processes | No decimal/precision business limit introduced |
| R05 | Actual Received immutable audit has manual-assertion, actor/raw time/opaque reference; target grant mapping tested in preauthenticated middleware unit | Actual JWT/HTTP grant enforcement pending |
| R06 | Opaque nullable command handling; no Inventory/Warehouse client path; Shipment-only mocked transport; disposition/lifecycle tests | No physical Warehouse receipt or stock claim |
| R07 | 64 source×target pairs checked against seven arrows through actual repository/Mongo; InTransit→Cancelled rejects | HTTP translation separately verified after composition |
| R08 | Preauthenticated DefaultHttpContext cases, exact permission mapping, root-before-fingerprint Mongo tests | Authentication parser and real Kestrel/JWT are NOT executed |
| R09 | Scoped original result replay after state/deletion, same key across scope; genuine unknown-commit failpoint and postcommit loss; two-process restart | API process restart/HTTP evidence pending |
| R10 | Five actual sequential write-stage faults, reached-stage trace and five collection rollback counts; Pending events; snapshot drift | Model PASS not used as Mongo evidence; no worker/publisher |
| R11 | Fresh restore/rebuild, 46 source hashes, same executed binary, actual testhost PID records; two non-Returns regressions | No Returns request/status/header capture until approved HTTP composition |

No R12 row exists in the controlling pack table. No full-module/E5/G5/rollout acceptance is implied.
