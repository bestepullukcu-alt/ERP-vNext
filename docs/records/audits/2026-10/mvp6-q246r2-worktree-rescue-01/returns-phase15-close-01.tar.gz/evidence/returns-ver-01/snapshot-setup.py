import pathlib,subprocess,tempfile,hashlib,json,shutil,tarfile,io
src=pathlib.Path('/Users/natig/.codex/worktrees/returns-phase15-close-01/ERP-vNext-recovery'); out=pathlib.Path(tempfile.mkdtemp(prefix='mvp6-returns-core-ver-',dir='/private/tmp')); snap=out/'snapshot';snap.mkdir();ev=out/'evidence';ev.mkdir();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();phase='docs/records/audits/2026-09/mvp6-mod0186-phase15-close-01/'
for cmd in [['git','status','--porcelain=v1','--untracked-files=all'],['git','rev-parse','HEAD'],['git','branch','--show-current'],['git','worktree','list','--porcelain'],['git','diff','--cached','--name-only']]:
 (ev/('preflight-'+cmd[1]+'.txt')).write_bytes(subprocess.check_output(cmd,cwd=src))
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD'],cwd=src))) as t:t.extractall(snap)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=src).decode().split('\0');selected=[p for p in paths if p and (p.startswith(('services/','tests/','building-blocks/','Building.Blocks/','.antigravity/','execution/','docs/analysis/contracts/',phase,'evidence/returns-dev/')) or '/' not in p)]
for line in (src/phase/'input-manifest.tsv').read_text().splitlines()[1:]:selected.append(line.split('\t')[0])
manifest={}
for p in sorted(set(selected)):
 f=src/p
 if f.is_file():
  manifest[p]=h(f); d=snap/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,d);assert h(d)==manifest[p]
(ev/'snapshot-manifest.json').write_text(json.dumps(manifest,indent=2));(out/'source.txt').write_text(str(src));(out/'phase.txt').write_text(phase)
rows=[l.split('\t') for l in (src/'evidence/returns-dev/source-manifest.tsv').read_text().splitlines()[1:]];assert len(rows)==46
for p,v in rows:assert h(snap/p)==v
assert h(src/'evidence/returns-dev/returns-core.patch')=='3bb73a8cd77071c0c63721e53f54e9792d155924e8c38ea41e233df78b223a98'
patchcopy=out/'patch-copy';patchcopy.mkdir();r=subprocess.run(['patch','-p1','--batch','-i',str(src/'evidence/returns-dev/returns-core.patch')],cwd=patchcopy,capture_output=True);(ev/'patch-apply.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
for p,v in rows:assert h(patchcopy/p)==v
(ev/'scope-check.json').write_text(json.dumps({'owned':len(rows),'patchApplied':True,'patchOutputsMatch':True,'workerAbsent':not any('Worker' in p for p,v in rows)},indent=2));print(out)
