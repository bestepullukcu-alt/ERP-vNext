import pathlib,os,subprocess,json,time,hashlib,socket
root=pathlib.Path(__file__).parent; snap=root/'snapshot';ev=root/'evidence';env=dict(os.environ,DOTNET_ROOT='/Users/natig/.dotnet',DOTNET_ROOT_ARM64='/Users/natig/.dotnet',PATH='/Users/natig/.dotnet:'+os.environ['PATH'],RETURNS_MONGO_URI='mongodb://127.0.0.1:27889/?replicaSet=returns_ver',MOD0185_TEST_MONGO='mongodb://127.0.0.1:27889/?replicaSet=returns_ver')
records=[]
def run(name,args,cwd=snap):
 start=time.time()
 with (ev/(name+'.log')).open('w') as f:r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,args=args,exit=r.returncode,start=start,end=time.time()));(ev/'commands.json').write_text(json.dumps(records,indent=2)); print(name,r.returncode,flush=True);return r.returncode
s=socket.socket();s.bind(('127.0.0.1',27889));s.close();(root/'mongo').mkdir();assert run('mongo-start',['/opt/homebrew/bin/mongod','--dbpath',str(root/'mongo'),'--port','27889','--bind_ip','127.0.0.1','--replSet','returns_ver','--setParameter','enableTestCommands=1','--fork','--logpath',str(ev/'mongod.log')])==0
assert run('mongo-init',['/opt/homebrew/bin/mongosh','mongodb://127.0.0.1:27889/?directConnection=true','--quiet','--eval','rs.initiate({_id:"returns_ver",members:[{_id:0,host:"127.0.0.1:27889"}]}); while(!db.hello().isWritablePrimary){sleep(100)}'])==0
project='services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj'
assert run('restore',['dotnet','restore',project])==0
assert run('build',['dotnet','build',project,'--no-restore','-t:Rebuild'])==0
bins={str(p.relative_to(snap)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (snap/'services/Diten.SupplyChainService').rglob('bin/Debug/net8.0/Diten.*.dll')};(ev/'fresh-binary-manifest.json').write_text(json.dumps(bins,indent=2))
run('core',['python3','services/Diten.SupplyChainService/tests/returns/runtime_probe.py','--output',str(ev/'core')])
run('restart',['python3','services/Diten.SupplyChainService/tests/returns/restart_probe.py','--output',str(ev/'restart')])
run('loads',['dotnet','test',project,'--no-build','--no-restore','--filter','FullyQualifiedName~Loads.LoadContractTests.FrozenThreeOperationWireAndSuccessfulCreateList|FullyQualifiedName~Loads.LoadContractTests.SchemaUnknownFieldsAndNoExtraRoutesAreRejected','--logger','trx;LogFileName=loads.trx','--results-directory',str(ev/'loads')])
run('architecture',['dotnet','test','tests/architecture/TenantArchitecture.ArchitectureTests','--filter','FullyQualifiedName~MongoTestDatabaseGuardTests','--logger','trx;LogFileName=architecture.trx','--results-directory',str(ev/'architecture')])
run('mongo-index',['/opt/homebrew/bin/mongosh','mongodb://127.0.0.1:27889/?replicaSet=returns_ver','--quiet','--eval','db=db.getSiblingDB("diten_returns_tests"); for(const c of ["returns","return_entitlements","returns_receipts","returns_audit","returns_outbox"]){print(c);printjson(db.getCollection(c).getIndexes())}'])
run('mongo-shutdown',['/opt/homebrew/bin/mongosh','mongodb://127.0.0.1:27889/?directConnection=true','--quiet','--eval','db.getSiblingDB("admin").shutdownServer()'])
