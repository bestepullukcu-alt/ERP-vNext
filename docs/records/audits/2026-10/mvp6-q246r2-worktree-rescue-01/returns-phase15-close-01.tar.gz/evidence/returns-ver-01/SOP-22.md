# MVP6-MOD0186-CORE-VER-01 — Independent SOP §22

Agent Verdict: **PASS — exact scoped Returns core verification. Repository architecture gate remains FAIL; HTTP/full-module acceptance not assessed.** Independent verifier did not author or modify the Returns core. Applied CORE-VER-v2.1 only; no new business or runtime scope.

Branch / HEAD: `codex/mod-0186-phase15-core-dev-01` / `4a8d4d4b339528a88e6220fb8402e5a2c771136c`.
Source registered worktree: `/Users/natig/.codex/worktrees/returns-phase15-close-01/ERP-vNext-recovery`.
Disposable snapshot: `/private/tmp/mvp6-returns-core-ver-jj3j9u_t/snapshot`, filesystem snapshot, **not a registered worktree**. No .git copied or invented. 7,985 inspected inputs hash-bound in snapshot-manifest.json. HEAD archive plus current tracked/untracked overlays; 413 historical transfer rows checked, sole expected delta is approved/promoted pack (07a8… to1c80…). No integration lane mutable source used for execution.

## Authority and exact scope

Actual user records verified in JSONL source cited in input-authority.md: line6279 timestamp2026-09-20T11:44:45.025Z conditional isolated pack/runtime grant; line6779 timestamp2026-09-21T06:36:51.262Z exact replacement grant and46effective paths/no worker. Original role:user records retained actual-authority.json. Historical drafts were not substituted. Writer complete confirmed DEV SOP/TEST-AUTHOR-HANDOFF. Promoted pack SHA256 `1c80cca70ef774d18f5d30174566e68c9b6332b61dd1f564d54de3429886482f` verified. Published contract/annex pinned via input-DEV-v2.0.md and snapshot manifest. No new approval issued.

Exact source patch `3bb73a8cd77071c0c63721e53f54e9792d155924e8c38ea41e233df78b223a98` independently applied with patch -p1 to empty disposable tree; all46 outputs match source manifest. Input handoff archive `2cdbd60a35e6602b540f8ead8b60dbb48c2f2343ae675d3ed4c1a3469207b66f` and all ARTIFACTS.sha256 entries match. 201archive members independently inventoried. Input source patch has no worker/shared/Program changes.

## Fresh source → build → binary → execution

Fresh restore exit0; Rebuild exit0, zero warnings/errors. Commands/exit/timestamps retained commands.json; restore.log/build.log. Fresh binary SHA256 **adcdc7cb59736b751de05db7c0441adb5a0b6cb4d685eee9f8fff427161d7b59**. Different absolute build path can change binary/PDB identity; no claim to reproduce DEV binary hash. Fresh binary is pinned across core and both restart processes; testhost records include actual loaded assembly hash/process command. See binding.json and fresh-binary-manifest.json.

| Executed scope | Fresh result | Counting boundary |
|---|---|---|
| Returns namespace suite |68 passed,0failed,0skipped|68 test results, including parameter cases|
| Separate-process restart seed/read |1pass +1pass; PIDs51802/51807|Same RestartReceipt case already in68; extra process/persistence evidence, not70unique core tests|
| Existing Loads two exact regressions |2passed|Separate module regression scope, not Returns acceptance|
| Five MongoTestDatabaseGuardTests |4pass/1fail|First selected guard class|
| MongoClientInstantiation exact selected guard |1pass|Sixth historical selected case; total selected architecture5pass/1fail|

No historical run presented as fresh. Full command/TRX/raw process output retained; source tests unchanged. Unknown-commit case ran87.6seconds and passed real Mongo failCommand commitTransaction scenario: unresolved503 then same-key recovery with one persisted result. Its raw stage/count records and assertion source are retained; unknown outcome is not called guaranteed rollback. Initial verifier harness preparation issues (Python3.9 tar filter incompatibility; occupied27888) occurred before source test execution and were corrected only in verifier tooling; occupied process untouched. Own Mongo used27889/returns_ver with enableTestCommands, fixed diten_returns_tests/diten_returns_collation_tests, fresh tenant IDs. Operational27017 untouched.

## Golden/contract flow, sub-flows and failure evidence

Source inspection and unchanged executable tests cover inherited Shipment root; numeric exact quantity/instant fingerprint; first raw audit preservation; receipt root-before-payload precedence/original result; all64source-target pairs/seven canonical arrows with InTransit→Cancelled rejected; immutable source snapshot and drift; ordinal entitlement under case-insensitive collection default; cap6+6/4+6 races and20same-key concurrency; exactly-once release; Closed/softdeleted cap retention; manualReceived and Pending outbox. See verified-source tests and core/returns.trx.

Five separate real transaction write stages (entitlement,aggregate,receipt,audit,outbox) reached/asserted distinctly; every precommit fault checks all five scoped collections rolled back, then retry succeeds. Multiline failure, postcommit loss receipt recovery and unknown-commit recovery executed. No worker/publisher/Inventory/Warehouse call added. Source reader transport test verifies only mocked Shipment GET; static code bounds support zero Inventory/Warehouse calls. This is not live producer uptake.

Persistence evidence: actual isolated replica-set transactions, tenant/LE scope, indexes, concurrency, rollback and restart. mongo-index.log records physical indexes; repository-process.jsonl records stage/counts and process binding. Own Mongo cleanly stopped: shutdown client exit1 due connection close, independently verified ECONNREFUSED61 and no matching process; mongo-stop-check.txt. No migration/backfill/data rollout.

Security/RBAC/Tenant evidence: actual scoped repository isolation, hidden softdeleted aggregate with retained receipt; middleware tests use fabricated already-authenticated principal. **No actual HTTP/JWT parser validation, Program composition, producer uptake, deployment or full-module acceptance claimed.**

## Existing architecture finding — no waiver

`tests/architecture/TenantArchitecture.ArchitectureTests/MongoTestDatabaseGuardTests.cs:126` fails NoTestCreatesItsOwnDatabasePerRun on two existing Platform files, exactly as historical raw log:

- `services/Diten.Platform/tests/Diten.Platform.Application.Tests/Persistence/DisposableStandaloneMongo.cs:25`: per-run GUID database name. SHA2560fb06a1d020ada8deaaaf0d702fe2007ac89d2104e585d1f2bca3868c9cb00ef.
- `services/Diten.Platform/tests/Diten.Platform.Application.Tests/Audit/PpmAuditRetentionPolicySeedMongoTests.cs:79`: per-run GUID database name. SHA256c22f0cdab58c2b229fa529c1cdb466d876a99a68abb1cae40952a8f1d4acbc46.

Both exact bytes equal HEAD (platform-baseline.json). Attribution is source comparison, not a separate HEAD execution. Existing out-of-scope DB-010 violation; scoped Returns verification not a waiver. Historical summary mentioned onlyfirstfile; raw history and freshresult showboth. No exceptions/guards/source changed; repository-wide PASS unavailable.

Audit/Evidence/Observability: actual original raw audit, manualReceived evidence and five collection observations; no live HTTP observability assertion. Evidence archives contain source/test/hash binding and raw execution, not synthetic acceptance.

Changed files: only this new evidence directory/archive; no product/test/pack/Program/canonical/guard/git modification. no-change.json proves all7,985 inspectedsource+snapshotbytes stable,46owned stable, branch/HEAD/staged/status identical before evidence delivery. Shared concurrent lane changes outside inspected manifest are not covered by a global repository-byte claim. Evidence directory addition is intentional authorized output.

Decisions: existing grants consumed; no new owner default/waiver/promotion/publication/runtime approval. Rollback: no product mutation to roll back; verifier-owned Mongo stopped. Blockers within exact core scope: none newly found. Known remaining gates: separately authorized HTTP composition/JWT/live producer uptake/integration verification and CT/full-module/deployment disposition. Selected repository architecture remains failed as above. Independent core PASS cannot close them.
