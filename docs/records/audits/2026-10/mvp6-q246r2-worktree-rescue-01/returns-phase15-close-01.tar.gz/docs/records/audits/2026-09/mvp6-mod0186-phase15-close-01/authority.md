# Existing actual user grants (extracts, not new approvals)

Source /Users/natig/.codex/sessions/2026/09/18/rollout-2026-09-18T15-08-33-01a0a663-9b56-7721-94a9-da2d2f124c2a_01a0b3fd-3f99-7020-aa58-6a2f484e8677.jsonl:6279; timestamp 2026-09-20T11:44:45.025Z; message SHA256 f81370463271a14208232a420c74c121e1e52f67bbe587bbb67864f0296241ee

MOD-0186 proposed pack patch:
731622d2e6104ebd1e161082481860a9ea45ea0d39b25ef06bb226c4dbf2ab7d

MOD-0187 proposed pack patch:
afe36ff9123088593ec920191657176e5343270655b7b0a2be4106bc05820187

Bu exact delta'ları ve bağlı belgelerde tanımlanan izole runtime
kapsamını onaylıyorum.

Gerekli canonical publication/guard işlemleri ayrı gerçek yetkileriyle
tamamlanıp contract hedefi doğrulandıktan sonra:

- pack delta'ları uygulansın;
- Phase 1.5 koşulları kanıtla kontrol edilsin;
- koşullar sağlanırsa pack'ler ready-for-dev yapılsın;
- HELD promptların yerine versioned DEV/VER dispatch'leri çıkarılsın;
- Returns ve Claims ayrı checkout ve ayrık owned path'lerde
  paralel izole geliştirilsin.

Program.cs/shared composition consumer writer'larına kapalıdır.
Integration owner yalnız ayrıca onaylanmış exact composition diff'ini
uygulayabilir. Bu onay bilinmeyen shared-file değişikliklerini kapsamaz.

Eksik koşullar tamamlanmış sayılmasın.
Operasyonel rollout, migration/backfill, E5/G5, full-module kabulü,
commit veya push yetkisi vermiyorum.


Source /Users/natig/.codex/sessions/2026/09/18/rollout-2026-09-18T15-08-33-01a0a663-9b56-7721-94a9-da2d2f124c2a_01a0b3fd-3f99-7020-aa58-6a2f484e8677.jsonl:6779; timestamp 2026-09-21T06:36:51.262Z; message SHA256 7490182be0fc6ffb5003a8c9dab28a5fc6cf0b63f78e9b4f571f53d5d38839b5

1. Claims HTTP composition

Program.cs baseline:
7fdb5ef0d322c3b9c814fab709dcfbaf1c9a2904f3d9a39e6f90bce077f204d8

Patch:
2ff9625201dae4c2a6f8f1fd75e00bc76bea95b7d2ade008bbf20c5346ddd1f7

Beklenen target:
a28cb1ab5b7dc235cb68bb0bf7ad72cdc4889a49846ab6fdd4f01601285ab34a

Bu exact Program.cs diff'inin kayıtlı Claims worktree'ında,
yalnız tek integration owner tarafından uygulanmasını onaylıyorum.
Mevcut Claims runtime yetkisi kapsamında HTTP/JWT, producer uptake
ve ilgili regresyon kanıtları tamamlanabilir; ardından bağımsız VER yapılır.
Başka shared dosya veya kapsam genişletme yetkisi vermiyorum.

2. Returns artifact replacement

Baseline pack:
07a8a0159b5ab02fecc7b1aa6314106d81b1584150169f457cb9a395614a04b7

Replacement patch:
2a1843eb52b8fd0b61a553c06a75d07b32dda57bf020734d946c004b82893709

Beklenen target:
745e9cc74abf8791d5fd9f96086ae8a721bfe041b6a4168353af059c6d34fc54

Eski pseudo-patch yerine bu exact unified patch'in kullanılmasını
ve izole Returns checkout'ına uygulanmasını onaylıyorum.
Önceki koşullu pack/Phase 1.5/izole runtime onayım korunur.
46 efektif owned path ve worker yok sınırı geçerlidir.
Phase 1.5 teknik koşulları doğrulanmadan promotion veya DEV GO verilmesin.
Program.cs değişikliği bu karara dahil değildir.

İki karar da commit/push, migration/backfill, operasyonel rollout,
E5/G5 veya full-module acceptance yetkisi vermez.

