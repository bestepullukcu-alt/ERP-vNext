# Physical design bound to published Returns policy — no new business decisions

ReturnOrder : existing Domain/Common/EntityBase (Id/_id,TenantId,IsDeleted,DeletedAt,CreatedAt,UpdatedAt,Version); module LegalEntityId,CreatedBy,UpdatedBy,RmaNumber,ShipmentId,ReasonCode,Lines,EvidenceReferenceIds,Status,CorrelationRoot,LastEventId,InventoryTransactionReferenceId,DispositionCode. Command occurredAt and raw optional fields retain immutable audit; no public Version/Tenant input. ReturnLine: ShipmentLineNumber,Quantity(originalstring),UomId. No extra ID for line. ReturnSourceSnapshot: ShipmentId,Status,Root,ObservedAt, source lines (LineNumber,Quantity,UomId,ItemId,SkuId); evidence of observation only, not Shipment master.

ReturnEntitlement document: _id, TenantId,LegalEntityId,ShipmentId,LineNumber,SourceQuantity(originaltext),UomId,ItemId,SkuId,UsedQuantity(exactcanonicaldecimalstring),Version. No stock/location dimensions. First insert freezes sourcefields. Ordinal UoM/line; UUIDvalue item/sku; exactnumeric quantity compare; drift409. Read source outside local transaction, then compare/debit every selected entitlement atomically. Concurrent first insert unique-conflict retry rechecks stored snapshot/cap. Transitions/replay do not reread. Rejected/Cancelled release exact lines once under aggregateCAS; Closed/soft-delete neverrelease.

|Collection|Index name|Physical ascending fields|Constraint|
|---|---|---|---|
|returns|return_number|TenantId,LegalEntityId,RmaNumber|unique,full,no softdeletepartial|
|return_entitlements|return_entitlement|TenantId,LegalEntityId,ShipmentId,LineNumber|unique; UomId excluded|
|returns_receipts|return_receipt|TenantId,LegalEntityId,Operation,TargetId,IdempotencyKey|unique,noTTL; actor/root notkey|
|returns_outbox|return_event|TenantId,LegalEntityId,EventId|unique|
|all5 collections|return_scope|TenantId,LegalEntityId|nonunique scoped access|

Simple ordinal collation; existing shared AddPersistence registers Guid/DateTimeOffset BSONstrings, enumstrings. No serializer modification. Existing MongoClient/IMongoDatabase reused. Operation createReturn/transitionReturn, TargetId literalcreate or UUID-D, no actor in key. Normal aggregates IsDeleted=false; historicalreceipt scoped separately. Missingindex/standalone transaction must failclosed. Five atomic groups: entitlement(s),aggregate,receipt,audit,outbox; audit before/after,actor,rawcommand+server times, Received evidenceType manual-assertion. ReturnRequested event serverUTC/nullcause; transition exactnormalizedinstant/previousReturneventIdcause. Pendingonly.

Sources: published Returns annex lines23–43,49–76; YAML #/components/schemas/ReturnLine/CreateReturnCommand/TransitionReturnCommand/ReturnEventPayload; modulepack§25–29; existing EntityBase, Application/DependencyInjection.cs, Persistence/DependencyInjection.cs. Physical index names and PascalCase mappings are bounded implementation choices for existing normative keys, not new policy. Required wrappers/ref inheritance checked in schema-check.txt.
