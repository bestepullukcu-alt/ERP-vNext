# MOD-0186 isolated core DEV — v2.0

Work Package ID: MVP6-MOD0186-CORE-DEV-02  
Prompt Version: 2.0  
Agent Lane Type: DEV  
Target: orchestrator / add-module  
Dispatch: **GO — isolated core only**  
Risk: HIGH; Profile: B; Evidence target: E2 plus actual Mongo core evidence; HTTP integration is separate.

## Exact baseline and authority

- Registered worktree: `/Users/natig/.codex/worktrees/returns-phase15-close-01/ERP-vNext-recovery`
- Branch: `codex/mod-0186-phase15-core-dev-01`
- Expected HEAD: `4a8d4d4b339528a88e6220fb8402e5a2c771136c`
- Dirty/untracked overlay: `input-manifest.tsv`, 413 exact inputs; `head-only-gaps.tsv` identifies why HEAD-only is insufficient.
- Real conditional and replacement user grants: `authority.md`. Applied target and separate promotion: `pack-hashes.txt`, `promotion.patch`.
- Published SHIPMENT-BUNDLE 3.0.0 / wire v1 YAML: `5dfe7c1bba32551bd8d4b532243878684e69a6d9560e667a4183bfd516b9d21c`.
- Returns annex: `00990a289069d25a62f7c883aac718e08b96b0386a572e7d1f93f0e447e98a11`.
- Root annex: `7d1327a12b9775a594631dd9eb3c3c4c90e7f8429581f9ff7f42dde419f7b8af`.
- Owning pack: isolated MOD-0186-reverse-logistics.md, controlling section 30; Phase 1.5: PHASE15.md.

## NE / NASIL

Implement the exact 46 paths in `owned-paths.txt`; use the published Returns policies and physical/context matrices. Preserve arbitrary-precision quantity and instant fingerprints, seven lifecycle arrows, inherited Shipment root, receipt root-before-fingerprint precedence, immutable snapshot/drift detection and entitlement CAS. Execute all five write groups in one Mongo transaction. No Inventory/Warehouse HTTP, worker, publisher or stock writes.

Measure R01–R11 at the appropriate evidence boundary. Use DB-010 fixed test database names and unique test tenants on an isolated non-27017 replica set. Test 6+6/4+6 races, release once, multi-line rollback, exact decimals, scoped replay, unknown commit, and persistence across separate processes. Bind source → build → binary → process → evidence. A model or mocked reference is not HTTP/JWT or producer uptake.

## Ownership / integration

All other source paths, including Program.cs, Claims/Returns shared composition, canonical/guard and other modules, are protected. The integration owner receives a proposed exact Program.cs delta separately. No alternate HTTP testhost composition to bypass that gate. Evidence may be written under `evidence/returns-dev`; no commit/push/stash, migration, rollout or common-checkout application.

Integration order: published target → authorized isolated pack/Phase 1.5 → core DEV → separately authorized HTTP composition → independent VER → CT disposition. Parallel Claims work stays in its separate worktree.

## Handoff

SOP §22, exact source patch and 46-file manifest, command/exit/TRX records, binary/process hashes, criterion mapping, remaining HTTP dependencies and writer-complete status. Do not claim full-module, deployment or HTTP acceptance from core tests.
