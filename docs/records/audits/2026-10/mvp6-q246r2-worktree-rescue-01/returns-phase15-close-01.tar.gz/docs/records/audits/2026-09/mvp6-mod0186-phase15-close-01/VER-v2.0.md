# MOD0186 core VER v2.0
Work Package ID: MVP6-MOD0186-CORE-VER-02
Prompt Version:2.0
Agent Lane Type:VER
Target: independent testing-agent/read-only-auditor
Status: HELD until DEV writer-complete
Capability:MVP6 Returns; Module:MOD0186; Build Lane:isolatedbackend; Risk:HIGH; Profile:B; Evidence:E2+actualMongo where executed, HTTPintegration separate
TargetBranch:codex/mod-0186-phase15-core-dev-01
ExpectedHEAD:4a8d4d4b339528a88e6220fb8402e5a2c771136c
RegisteredWorktree:/Users/natig/.codex/worktrees/returns-phase15-close-01/ERP-vNext-recovery
Dirtybaseline:baseline.txt; input-manifest.tsv currenttracked/untracked overlay, notHEAD-only
Authority:authority.md, promotedpack, PHASE15.md, exactpublishedcontract/Returns/rootannex
AllowedPaths:46exactlines owned-paths.txt; output evidence/returns-dev or evidence/returns-ver withinthisworktree
Protected:allotherpaths inclProgram.cs,shared,Claims,canonical,guard,worker; commit/push/stash forbidden
DependsOn:actualownergrants verified; VERafterwritercomplete; HTTPafterintegrationowner approveddiff
ParallelSafe:MOD0187-HTTP-EVIDENCE-DEV-02 separateworktree
IntegrationOrder:published→approvedisolatedpack→coreDEV→separateProgramcomposition→HTTP/independentVER→CT

NE: Independently rebuild delivered source in separateisolated environment; no sourcefixes.
NASIL: numericquantity+instantfingerprints,64pairs/7arrows,firstsnapshot/entitlementCAS,5distinctwritegroups,scopedreceiptrootprecedence/manualReceived/zeroInventoryWarehouseHTTP. ActualMongo DB010fixedtestDB+tenant isolation onnon27017port; nooperationalDB. Handle6+6 and4+6 races,releaseonce,source409drift,multilinerollback,receipt/restart; noClaims policycopy.
DOĞRULA: R01–R11 packcriteria; freshrestore/build/sourcebinaryprocesshashes; actualexecutedtests separatedfrommodels/mocks. Do not bypassHTTPcomposition withtesthost. Complete independentcorework then reportremainingexactintegrationdiff tosingleowner.
OUTPUT:SOP22,exactsourcepatch/manifest,commandexits/rawresults,percriteria verdict,writercomplete. No blanketHTTP/JWT/E5PASS. Stoponextraownedpath/missingcontract oractualdrift; no broadnewapprovalrequest forcloseddecisions.
