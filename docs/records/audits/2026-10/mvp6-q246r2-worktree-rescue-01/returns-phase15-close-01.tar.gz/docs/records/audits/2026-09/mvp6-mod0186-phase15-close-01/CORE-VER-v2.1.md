# Independent Returns core VER — v2.1

Work Package ID: MVP6-MOD0186-CORE-VER-01; Prompt Version:2.1; Lane:VER; Risk:HIGH; Profile:B. Status: **GO for independent core verification after writer-complete; HTTP/full runtime acceptance HELD**. Do not treat this prompt as an owner runtime acceptance.

Read AGENTS, testing/read-only rules, CT SOP, promoted MOD-0186 pack section30, Phase1.5 package, real authority.md and evidence/returns-dev/SOP-22.md. Verify registered branch/worktree and source/binary input manifest, not HEAD-only. Preserve the exact published contract and annex pins from DEV-v2.0. User grants are already recorded; do not reopen them.

Writer-complete source patch SHA256: `3bb73a8cd77071c0c63721e53f54e9792d155924e8c38ea41e233df78b223a98`.
Promoted isolated pack SHA256: `1c80cca70ef774d18f5d30174566e68c9b6332b61dd1f564d54de3429886482f`.
Input transfer: input-manifest.tsv (413); source manifest: evidence/returns-dev/source-manifest.tsv (46). Independently reproduce patch application and source/build/binary binding in a separate disposable copy. Do not modify the DEV source, common checkout or Claims lane.

Verify receipt root-before-fingerprint and original result replay; seven lifecycle arrows/64 pairs; source required/optional/root precision; exact quantity/instant fingerprints and raw first accepted audit; ordinal entitlement even under non-simple collection default; cap6+6/4+6 races; snapshot drift; release exactly once; Closed/deleted cap retention; scoped tenant/LE receipt history; manual Received and zero Inventory/Warehouse HTTP. Run distinct five-stage rollback faults and genuine unknown-commit/postcommit receipt recovery on a dedicated non27017 DB-010 replica set. Keep fixed database names and unique test tenants. Repeat separate-process restart with source/binary/process pins.

Do not count preauthenticated middleware or mocked Shipment transport as real HTTP/JWT/producer uptake. Program.cs remains protected; no testhost bypass. Preserve/report the existing unrelated architecture failure in Platform DisposableStandaloneMongo.cs:25 rather than editing its source or exception list.

Output only a new lane evidence directory: SOP §22 verdict, exact hash manifest, executed command/exit/TRX/stage/count records, scope preservation and remaining HTTP integration gates. On a new defect, report exact rework; do not fix DEV source. No worker, business defaults, canonical/guard activation, pack promotion, commit/push/stash, deployment or full-module acceptance.
