namespace Diten.Web.Tests.JavaScript;

using Xunit;

public sealed class CarrierIndexBehaviorTests
{
    private readonly string _script = File.ReadAllText(Path.Combine(
        FindRepoRoot(), "frontend/Diten.Web/wwwroot/assets/js/SupplyChain/Carriers/index.js"));
    private readonly string _localizationScript = File.ReadAllText(Path.Combine(
        FindRepoRoot(), "frontend/Diten.Web/wwwroot/assets/js/SupplyChain/Carriers/index.l10n.js"));

    [Fact]
    public void UsesSameOriginProxyAndNeverBuildsBrowserBearerOrServicePortRequest()
    {
        Assert.Contains("const endpoint = '/SupplyChain/Carriers/api';", _script);
        Assert.DoesNotContain(":5061", _script);
        Assert.DoesNotContain("document.cookie", _script);
        Assert.DoesNotContain("Authorization", _script);
        Assert.DoesNotContain(":5000", _script);
    }

    [Fact]
    public void EmitsOnlyListCreateAndStatusOperations()
    {
        Assert.Contains("fetch(buildListUrl()", _script);
        Assert.Contains("fetch(endpoint", _script);
        Assert.Contains("/${encodeURIComponent(carrierId)}/status", _script);
        Assert.DoesNotContain("method: 'DELETE'", _script);
        Assert.DoesNotContain("method: 'PATCH'", _script);
        Assert.DoesNotContain("method: 'PUT'", _script);
        Assert.DoesNotContain("/bulk", _script);
        Assert.DoesNotContain("/import", _script);
    }

    [Fact]
    public void KeepsStablePerPayloadIntentAndUsesSharedModalPrimitives()
    {
        Assert.Contains("existing?.signature === signature", _script);
        Assert.Contains("createIntent = ensureIntent(createIntent, signature)", _script);
        Assert.Contains("statusIntents.set(carrierId, intent)", _script);
        Assert.Contains("'Idempotency-Key': intent.key", _script);
        Assert.Contains("window.showConfirm?.(L.StatusChangeConfirm", _script);
        Assert.Contains("window.showToast?.", _script);
        Assert.DoesNotContain("Swal.fire", _script);
        Assert.DoesNotContain("window.alert", _script);
        Assert.DoesNotContain("window.confirm", _script);
    }

    [Fact]
    public void AppliesIndependentCreateAndStatusPermissions()
    {
        Assert.Contains("permissions.canCreate ? L.AddNewCarrier", _script);
        Assert.Contains("permissions.canChangeStatus && row.status !== 'Retired'", _script);
        Assert.Contains("availableStatusTargets", _script);
        Assert.Contains("['Suspended', 'Retired']", _script);
        Assert.Contains("['Active', 'Retired']", _script);
    }

    [Fact]
    public void LocalizationWarningsUsePresenceAndNonEmptyValueInsteadOfComparingValueToKey()
    {
        Assert.Contains("Object.prototype.hasOwnProperty.call(dictionary, key)", _localizationScript);
        Assert.Contains("dictionary[key].trim().length > 0", _localizationScript);
        Assert.DoesNotContain("dictionary[key] === key", _localizationScript);
    }

    private static string FindRepoRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !File.Exists(Path.Combine(directory.FullName, "AGENTS.md")))
            directory = directory.Parent;
        return directory?.FullName ?? throw new DirectoryNotFoundException("Repository root was not found.");
    }
}
