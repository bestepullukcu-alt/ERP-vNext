# Carrier UI partial-resolution rework

Live composed verification found an authorized-page HTTP 500 because five Carrier-local partials were referenced by relative names from a controller whose conventional view folder differs from the explicit nested view path. The rework changes only `frontend/Diten.Web/Views/SupplyChain/Carriers/Index.cshtml` and binds `_Filter`, `_DataTable`, `_CreateEditOffcanvas`, `_ChangeStatusOffcanvas`, and `_IndexL10n` to explicit `~/Views/SupplyChain/Carriers/*.cshtml` paths. Shared `_AccessDenied` remains unchanged.

- Previous 21-path manifest: `847d4e7aefb8c65f5651336f61a0da2c8baed46109017a692cbf372c345db865`.
- New 21-path manifest: `e96578d0e874e8796469ee763aa9b6e723c7f0c9a966b5fe8a46b535279b26cb`.
- New full UI patch: `3c05dfdf5fb6005d962c1c2d0b33dc8fccd1332a52a812bcdf56af44ff19ec07`.
- New Index hash: `da254157aa3edc3a32434281e71303c1fd7a2bf9bc8863afe4b21884b37ddd0a`.
- Focused rerun: 12/12 PASS (`raw/carrier-ui-rework-rerun.trx`).

This is an owned UI source rework. Shared integration, backend, pack, layout, contract and Program.cs are unchanged.
