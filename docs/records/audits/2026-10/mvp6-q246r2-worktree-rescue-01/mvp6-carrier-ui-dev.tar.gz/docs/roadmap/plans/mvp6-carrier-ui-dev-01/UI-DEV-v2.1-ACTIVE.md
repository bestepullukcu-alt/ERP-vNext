# MVP6-MOD0184-UI-DEV-02 — v2.1 — ACTIVE

**Target:** frontend-ui-ux single writer  
**Lane:** Carrier UI DEV  
**Authority:** user message `MVP6-CARRIER-UI-DEV-01`, 2026-09-23  
**Worktree:** `/Users/natig/.codex/worktrees/mvp6-carrier-ui-dev/ERP-vNext-recovery`

## Immutable inputs

- Pack target: `28019ebe9fd6e34ca719d244cc0129fe2046ee0f692a9ffd6a5a6eed16028f3f`.
- BC successor manifest: `dec28b6aebd7552df82d380cf8b601aabc4d28c7d21349ff43807bd0747e4634`, verified 422/422 in this worktree.
- Shared integration patch: `3fdc9188f635a2428e3ffc5c4ef07c9c4b747b2f74a4196d8e6207cd85ccf1d5`, verified 18/18 targets in this worktree.
- Carrier contract/annex and Phase 1.5 matrix from `mvp6-carrier-ui-dispatch-close-01`.
- Exact UI allowlist: the 21 paths in `mvp6-carrier-ui-scope-01/OWNED-PATHS.txt`.

## Work

Implement only those 21 UI-owned paths. Build `/SupplyChain/Carriers` as a four-field GoldenReferenceSlim tenant page with list/create/status only, mandatory `_Filter`, `_DataTable`, `_IndexL10n`, create and status offcanvas surfaces, DataTables v2, shared SweetAlert2 primitives, and seven localized view-resource files.

Use independent read/create/status permissions. UAS-001 must render authenticated read-denied content inside the tenant shell without the page/table/actions; unauthenticated behavior remains the existing 401 flow. Browser requests are same-origin to the MVC proxy. The proxy alone forwards through Gateway `http://localhost:5000`; browser JavaScript must not use port 5061, bearer tokens, or cookies as token sources.

Preserve exact Carrier request/response/error/replay behavior. Create fields are `carrierCode`, `displayName`, `supportedModes`, and `externalReference`. Do not add by-id details, edit, delete, bulk, import, new backend endpoints, new permissions, shared layout/JS changes, or server-side DataTables query conventions absent from the contract.

## Verification and handoff

Run focused frontend tests, the DataTable verifier, build, and the independently executable portions of the Phase 1.5 matrix. Record the exact 21-path change manifest and writer-complete. Do not claim composed browser/Gateway/JWT runtime PASS without real process evidence. Do not modify the 18 shared targets, pack, backend, canonical/guard, Program.cs, or another module. No commit/push/stash.
