import pathlib,sys,subprocess,json,time,os
w=pathlib.Path(pathlib.Path('/private/tmp/mod0185-fresh-current.txt').read_text());e=w/'evidence'; name=sys.argv[1];cmd=sys.argv[2:];env=os.environ.copy();env['MOD0185_TEST_MONGO']=env.get('MOD0185_TEST_MONGO','mongodb://127.0.0.1:27785/?replicaSet=mod0185ver03');start=time.time()
with (e/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=w/'copy',env=env,stdout=f,stderr=subprocess.STDOUT)
(e/(name+'.command.json')).write_text(json.dumps({'command':cmd,'cwd':str(w/'copy'),'exit':p.returncode,'testMongo':env['MOD0185_TEST_MONGO'],'startEpoch':start,'endEpoch':time.time()},indent=2));print(name,'exit',p.returncode);print((e/(name+'.log')).read_text()[-2200:]);sys.exit(p.returncode)
