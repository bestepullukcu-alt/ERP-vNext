import pathlib,subprocess,os,time,json,urllib.request,hashlib
w=pathlib.Path(pathlib.Path('/private/tmp/mod0185-fresh-current.txt').read_text());e=w/'evidence';c=w/'copy';dll=c/'services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll';env=os.environ.copy();env.update({'ASPNETCORE_URLS':'http://127.0.0.1:5061','Mongo__ConnectionString':'mongodb://127.0.0.1:27785/?replicaSet=mod0185ver03','Mongo__DatabaseName':'diten_mod0185_startup_probe','JwtSettings__Secret':'MOD0185 isolated runtime probe secret 32+ bytes','JwtSettings__Issuer':'mod0185-runtime','JwtSettings__Audience':'mod0185-runtime','Loads__ReferenceBaseUrl':'http://127.0.0.1:9/'})
f=(e/'a07-recovery-api.log').open('wb');cmd=['dotnet',str(dll)];p=subprocess.Popen(cmd,cwd=c,env=env,stdout=f,stderr=subprocess.STDOUT)
try:
 deadline=time.time()+25
 while time.time()<deadline:
  assert p.poll() is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:5061/health',timeout=1) as response:status=response.status;body=response.read().decode()
   break
  except Exception:time.sleep(.2)
 else:raise AssertionError('recovery health timeout')
 assert status==200
 (e/'startup-recovery.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'binarySha256':hashlib.sha256(dll.read_bytes()).hexdigest(),'status':status,'body':body},indent=2));print('PASS startup recovery health200 after failpoint cleared')
finally:p.terminate();p.wait(timeout=10);f.close()
