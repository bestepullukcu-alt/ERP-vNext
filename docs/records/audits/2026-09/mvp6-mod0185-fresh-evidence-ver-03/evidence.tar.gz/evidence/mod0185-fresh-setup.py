import pathlib,subprocess,json,hashlib
w=pathlib.Path(pathlib.Path('/private/tmp/mod0185-fresh-current.txt').read_text());c=w/'copy';r=pathlib.Path.cwd();e=w/'evidence'
tracked=set(subprocess.check_output(['git','ls-files','services/Diten.SupplyChainService'],text=True).splitlines());changes=[]
for p in list((c/'services/Diten.SupplyChainService').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(c))
 if '/Loads/' in rel or '/Carriers/' in rel or '/loads/' in rel or '/carriers/' in rel or rel.endswith('/Program.cs'):continue
 if rel in tracked:
  data=subprocess.check_output(['git','show','HEAD:'+rel]);old=hashlib.sha256(p.read_bytes()).hexdigest();new=hashlib.sha256(data).hexdigest()
  if old!=new:changes.append({'path':rel,'excludedCurrentHash':old,'selectedHeadHash':new});p.write_bytes(data)
 else:changes.append({'path':rel,'excludedCurrentHash':hashlib.sha256(p.read_bytes()).hexdigest(),'selection':'excluded-untracked-producer'});p.unlink()
(e/'excluded-producer-delta.json').write_text(json.dumps(changes,indent=2))
m=[{'path':str(p.relative_to(c)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(c.rglob('*')) if p.is_file()];(e/'build-input-manifest.json').write_text(json.dumps(m,indent=2))
print('excluded producer deltas',len(changes),'build files',len(m))
