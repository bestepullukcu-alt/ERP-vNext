import pathlib,sys,subprocess,os,json,hashlib,time,runpy,traceback
w=pathlib.Path(pathlib.Path('/private/tmp/mod0185-fresh-current.txt').read_text());e=w/'evidence';c=w/'copy';mode=sys.argv[1];probe=c/'services/Diten.SupplyChainService/tests/loads';sys.path.insert(0,str(probe));import runtime_probe as rp
base='mongodb://127.0.0.1:27785/';mongo=base+'?replicaSet=mod0185ver03&serverSelectionTimeoutMS=3000'
for key,rel in [('MOD0185_SHIPMENT_BUNDLE_CONTRACT_FILE','shipment-bundle.openapi.yaml'),('MOD0185_LOADS_ANNEX_FILE','loads-semantics-v2.0.0.md'),('MOD0185_CARRIER_ANNEX_FILE','carrier-semantics-v1.1.0.md')]:os.environ[key]=str(c/'docs/analysis/contracts'/rel)
realPopen=subprocess.Popen;processes=[];handles=[];requests=[];counts=[];realrequest=rp.request
class ObservedPopen(realPopen):
 def __init__(self,args,*a,**kw):
  args=list(args); record={'command':args.copy(),'startEpoch':time.time()}
  if args[0]=='mongosh':
   # Bound failed replica-selection controls to return a real query exit before probe's ten-second supervisor timeout.
   args=[x+'&serverSelectionTimeoutMS=1500&connectTimeoutMS=1000' if x.startswith('mongodb://') and 'replicaSet=missing' in x else x for x in args];record['effectiveCommand']=args.copy()
  if args[0]=='dotnet' and str(rp.API_DLL) in args:
   f=(e/f'{mode}-api-{len(processes)}.log').open('wb');handles.append(f);kw['stdout']=f;kw['stderr']=subprocess.STDOUT;record['apiBinarySha256']=hashlib.sha256(rp.API_DLL.read_bytes()).hexdigest()
  super().__init__(args,*a,**kw);record['pid']=self.pid;record['process']=self;processes.append(record)
subprocess.Popen=ObservedPopen

def observed_request(url,method='GET',body=None,headers=None):
 result=realrequest(url,method,body,headers);status,hs,raw,sent=result
 requests.append({'timeEpoch':time.time(),'url':url,'method':method,'status':status,'requestBytes':0 if sent is None else len(sent),'requestBody':None if sent is None else sent.decode(),'responseBody':raw.decode(errors='replace'),'responseHeaders':dict(hs),'scopeHeaders':{k:v for k,v in (headers or {}).items() if k!='Authorization'}});return result
rp.request=observed_request
try:
 if mode=='failure':
  import failure_probe as fp
  oldcounts=fp.scoped_counts
  def observed_counts(uri,tenant,le,label='unlabeled'):
   result=oldcounts(uri,tenant,le,label)
   # Independent query, distinct aggregation expression, before AND after actual request.
   expr='const names='+json.dumps(list(fp.COLLECTIONS))+';const scope='+json.dumps({'TenantId':tenant,'LegalEntityId':le})+';print(JSON.stringify(Object.fromEntries(names.map(n=>[n,db.getCollection(n).aggregate([{$match:scope},{$count:"n"}]).toArray()[0]?.n||0]))))'
   done=subprocess.run(['mongosh',uri,'--quiet','--eval',expr],capture_output=True,text=True,timeout=15)
   row={'label':label,'tenant':tenant,'legalEntity':le,'exit':done.returncode,'stdout':done.stdout,'stderr':done.stderr};counts.append(row);assert done.returncode==0;assert json.loads(done.stdout)==result;return result
  fp.scoped_counts=observed_counts;sys.argv=[str(probe/'failure_probe.py'),'--mongo',base+'diten_mod0185_failure_probe?replicaSet=mod0185ver03&serverSelectionTimeoutMS=3000','--evidence',str(e/'failure-paths.json')];fp.main()
 elif mode=='runtime':
  sys.argv=[str(probe/'runtime_probe.py'),'--mongo',mongo,'--evidence',str(e/'runtime.json'),'--start-local'];rp.main()
 elif mode=='restart':
  import restart_probe as rest
  sys.argv=[str(probe/'restart_probe.py'),mongo,str(e/'restart.json')];rest.main()
finally:
 for f in handles:f.close()
 for p in processes:p['exit']=p.pop('process').poll()
 (e/(mode+'-processes.json')).write_text(json.dumps(processes,indent=2));(e/(mode+'-http.json')).write_text(json.dumps(requests,indent=2));
 if counts:(e/'independent-query.json').write_text(json.dumps(counts,indent=2))
