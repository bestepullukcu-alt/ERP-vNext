import pathlib,subprocess,json,copy
w=pathlib.Path(pathlib.Path('/private/tmp/mod0185-fresh-current.txt').read_text());e=w/'evidence';script=w/'copy/services/Diten.SupplyChainService/tests/loads/verify_evidence.py';d=json.loads((e/'runtime.json').read_text());out=[]
mutants={}
x=copy.deepcopy(d);x['operations'][0]['requestBytes']+=1;mutants['byte-count']=x
x=copy.deepcopy(d);x['operations'][1]['requestBody']='{}';x['operations'][1]['requestBytes']=2;mutants['get-body']=x
x=copy.deepcopy(d);x['operations'][0].pop('requestBody');mutants['missing-transport-record']=x
x=copy.deepcopy(d);x['operations'][2]['idempotentReplay']=False;mutants['replay-flag']=x
x=copy.deepcopy(d);x['mockCalls'][0]['requestBytes']=2;mutants['reference-get-body']=x
for name,value in [('valid',d),*mutants.items()]:
 p=e/('a12-'+name+'.json');p.write_text(json.dumps(value,indent=2));cmd=['python3',str(script),str(p)];r=subprocess.run(cmd,capture_output=True,text=True);(e/('a12-'+name+'.log')).write_text(r.stdout+r.stderr);out.append({'case':name,'command':cmd,'exit':r.returncode,'expectedExitClass':'zero' if name=='valid' else 'nonzero'});assert (r.returncode==0)==(name=='valid')
(e/'a12-controls.json').write_text(json.dumps(out,indent=2));print('PASS valid 18 checks; five fresh negative mutants rejected. No historical record reconstructed.')
