import pathlib,subprocess,json,time,os,socket,urllib.request,hashlib
w=pathlib.Path(pathlib.Path('/private/tmp/mod0185-fresh-current.txt').read_text());e=w/'evidence';c=w/'copy';dll=c/'services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll';mongo='mongodb://127.0.0.1:27785/?replicaSet=mod0185ver03&serverSelectionTimeoutMS=3000';rows=[]
def query(name,expr):
 cmd=['mongosh',mongo,'--quiet','--eval',expr];p=subprocess.run(cmd,capture_output=True,text=True,timeout=15);(e/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));assert p.returncode==0;return p.stdout
for port in (27786,27787,5061):
 s=socket.socket();s.bind(('127.0.0.1',port));s.close()
(w/'mongo-standalone').mkdir();cmd=['mongod','--dbpath',str(w/'mongo-standalone'),'--bind_ip','127.0.0.1','--port','27786','--nounixsocket','--logpath',str(e/'mongo-standalone.log')];mg=subprocess.Popen(cmd,stdout=(e/'mongo-standalone-console.log').open('wb'),stderr=subprocess.STDOUT);(e/'standalone-process.json').write_text(json.dumps({'pid':mg.pid,'command':cmd},indent=2));time.sleep(2)
try:
 query('testcommands','printjson(db.adminCommand({getParameter:1,enableTestCommands:1}));printjson(db.adminCommand({configureFailPoint:"failCommand",mode:"off"}))')
 for name,uri in [('standalone','mongodb://127.0.0.1:27786/?serverSelectionTimeoutMS=3000'),('unavailable','mongodb://127.0.0.1:27787/?serverSelectionTimeoutMS=3000'),('index',mongo)]:
  if name=='index':query('index-configure','printjson(db.adminCommand({configureFailPoint:"failCommand",mode:{times:1},data:{failCommands:["createIndexes"],errorCode:10107,errorLabels:["RetryableWriteError"]}}))')
  env=os.environ.copy();env.update({'ASPNETCORE_URLS':'http://127.0.0.1:5061','Mongo__ConnectionString':uri,'Mongo__DatabaseName':'diten_mod0185_startup_probe','JwtSettings__Secret':'MOD0185 isolated runtime probe secret 32+ bytes','JwtSettings__Issuer':'mod0185-runtime','JwtSettings__Audience':'mod0185-runtime','Loads__ReferenceBaseUrl':'http://127.0.0.1:9/'})
  cmd=['dotnet',str(dll)];f=(e/('a07-'+name+'-api.log')).open('wb');p=subprocess.Popen(cmd,cwd=c,env=env,stdout=f,stderr=subprocess.STDOUT);healthy=False;deadline=time.time()+25;attempts=0
  while time.time()<deadline and p.poll() is None:
   try:
    attempts+=1
    with urllib.request.urlopen('http://127.0.0.1:5061/health',timeout=.3) as response:healthy=healthy or response.status==200
   except Exception:pass
   time.sleep(.1)
  timedout=p.poll() is None
  if timedout:p.terminate()
  code=p.wait(timeout=10);f.close();row={'scenario':name,'command':cmd,'pid':p.pid,'binarySha256':hashlib.sha256(dll.read_bytes()).hexdigest(),'mongoUri':uri,'database':'diten_mod0185_startup_probe','exit':code,'healthAvailable':healthy,'healthAttempts':attempts,'supervisorTimeout':timedout};rows.append(row)
  if name=='index':query('index-clear','printjson(db.adminCommand({configureFailPoint:"failCommand",mode:"off"}))')
  assert code!=0 and not timedout and not healthy,row
finally:
 mg.terminate();mg.wait(timeout=15);(e/'startup-results.json').write_text(json.dumps(rows,indent=2))
assert len(rows)==3
print('PASS three fail-closed startup scenarios')
