using MongoDB.Bson;
using MongoDB.Driver;
using Diten.SupplyChainService.Domain.Features.CapacityPlans;
using Diten.SupplyChainService.Infrastructure.Features.CapacityPlans;
using Diten.SupplyChainService.Persistence.Features.CapacityPlans;
using Xunit;
namespace Diten.SupplyChainService.Tests.CapacityPlans;
[Collection("CapacityMongo")]
public sealed class CapacityConcurrencyTests
{
    [Fact]
    public async Task Twenty_distinct_keys_produce_one_active_evaluation()
    {
        var db=new MongoClient("mongodb://127.0.0.1:57192/?replicaSet=rsmod192&serverSelectionTimeoutMS=5000")
            .GetDatabase("DitenSupplyChain_Mod0192_Test");
        foreach(var name in new[]{"capacity_plans","capacity_scenarios","capacity_evaluations","capacity_receipts","capacity_active_slots","capacity_audit","capacity_outbox"})
            await db.DropCollectionAsync(name);
        await new CapacitySchema(db).StartAsync(CancellationToken.None);
        var scope=new CapacityScope(DemandFixtureReader.Tenant,DemandFixtureReader.LegalEntity,Guid.NewGuid());
        var repo=new CapacityRepository(db,new DemandFixtureReader(),new ConstraintFixtureReader());
        var plan=new CapacityPlan {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            Name="Race plan",HorizonStart=new DateOnly(2027,1,1),HorizonEnd=new DateOnly(2027,12,31),
            DemandPlanId="dp-2027",DemandPlanVersion="3",SourceCapturedAt=DateTimeOffset.UtcNow,
            SourceChecksum="sha256:ee56d4f9a3c8",CreatedAt=DateTimeOffset.UtcNow,Version=1,CreatedBy=scope.ActorId};
        Assert.Equal(201,(await repo.CreatePlanAsync(scope,"plan","p",Guid.NewGuid(),plan,CancellationToken.None)).StatusCode);
        var scenario=new CapacityScenario {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            CapacityPlanId=plan.Id,Name="Race scenario",CreatedAt=DateTimeOffset.UtcNow,Version=1,CreatedBy=scope.ActorId,
            ConstraintRefs=[new("line-4-hours","SUPPLY-CONSTRAINTS","8")],Adjustments=[new("line-4","2027-W03","80.000","HOUR")]};
        Assert.Equal(201,(await repo.CreateScenarioAsync(scope,plan.Id,"scenario","s",Guid.NewGuid(),scenario,CancellationToken.None)).StatusCode);
        var requests=Enumerable.Range(0,20).Select(async i =>
        {
            var eval=new CapacityEvaluation {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
                CapacityPlanId=plan.Id,ScenarioId=scenario.Id,EvaluationMode="Finite",ResourceRefs=["line-4"],
                SubmittedAt=DateTimeOffset.UtcNow,CreatedAt=DateTimeOffset.UtcNow,Version=1,CorrelationId=Guid.NewGuid()};
            return await repo.EvaluateAsync(scope,plan.Id,scenario.Id,$"key-{i}",$"fingerprint-{i}",eval.CorrelationId,eval,CancellationToken.None);
        });
        var results=await Task.WhenAll(requests);
        Assert.Single(results,x=>x.StatusCode==202);
        Assert.Equal(19,results.Count(x=>x.StatusCode==409 && x.ErrorCode=="EVALUATION_ALREADY_ACTIVE"));
        Assert.Equal(1,await db.GetCollection<BsonDocument>("capacity_active_slots").CountDocumentsAsync(FilterDefinition<BsonDocument>.Empty));
        Assert.Equal(1,await db.GetCollection<CapacityEvaluation>("capacity_evaluations").CountDocumentsAsync(FilterDefinition<CapacityEvaluation>.Empty));
        Assert.Equal(3,await db.GetCollection<BsonDocument>("capacity_receipts").CountDocumentsAsync(FilterDefinition<BsonDocument>.Empty));
    }
}
