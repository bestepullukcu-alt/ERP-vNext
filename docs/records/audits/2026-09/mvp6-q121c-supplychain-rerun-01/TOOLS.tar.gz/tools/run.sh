#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q121C_LANE=1
C=~/mvp6-env/q121c; W=~/mvp6-env/q121b; export TMPDIR=$C/tmp/
U="mongodb://127.0.0.1:57192/?replicaSet=rsmod192"
export CLAIMS_TEST_MONGO=$U MOD0183_TEST_MONGO=$U MOD0184_TEST_MONGO=$U MOD0185_TEST_MONGO=$U MVP6_MOD0190_MONGO_URI=$U RETURNS_MONGO_URI=$U
L=$C/logs/test; mkdir -p $L
# sampler: every 1 s, record any ESTABLISHED client connection to :27017 (lsof shows local-side PIDs)
( while [ ! -f $C/logs/.done ]; do lsof -nP -iTCP@127.0.0.1:27017 -iTCP@[::1]:27017 -sTCP:ESTABLISHED -Fpcn 2>/dev/null | paste -sd' ' - | grep -v '^$' | sed "s/^/$(date +%H:%M:%S) /" >> $C/logs/S-27017-conn-samples.txt; sleep 1; done ) &
echo "start $(date +%H:%M:%S)" > $C/logs/S-window.txt
cd $W/build-after
dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj --no-build --disable-build-servers --results-directory $L --logger "trx;LogFileName=build-after--supplychain-single-57192.trx" > $L/build-after--supplychain-single-57192.log 2>&1; rc=$?
echo "end $(date +%H:%M:%S) exit $rc" >> $C/logs/S-window.txt
printf "tree\tsuite\texit\tsummary\nq121b/build-after\tsupplychain-single-57192\t%s\t%s\n" $rc "$(grep -E '(Passed|Failed)!' $L/build-after--supplychain-single-57192.log | tail -1 | sed 's/^ *//')" > $C/logs/TEST-SUMMARY.tsv
touch $C/logs/.done; wait; echo RUN-DONE
