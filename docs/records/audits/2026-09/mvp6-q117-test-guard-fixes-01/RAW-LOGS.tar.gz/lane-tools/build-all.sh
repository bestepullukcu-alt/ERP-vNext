#!/usr/bin/env bash
# Q117 builds: stage B (fixes) and the unmodified base clone for the services Q117 changes. No build servers left behind.
set -u
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 MSBUILDDISABLENODEREUSE=1
D=/Users/natig/.dotnet/dotnet; L=/Users/natig/mvp6-env/q117/logs; S=$L/BUILD-SUMMARY.tsv
[ -f $S ] || printf 'tree\ttarget\texit\twarnings\terrors\n' > $S
b() { local tree=$1 t=$2 n; n=$(echo "$tree-$t" | tr '/' '_'); (cd /Users/natig/mvp6-env/q117/$tree && $D build "$t" -c Debug --disable-build-servers -p:UseSharedCompilation=false > $L/build-$n.log 2>&1); local rc=$?
  printf '%s\t%s\t%s\t%s\t%s\n' "$tree" "$t" "$rc" "$(grep -E '^ +[0-9]+ Warning\(s\)' $L/build-$n.log | awk '{print $1}' | tail -1)" "$(grep -E '^ +[0-9]+ Error\(s\)' $L/build-$n.log | awk '{print $1}' | tail -1)" >> $S; }
for t in services/Diten.MdmService/Diten.MdmService.sln services/Diten.HumanCapitalService/src/Diten.HumanCapitalService.Api/Diten.HumanCapitalService.Api.csproj services/Diten.TalentEcosystemService/src/Diten.TalentEcosystemService.Api/Diten.TalentEcosystemService.Api.csproj; do b build-base $t; done
for t in services/Diten.SupplyChainService/Diten.SupplyChainService.sln services/Diten.MdmService/Diten.MdmService.sln services/Diten.HumanCapitalService/src/Diten.HumanCapitalService.Api/Diten.HumanCapitalService.Api.csproj services/Diten.TalentEcosystemService/src/Diten.TalentEcosystemService.Api/Diten.TalentEcosystemService.Api.csproj services/Diten.Building.Blocks/Diten.BuildingBlocks.Security.Secrets.Tests/Diten.BuildingBlocks.Security.Secrets.Tests.csproj frontend/Diten.Web.Tests/Diten.Web.Tests.csproj gateway/Diten.ApiGateway.Tests/Diten.ApiGateway.Tests.csproj tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj; do b build-B $t; done
