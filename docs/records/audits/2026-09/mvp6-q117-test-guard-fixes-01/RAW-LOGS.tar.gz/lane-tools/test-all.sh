#!/usr/bin/env bash
# Q117 test battery (stage B + MDM base comparison). Isolated Mongo 127.0.0.1:57192/rsmod192 only.
set -u
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 MSBUILDDISABLENODEREUSE=1
U="mongodb://127.0.0.1:57192/?replicaSet=rsmod192"
export CLAIMS_TEST_MONGO=$U MOD0183_TEST_MONGO=$U MOD0184_TEST_MONGO=$U MOD0185_TEST_MONGO=$U MVP6_MOD0190_MONGO_URI=$U RETURNS_MONGO_URI=$U
D=/Users/natig/.dotnet/dotnet; Q=/Users/natig/mvp6-env/q117; R=$Q/test-results/B; mkdir -p $R $Q/test-results/BASE; S=$Q/test-results/TEST-SUMMARY.tsv
[ -f $S ] || printf 'tree\tsuite\tfilter\texit\tsummary\n' > $S
t() { local tree=$1 n=$2 proj=$3 filt=$4; shift 4; local out=$Q/test-results/$([ $tree = build-B ] && echo B || echo BASE)
  (cd $Q/$tree && if [ -n "$filt" ]; then $D test $proj --no-build --disable-build-servers --filter "$filt" --results-directory $out --logger "trx;LogFileName=$n.trx" "$@" > $out/$n.log 2>&1; else $D test $proj --no-build --disable-build-servers --results-directory $out --logger "trx;LogFileName=$n.trx" "$@" > $out/$n.log 2>&1; fi); local rc=$?
  printf '%s\t%s\t%s\t%s\t%s\n' "$tree" "$n" "${filt:--}" "$rc" "$(grep -E '^(Passed|Failed)!' $out/$n.log | tail -1)" >> $S; }
SC=services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj
t build-B supplychain-single $SC ""
t build-B supplychain-single-serial $SC "" -- xUnit.ParallelizeTestCollections=false
t build-B split-shipments-root $SC "FullyQualifiedName~Diten.SupplyChainService.Tests.Shipment|FullyQualifiedName~Diten.SupplyChainService.Tests.SourceIntake|FullyQualifiedName~Diten.SupplyChainService.Tests.SourceClient"
for m in Carriers Loads Returns Claims SandopPlans CapacityPlans; do t build-B split-$m $SC "FullyQualifiedName~Diten.SupplyChainService.Tests.$m."; done
t build-B architecture tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj ""
t build-B gateway gateway/Diten.ApiGateway.Tests/Diten.ApiGateway.Tests.csproj ""
t build-B web frontend/Diten.Web.Tests/Diten.Web.Tests.csproj ""
t build-B secrets services/Diten.Building.Blocks/Diten.BuildingBlocks.Security.Secrets.Tests/Diten.BuildingBlocks.Security.Secrets.Tests.csproj ""
MT=services/Diten.MdmService/tests/Diten.MdmService.Application.Tests/Diten.MdmService.Application.Tests.csproj
t build-base mdm-application $MT ""
t build-B mdm-application $MT ""
