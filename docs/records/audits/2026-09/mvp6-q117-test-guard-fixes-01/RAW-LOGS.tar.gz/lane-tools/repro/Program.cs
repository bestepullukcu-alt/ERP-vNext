// Q117 N1 repro (lane-only, not part of the overlay). Mode "lookup-first": a typed Guid use (what a typed collection
// does on first serialisation) happens before AddPersistence — the order Q103 run 3 had (35 Capacity tests first).
// Mode "persistence-first": the order of the passing runs.
using Microsoft.Extensions.Configuration; using Microsoft.Extensions.DependencyInjection; using MongoDB.Bson.Serialization;
var cfg = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>{{"Mongo:ConnectionString","mongodb://127.0.0.1:1"},{"Mongo:DatabaseName","unused"}}).Build();
var mode = args[0];
try {
    if (mode == "init-then-lookup") { Diten.SupplyChainService.Persistence.DependencyInjection.AddPersistence(new ServiceCollection(), cfg); BsonSerializer.LookupSerializer<Guid>(); }
    if (mode == "lookup-first") BsonSerializer.LookupSerializer<Guid>();
    Diten.SupplyChainService.Persistence.DependencyInjection.AddPersistence(new ServiceCollection(), cfg);
    if (mode == "persistence-first") BsonSerializer.LookupSerializer<Guid>();
    Console.WriteLine($"{mode}: OK, Guid serializer = {BsonSerializer.LookupSerializer<Guid>().GetType().Name}");
} catch (Exception e) { Console.WriteLine($"{mode}: {e.GetType().Name}: {e.Message}"); return 1; }
return 0;
