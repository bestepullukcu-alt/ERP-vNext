The first sandboxed probe launch could not spawn mongosh network clients and
produced no acceptance results. A subsequent privileged run stopped before
completion because the probe client timeout was 20 seconds while the deliberate
three-attempt unknown-commit failpoint took 21.25 seconds; Kestrel recorded 499
after the client cancellation. These partial attempts are excluded. The final
coherent run uses a 45-second test-client timeout and clears only the isolated
lane database records before execution.
