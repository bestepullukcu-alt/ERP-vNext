using System.Net;
using System.Text.Json;
using System.Text.Json.Nodes;
using Diten.SupplyChainService.Application.Features.Claims;
using Diten.SupplyChainService.Domain.Features.Claims;
using Diten.SupplyChainService.Infrastructure.Features.Claims;
using Microsoft.Extensions.Configuration;
using Xunit;
namespace Diten.SupplyChainService.Tests.Claims;
public sealed class ClaimReferenceTests
{
 [Theory][InlineData("Draft",false)][InlineData("Planned",false)][InlineData("Dispatched",true)][InlineData("InTransit",true)][InlineData("Delivered",true)][InlineData("Exception",true)][InlineData("Closed",true)][InlineData("Cancelled",false)]
 public void Eligibility_AllEightShipmentStates_MatchesPolicy(string status,bool eligible)
 {
  var claim=new Claim {ClaimedAmount="1"};var snapshot=new ClaimReferenceSnapshot(Guid.NewGuid(),status,null,null,Guid.NewGuid(),DateTimeOffset.UtcNow);
  var ex=Record.Exception(()=>ClaimLifecycle.ValidateCreate(claim,snapshot));
  if(eligible)Assert.Null(ex);else Assert.Equal("CLAIM_SHIPMENT_INELIGIBLE",Assert.IsType<ClaimFailureException>(ex).Code);
 }
 [Theory][InlineData("missing",503)][InlineData("null",503)][InlineData("empty",503)][InlineData("malformed",502)]
 public async Task Reader_UnusableRoot_DistinguishesIncompleteFromMalformed(string mode,int status)
 {
  var id=Guid.NewGuid();var json=Shipment(id);if(mode=="missing")json.Remove("lifecycleCorrelationId");else json["lifecycleCorrelationId"]=mode=="null"?null:mode=="empty"?"":"bad";
  var reader=Reader(json,out var transport,out _);var ex=await Assert.ThrowsAsync<ClaimFailureException>(()=>reader.ObserveAsync(new Claim{ShipmentId=id},default));
  Assert.Equal(status,ex.Status);Assert.Equal(status==502?"CLAIM_REFERENCE_INVALID":"CLAIM_REFERENCE_INCOMPLETE",ex.Code);Assert.Single(transport.Requests);
 }
 [Fact] public async Task Reader_RealNilRoot_PreservesNilAndTrustedScope()
 {
  var id=Guid.NewGuid();var reader=Reader(Shipment(id),out var transport,out var context);
  var result=await reader.ObserveAsync(new Claim{ShipmentId=id},default);Assert.Equal(Guid.Empty,result.Root);
  Assert.Single(transport.Requests);var request=transport.Requests[0];Assert.Equal("GET",request.Method);
  Assert.Equal("/api/shipment-bundle/shipments/"+id,request.Path);Assert.Equal(context.Scope.TenantId.ToString(),request.Tenant);Assert.Equal(context.Scope.LegalEntityId.ToString(),request.Le);
 }
 [Fact] public async Task Reader_MismatchedIdentity_IsMalformedNotNotFound()
 {
  var reader=Reader(Shipment(Guid.NewGuid()),out _,out _);var ex=await Assert.ThrowsAsync<ClaimFailureException>(()=>reader.ObserveAsync(new Claim{ShipmentId=Guid.NewGuid()},default));Assert.Equal(502,ex.Status);
 }
 [Theory][InlineData("Active")][InlineData("Suspended")][InlineData("Retired")]
 public async Task Reader_ExplicitMatchingCarrier_AllHistoricalStatusesQualify(string status)
 {
  var id=Guid.NewGuid();var carrier=Guid.NewGuid();var shipment=Shipment(id);shipment["carrierId"]=carrier.ToString();
  var handler=new BranchTransport(shipment.ToJsonString(),Carriers(carrier,status).ToJsonString());var reader=BranchReader(handler);
  var claim=new Claim {ShipmentId=id,CarrierId=carrier,ClaimedAmount="1"};var snapshot=await reader.ObserveAsync(claim,default);
  ClaimLifecycle.ValidateCreate(claim,snapshot);Assert.Equal(status,snapshot.CarrierStatus);Assert.Equal(carrier,snapshot.ShipmentCarrierId);
  Assert.Equal(new[]{"/api/shipment-bundle/shipments/"+id,"/api/shipment-bundle/carriers"},handler.Paths);
 }
 [Theory][InlineData("carrierCode")][InlineData("displayName")][InlineData("status")][InlineData("supportedModes")][InlineData("carrierId")]
 public async Task Reader_RequiredCarrierFieldMissing_IsMalformed502(string field)
 {
  var id=Guid.NewGuid();var carrier=Guid.NewGuid();var shipment=Shipment(id);shipment["carrierId"]=carrier.ToString();var carriers=Carriers(carrier,"Active");
  carriers["items"]![0]!.AsObject().Remove(field);var handler=new BranchTransport(shipment.ToJsonString(),carriers.ToJsonString());
  var ex=await Assert.ThrowsAsync<ClaimFailureException>(()=>BranchReader(handler).ObserveAsync(new Claim {ShipmentId=id,CarrierId=carrier},default));
  Assert.Equal(502,ex.Status);Assert.Equal("CLAIM_REFERENCE_INVALID",ex.Code);Assert.Equal(2,handler.Paths.Count);
 }
 [Fact] public async Task Reader_ExplicitCarrierNotInList_Generic404()
 {
  var id=Guid.NewGuid();var carrier=Guid.NewGuid();var shipment=Shipment(id);shipment["carrierId"]=carrier.ToString();
  var handler=new BranchTransport(shipment.ToJsonString(),Carriers(Guid.NewGuid(),"Active").ToJsonString());
  var ex=await Assert.ThrowsAsync<ClaimFailureException>(()=>BranchReader(handler).ObserveAsync(new Claim {ShipmentId=id,CarrierId=carrier},default));
  Assert.Equal(404,ex.Status);Assert.Equal("CLAIM_NOT_FOUND",ex.Code);
 }
 [Fact] public async Task Reader_ExplicitCarrierWithNullShipmentCarrier_BusinessMismatch422()
 {
  var id=Guid.NewGuid();var carrier=Guid.NewGuid();var shipment=Shipment(id);shipment["carrierId"]=null;
  var handler=new BranchTransport(shipment.ToJsonString(),Carriers(carrier,"Retired").ToJsonString());var claim=new Claim {ShipmentId=id,CarrierId=carrier,ClaimedAmount="1"};
  var snapshot=await BranchReader(handler).ObserveAsync(claim,default);Assert.Null(snapshot.ShipmentCarrierId);
  var ex=Assert.Throws<ClaimFailureException>(()=>ClaimLifecycle.ValidateCreate(claim,snapshot));Assert.Equal(422,ex.Status);Assert.Equal("CLAIM_CARRIER_MISMATCH",ex.Code);Assert.Equal(2,handler.Paths.Count);
 }
 [Fact] public async Task Reader_ExplicitCarrierWithMissingShipmentField_IncompleteBeforeCarrierRead()
 {
  var id=Guid.NewGuid();var handler=new BranchTransport(Shipment(id).ToJsonString(),Carriers(Guid.NewGuid(),"Active").ToJsonString());
  var ex=await Assert.ThrowsAsync<ClaimFailureException>(()=>BranchReader(handler).ObserveAsync(new Claim {ShipmentId=id,CarrierId=Guid.NewGuid()},default));
  Assert.Equal(503,ex.Status);Assert.Equal("CLAIM_REFERENCE_INCOMPLETE",ex.Code);Assert.Single(handler.Paths);
 }
 [Theory][InlineData("timeout",503,"CLAIM_REFERENCE_UNAVAILABLE")][InlineData("invalid-json",502,"CLAIM_REFERENCE_INVALID")][InlineData("not-found",404,"CLAIM_NOT_FOUND")]
 public async Task Reader_TransportFailures_MapWithoutRawErrorLeak(string fault,int status,string code)
 {
  var handler=new BranchTransport("{", "{}") {Fault=fault};
  var ex=await Assert.ThrowsAsync<ClaimFailureException>(()=>BranchReader(handler).ObserveAsync(new Claim {ShipmentId=Guid.NewGuid()},default));
  Assert.Equal(status,ex.Status);Assert.Equal(code,ex.Code);Assert.DoesNotContain("private-source-error",ex.Message);
 }
 private static JsonObject Carriers(Guid id,string status)=>new(){["items"]=new JsonArray(new JsonObject{["carrierId"]=id.ToString(),["carrierCode"]="C1",["displayName"]="Carrier",["status"]=status,["supportedModes"]=new JsonArray("Road")}),["total"]=1,["contractVersion"]="v1"};
 private static ClaimReferenceReader BranchReader(BranchTransport handler)=>new(new HttpClient(handler),new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>{["Claims:ReferenceBaseUrl"]="http://reference.invalid/"}).Build(),new ClaimRequestContext {Scope=new(Guid.NewGuid(),Guid.NewGuid(),Guid.NewGuid()),CorrelationId=Guid.NewGuid(),Authorization="Bearer test-only"});
 private sealed class BranchTransport(string shipment,string carriers):HttpMessageHandler
 {
  public string? Fault {get;init;} public List<string> Paths {get;}=[];
  protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
  {
   Assert.Equal(HttpMethod.Get,request.Method);var path=request.RequestUri!.PathAndQuery;Paths.Add(path);
   if(Fault=="timeout")throw new TaskCanceledException("private-source-error");
   var status=Fault=="not-found"?HttpStatusCode.NotFound:HttpStatusCode.OK;
   var body=path=="/api/shipment-bundle/carriers"?carriers:shipment;
   return Task.FromResult(new HttpResponseMessage(status){Content=new StringContent(body)});
  }
 }
 private static JsonObject Shipment(Guid id)=>new(){["shipmentId"]=id.ToString(),["status"]="Delivered",["sourceModule"]="MOD-0141",["sourceType"]="SALES_ORDER",["warehouseReferenceId"]="w",["shipToReference"]="s",["lines"]=new JsonArray(),["contractVersion"]="v1",["lifecycleCorrelationId"]=Guid.Empty.ToString()};
 private static ClaimReferenceReader Reader(JsonObject shipment,out ReferenceTransport transport,out ClaimRequestContext context)
 {
  transport=new ReferenceTransport(shipment.ToJsonString());context=new(){Scope=new(Guid.NewGuid(),Guid.NewGuid(),Guid.NewGuid()),CorrelationId=Guid.NewGuid(),Authorization="Bearer fixture-not-authentication"};
  return new(new HttpClient(transport),new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>{["Claims:ReferenceBaseUrl"]="http://reference.invalid/"}).Build(),context);
 }
 internal sealed class ReferenceTransport(string body):HttpMessageHandler
 {
  public List<(string Method,string Path,string Tenant,string Le)> Requests {get;}=[];
  protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage r,CancellationToken ct){Requests.Add((r.Method.Method,r.RequestUri!.PathAndQuery,r.Headers.GetValues("X-Tenant-Id").Single(),r.Headers.GetValues("X-Legal-Entity-Id").Single()));return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent(body)});}
 }
}
