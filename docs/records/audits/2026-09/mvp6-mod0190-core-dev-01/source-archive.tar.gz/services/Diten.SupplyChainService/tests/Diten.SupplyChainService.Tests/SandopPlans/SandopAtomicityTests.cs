using Xunit;using MongoDB.Bson;using MongoDB.Driver;using Diten.SupplyChainService.Domain.Features.SandopPlans;
namespace Diten.SupplyChainService.Tests.SandopPlans;
public sealed class SandopAtomicityTests
{[Fact]public async Task Invalid_fixture_creates_nothing_in_five_effect_collections()
{var(h,db,s,f)=await SandopTestHost.Open();var bad=SandopTestHost.J("""{"name":"bad","horizonStart":"2027-01-01","horizonEnd":"2027-12-31","demandPlanId":"missing","demandPlanVersion":"3"}""");
 var result=await SandopTestHost.Mutate(h,s,f,SandopAction.Create,null,Guid.NewGuid().ToString(),bad);Assert.Equal(422,result.Status);Assert.Equal("INVALID_DEMAND_REFERENCE",result.Code);
 foreach(var name in new[]{"sandop_plans","sandop_snapshots","sandop_receipts","sandop_audit","sandop_outbox"})Assert.Equal(0,await db.GetCollection<BsonDocument>(name).CountDocumentsAsync(new BsonDocument("TenantId",s.TenantId.ToString())));
}

 [Fact]public async Task Checksum_mismatch_produces_422_and_no_capture_effects()
 {var(h,db,s,f)=await SandopTestHost.Open();var created=await SandopTestHost.Mutate(h,s,f,SandopAction.Create,null,Guid.NewGuid().ToString(),SandopTestHost.Create());Assert.Equal(201,created.Status);var id=SandopTestHost.Id(created,"sandopPlanId");
 var scoped=new BsonDocument("TenantId",s.TenantId.ToString());var names=new[]{"sandop_plans","sandop_snapshots","sandop_receipts","sandop_audit","sandop_outbox"};var before=await Task.WhenAll(names.Select(n=>db.GetCollection<BsonDocument>(n).CountDocumentsAsync(scoped)));
 var wrong=SandopTestHost.J("""{"demandPlanId":"dp-2027","demandPlanVersion":"3","sourceCapturedAt":"2026-09-15T09:45:00Z","sourceChecksum":"sha256:wrong"}""");var result=await SandopTestHost.Mutate(h,s,f,SandopAction.Capture,id,Guid.NewGuid().ToString(),wrong);Assert.Equal(422,result.Status);Assert.Equal("INVALID_DEMAND_REFERENCE",result.Code);
 var after=await Task.WhenAll(names.Select(n=>db.GetCollection<BsonDocument>(n).CountDocumentsAsync(scoped)));Assert.Equal(before,after);
 }
 [Fact]public async Task Unavailable_dependency_returns_declared_503()
 {var(h,db,s,f)=await SandopTestHost.Open();var unreachable=new MongoClient("mongodb://127.0.0.1:57191/?serverSelectionTimeoutMS=150");var repo=new Diten.SupplyChainService.Persistence.Features.SandopPlans.SandopRepository(unreachable.GetDatabase("DitenSupplyChain_Mod0190_Test"));var result=await SandopTestHost.Mutate(repo,s,f,SandopAction.Create,null,Guid.NewGuid().ToString(),SandopTestHost.Create());Assert.Equal(503,result.Status);Assert.Equal("DEPENDENCY_UNAVAILABLE",result.Code);}

}
