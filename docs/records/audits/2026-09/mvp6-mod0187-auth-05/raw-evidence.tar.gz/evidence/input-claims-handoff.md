# Claims evidence lane handoff

Use integration checkout `/private/tmp/mvp6-mod0186-http-integration-01` only while its combined manifest remains SHA-256 `4ae0f286479761512f50216e5bd8be721e48ae4839c062b57cfdd29696e2daa8` and Program.cs remains `a72a05a5e185e04d70ba221f086baacb8c8fca11ea061f289cb4b54fd430254c`.

Immutable archive: `evidence/returns-transfer/integration-source-baseline.tar.gz`, SHA-256 `eaf786e647ef019f862c7dcc4f0b2ab29b2b5a36ff1bee98d2cca8d2863cc766`; independent extraction matched 97/97 manifest entries.

Claims 47/47 source hashes are preserved. Fresh build passed and Claims core regression is 120/120 PASS. This handoff authorizes no Claims source edits. HTTP/JWT/producer/restart evidence must record a new process and runtime chain and must not reuse the earlier `6784...` binary. Current integration API binary is `72b18fb7af51f08a5375587c5b049210d7fec74c3e468b63f67fca2cfbc3842f`.
