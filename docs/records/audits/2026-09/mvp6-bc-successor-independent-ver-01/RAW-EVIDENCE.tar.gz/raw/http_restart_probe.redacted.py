#!/usr/bin/env python3
import base64, hashlib, hmac, json, os, pathlib, subprocess, time, urllib.error, urllib.request, uuid

ROOT = pathlib.Path('/private/tmp/mvp6-bc-successor-ver-01/source')
OUT = pathlib.Path('/private/tmp/mvp6-bc-successor-ver-01/raw')
DLL = ROOT/'services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll'
URL = 'http://127.0.0.1:57032'
MONGO = 'mongodb://127.0.0.1:57292/?replicaSet=rsmod192&serverSelectionTimeoutMS=5000'
DB = 'DitenSupplyChain_BC_Successor_VER01'
MONGO_DB = 'mongodb://127.0.0.1:57292/'+DB+'?replicaSet=rsmod192&serverSelectionTimeoutMS=5000'
TENANT = '19200000-0000-4000-8000-000000000001'
LE = '19200000-0000-4000-8000-000000000002'
ACTOR = '19200000-0000-4000-8000-000000000099'
SECRET = '[REDACTED EPHEMERAL TEST SECRET]'
ISS = 'bc-ver01'
AUD = 'bc-ver01'
PERMS = ['supplychain.capacity-plans.read','supplychain.capacity-plans.create','supplychain.capacity-plans.scenario.create','supplychain.capacity-plans.evaluate']
COLLECTIONS = ['capacity_plans','capacity_scenarios','capacity_evaluations','capacity_receipts','capacity_active_slots','capacity_audit','capacity_outbox']

def enc(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=')

def token():
    header = enc(b'{"alg":"HS256","typ":"JWT"}')
    payload = enc(json.dumps({'iss':ISS,'aud':AUD,'sub':ACTOR,'tenant_id':TENANT,'legal_entity_id':LE,'permission':PERMS,'iat':int(time.time()),'exp':int(time.time())+300},separators=(',',':')).encode())
    signature = enc(hmac.new(SECRET.encode(),header+b'.'+payload,hashlib.sha256).digest())
    return (header+b'.'+payload+b'.'+signature).decode()

def db_snapshot(label):
    collections = json.dumps(COLLECTIONS)
    js = f'''const cs={collections}; const tenant="{TENANT}"; const le="{LE}";
const scoped={{TenantId:{{$in:[tenant,UUID(tenant)]}},LegalEntityId:{{$in:[le,UUID(le)]}}}};
const counts={{}}; for (const c of cs) counts[c]=db.getCollection(c).countDocuments(scoped);
const result={{label:"{label}",database:db.getName(),scope:{{tenantId:tenant,legalEntityId:le}},counts:counts,
scenarioNames:db.capacity_scenarios.find(scoped,{{_id:0,Name:1}}).toArray(),
totalReceipts:db.capacity_receipts.countDocuments({{}}),totalAudit:db.capacity_audit.countDocuments({{}}),totalOutbox:db.capacity_outbox.countDocuments({{}})}};
print(JSON.stringify(result));'''
    proc = subprocess.run(['mongosh','--quiet',MONGO_DB,'--eval',js],capture_output=True,text=True,check=False)
    if proc.returncode != 0:
        raise RuntimeError('mongosh query failed: '+proc.stderr)
    lines = [x for x in proc.stdout.splitlines() if x.strip().startswith('{')]
    if not lines:
        raise RuntimeError('mongosh query returned no JSON: '+proc.stdout)
    data = json.loads(lines[-1])
    data['queryExit'] = proc.returncode
    return data

def launch(label):
    env = os.environ.copy()
    env.update({'ASPNETCORE_ENVIRONMENT':'Testing','ASPNETCORE_URLS':URL,
        'Mongo__ConnectionString':MONGO,'Mongo__DatabaseName':DB,
        'JwtSettings__Secret':SECRET,'JwtSettings__Issuer':ISS,'JwtSettings__Audience':AUD})
    log_path = OUT/f'api-{label}.log'
    log = log_path.open('wb')
    command = ['/Users/natig/.dotnet/dotnet',str(DLL)]
    process = subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    for _ in range(160):
        if process.poll() is not None:
            log.close()
            raise RuntimeError(f'API {label} exited {process.returncode}')
        try:
            with urllib.request.urlopen(URL+'/health',timeout=.5) as response:
                if response.status == 200:
                    return process, log, {'label':label,'pid':process.pid,'command':command,'binary':str(DLL),'binarySha256':hashlib.sha256(DLL.read_bytes()).hexdigest(),'url':URL,'database':DB,'mongoPort':57292}
        except Exception:
            time.sleep(.25)
    raise RuntimeError(f'API {label} health timeout')

def stop(process, log):
    process.terminate()
    try:
        process.wait(10)
    except subprocess.TimeoutExpired:
        process.kill(); process.wait(5)
    log.close()

records=[]
def call(label, method, path, body=None, key=None, corr=None, expected=None):
    corr = corr or str(uuid.uuid4())
    headers = {'Authorization':'Bearer '+token(),'X-Correlation-Id':corr,'Accept':'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body,separators=(',',':')).encode()
        headers['Content-Type'] = 'application/json'
    if key is not None:
        headers['Idempotency-Key'] = key
    request = urllib.request.Request(URL+path,data=data,headers=headers,method=method)
    try:
        with urllib.request.urlopen(request,timeout=10) as response:
            status=response.status; raw=response.read(); response_headers=dict(response.headers)
    except urllib.error.HTTPError as error:
        status=error.code; raw=error.read(); response_headers=dict(error.headers)
    parsed=json.loads(raw)
    record={'label':label,'method':method,'path':path,'requestBody':body,'requestBytes':0 if data is None else len(data),
        'idempotencyKey':key,'requestCorrelation':corr,'status':status,'responseCorrelation':response_headers.get('X-Correlation-Id'),'response':parsed}
    records.append(record)
    if expected is not None and status != expected:
        raise AssertionError((label,status,parsed))
    if response_headers.get('X-Correlation-Id') != corr:
        raise AssertionError((label,'correlation mismatch',response_headers.get('X-Correlation-Id'),corr))
    return parsed

subprocess.run(['mongosh','--quiet',MONGO_DB,'--eval','db.dropDatabase()'],check=True,capture_output=True,text=True)
before = db_snapshot('before')
plan_body={'name':'BC independent verifier plan','horizonStart':'2028-01-01','horizonEnd':'2028-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3','sourceCapturedAt':'2026-09-23T12:30:00Z','sourceChecksum':'sha256:ee56d4f9a3c8'}
scenario_body={'name':'Exact verifier name','constraintRefs':[{'constraintId':'line-4-hours','source':'SUPPLY-CONSTRAINTS','sourceVersion':'8'}],'adjustments':[{'resourceRef':'line-4','period':'2027-W03','availableCapacityDelta':'80.000','uomId':'HOUR'}]}
changed_body={'name':'Changed verifier payload','constraintRefs':scenario_body['constraintRefs'],'adjustments':scenario_body['adjustments']}
launches=[]
p1,l1,launch1=launch('first'); launches.append(launch1)
try:
    plan=call('create-plan','POST','/api/supply-chain/capacity-plans',plan_body,'ver-plan-key',expected=201); plan_id=plan['capacityPlanId']
    scenario=call('create-scenario','POST',f'/api/supply-chain/capacity-plans/{plan_id}/scenarios',scenario_body,'ver-scenario-key',expected=201); scenario_id=scenario['scenarioId']
    replay=call('replay','POST',f'/api/supply-chain/capacity-plans/{plan_id}/scenarios',scenario_body,'ver-scenario-key',expected=201)
    assert replay['scenarioId'] == scenario_id
    changed=call('changed-payload','POST',f'/api/supply-chain/capacity-plans/{plan_id}/scenarios',changed_body,'ver-scenario-key',expected=409)
    assert changed['error']['code'] == 'IDEMPOTENCY_KEY_REUSED'
    duplicate=call('duplicate-name','POST',f'/api/supply-chain/capacity-plans/{plan_id}/scenarios',scenario_body,'ver-duplicate-key',expected=409)
    assert duplicate['error']['code'] == 'CAPACITY_SCENARIO_NAME_CONFLICT'
    assert duplicate['error']['message'] == 'Capacity scenario name already exists in this plan'
finally:
    stop(p1,l1)

mid = db_snapshot('after-first-process')
p2,l2,launch2=launch('restart'); launches.append(launch2)
try:
    got=call('get-after-restart','GET',f'/api/supply-chain/capacity-plans/{plan_id}',expected=200)
    assert got['capacityPlanId'] == plan_id
    replay2=call('replay-after-restart','POST',f'/api/supply-chain/capacity-plans/{plan_id}/scenarios',scenario_body,'ver-scenario-key',expected=201)
    assert replay2['scenarioId'] == scenario_id
    duplicate2=call('duplicate-after-restart','POST',f'/api/supply-chain/capacity-plans/{plan_id}/scenarios',scenario_body,'ver-duplicate-key-2',expected=409)
    assert duplicate2['error']['code'] == 'CAPACITY_SCENARIO_NAME_CONFLICT'
    assert duplicate2['error']['message'] == 'Capacity scenario name already exists in this plan'
finally:
    stop(p2,l2)

after = db_snapshot('after-restart')
expected_counts={'capacity_plans':1,'capacity_scenarios':1,'capacity_evaluations':0,'capacity_receipts':2,'capacity_active_slots':0,'capacity_audit':2,'capacity_outbox':2}
assert before['counts'] == {name:0 for name in COLLECTIONS}, before
assert mid['counts'] == expected_counts, mid
assert after['counts'] == expected_counts, after
evidence={'verdict':'PASS','database':DB,'mongoUriRedacted':'mongodb://127.0.0.1:57292/?replicaSet=rsmod192',
    'binary':str(DLL),'binarySha256':hashlib.sha256(DLL.read_bytes()).hexdigest(),'sameBinaryRestart':True,
    'planId':plan_id,'scenarioId':scenario_id,'launches':launches,'records':records,
    'snapshots':[before,mid,after],'secretsRecorded':False,'bearerTokensRecorded':False}
(OUT/'http-restart-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'verdict':'PASS','records':len(records),'binarySha256':evidence['binarySha256'],'processes':[x['pid'] for x in launches],'counts':after['counts']}))
