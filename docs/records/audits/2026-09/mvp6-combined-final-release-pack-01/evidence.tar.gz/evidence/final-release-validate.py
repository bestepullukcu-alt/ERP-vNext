from pathlib import Path
import json,hashlib,shutil,subprocess,sys,re,copy
w=Path(Path('/private/tmp/final-release-current.txt').read_text());r=Path.cwd();s=r/'docs/records/audits/2026-09/mvp6-r2-combined-release-candidate-01';e=w/'evidence';pub=w/'publication/docs/analysis/contracts';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree('/private/tmp/mvp6-combined-ver01-x6kwmo_1/tooldeps',w/'tooldeps');sys.path.insert(0,str(w/'tooldeps'))
import yaml
from openapi_spec_validator import OpenAPIV31SpecValidator
from jsonschema import Draft202012Validator,RefResolver,FormatChecker
mapping={'shipment-bundle.openapi.yaml':'shipment-bundle-combined-candidate.yaml','shipment-root-semantics-v3.0.0.md':'shipment-root-semantics-candidate.md','returns-semantics-v3.0.0.md':'returns-semantics-candidate.md','claims-semantics-v3.0.0.md':'claims-semantics-r2.md'};edits=json.loads((e/'metadata-path-transformations.json').read_text());reverse=[]
for dest,source in mapping.items():
 t=(pub/dest).read_text()
 for edit in reversed(edits[dest]):assert t.count(edit['to'])==edit['count'];t=t.replace(edit['to'],edit['from'])
 assert t==(s/source).read_text();reverse.append({'file':dest,'source':source,'businessBytesUnchangedAfterMetadataReverse':True,'candidateHash':H(s/source),'finalHash':H(pub/dest)})
# Apply publication patch to a disposable canonical baseline, not the repository.
a=w/'patch-application';target=a/'docs/analysis/contracts';target.mkdir(parents=True);shutil.copy2(r/'docs/analysis/contracts/shipment-bundle.openapi.yaml',target/'shipment-bundle.openapi.yaml');cmd=['patch','--batch','--fuzz=0','-p1','-i',str(w/'publication.patch')];p=subprocess.run(cmd,cwd=a,capture_output=True,text=True);(e/'patch-application.log').write_text(p.stdout+p.stderr);assert p.returncode==0
assert all((target/n).read_bytes()==(pub/n).read_bytes() for n in mapping)
d=yaml.safe_load((pub/'shipment-bundle.openapi.yaml').read_text());errs=list(OpenAPIV31SpecValidator(d).iter_errors());assert not errs,[x.message for x in errs]
refs=0;examples=0;resolver=RefResolver.from_schema(d);fc=FormatChecker()
def walk(v):
 global refs,examples
 if isinstance(v,dict):
  if '$ref' in v:
   ref=v['$ref'];assert ref.startswith('#/');z=d
   for key in ref[2:].split('/'):z=z[key.replace('~1','/').replace('~0','~')]
   refs+=1
  if 'schema' in v:
   vals=([v['example']] if 'example' in v else [])+[x['value'] for x in v.get('examples',{}).values() if 'value' in x]
   for val in vals:assert not list(Draft202012Validator(v['schema'],resolver=resolver,format_checker=fc).iter_errors(val));examples+=1
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(d)
links=sorted(set(re.findall(r'[A-Za-z][A-Za-z0-9.-]*\.md',(pub/'shipment-bundle.openapi.yaml').read_text())))
assert len(links)==5 and all((pub/x).is_file() for x in links),links
assert d['info']['version']=='3.0.0' and d['info']['x-contract-version']=='v1' and d['info']['x-status']=='FROZEN'
original=yaml.safe_load((s/'shipment-bundle-combined-candidate.yaml').read_text());assert d['components']==original['components'] and d['webhooks']==original['webhooks']
# All operations equal after removing only explicitly declared description filename/release labels.
def normalize(v):
 if isinstance(v,str):
  for x in reversed(edits['shipment-bundle.openapi.yaml'][2:]):v=v.replace(x['to'],x['from'])
  return v
 if isinstance(v,dict):return {k:normalize(x) for k,x in v.items()}
 if isinstance(v,list):return [normalize(x) for x in v]
 return v
assert normalize(d['paths'])==original['paths']
(e/'validation-results.json.txt').write_text(json.dumps({'verdict':'PASS','patchCommand':cmd,'patchExit':p.returncode,'fourAppliedFilesExact':True,'reverseMetadataProof':reverse,'openapi31Errors':0,'validatorVersion':'0.7.2','localRefs':refs,'examples':examples,'annexLinks':links,'componentsAndWebhooksUnchanged':True,'normalizedPathsUnchanged':True,'models':'Not rerun; unchanged semantics bound to independent VER evidence and exact reverse transform.'},indent=2));print('PASS final publication patch, OpenAPI3.1,',refs,'refs,',examples,'examples,',len(links),'annex links; business inverse proof4/4')
