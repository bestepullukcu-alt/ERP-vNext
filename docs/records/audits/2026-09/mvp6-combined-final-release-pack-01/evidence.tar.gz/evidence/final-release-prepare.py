from pathlib import Path
import tempfile,json,hashlib,subprocess,shutil,difflib,yaml
r=Path.cwd();w=Path(tempfile.mkdtemp(prefix='mvp6-combined-final-release-',dir='/private/tmp'));Path('/private/tmp/final-release-current.txt').write_text(str(w));s=r/'docs/records/audits/2026-09/mvp6-r2-combined-release-candidate-01';ver=r/'docs/records/audits/2026-09/mvp6-combined-candidate-ver-01';g=r/'docs/records/audits/2026-09/mvp6-guard-payload-path-disposition-r2';raw=w/'evidence';raw.mkdir();pub=w/'publication/docs/analysis/contracts';pub.mkdir(parents=True);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(s/'shipment-bundle-combined-candidate.yaml')=='d763b571a1c6b88cbfadc56af2c51da1c0009589e3b82bcbe122329b17213c88'
for folder,manifest in [(s,'MANIFEST.sha256'),(ver,'SHA256SUMS')]:
 for line in (folder/manifest).read_text().splitlines():h,p=line.split('  ',1);assert H(folder/p)==h
(raw/'preflight.txt').write_text('\n'.join('git '+' '.join(a)+'\n'+subprocess.check_output(['git',*a],text=True) for a in [['branch','--show-current'],['rev-parse','HEAD'],['status','--short'],['diff','--cached','--name-only']]))
inputs=[s/p for p in ['shipment-bundle-combined-candidate.yaml','combined.patch','shipment-root-semantics-candidate.md','returns-semantics-candidate.md','claims-semantics-r2.md']]+[ver/'SOP-22.md',ver/'evidence.tar.gz',g/'final.patch',g/'authority-candidate.json.txt',g/'payload-generator.cs.txt',r/'docs/reference/architecture/docs-path-authority.json',r/'docs/records/decisions/2026-09/mvp6-guard-complete-disposition-owner-approval-01.json',r/'tests/architecture/TenantArchitecture.ArchitectureTests/DocsPathGuardTests.cs',r/'docs/analysis/contracts/shipment-bundle.openapi.yaml']
(raw/'inspected-inputs.sha256').write_text(''.join(H(p)+'  '+str(p.relative_to(r))+'\n' for p in inputs))
# Explicit reversible text substitutions; no YAML serializer reflow.
transforms={};text=(s/'shipment-bundle-combined-candidate.yaml').read_text();edits=[('  version: 2.0.0\n','  version: 3.0.0\n'),('  x-status: CANDIDATE\n  x-candidate-revision: R2\n','  x-status: FROZEN\n  x-shipment-root-semantics: shipment-root-semantics-v3.0.0.md\n'),('semantics-candidate.md','returns-semantics-v3.0.0.md'),('claims-semantics-r2.md','claims-semantics-v3.0.0.md')]
# First filename is Returns-only in original YAML.
transforms['shipment-bundle.openapi.yaml']=[]
for old,new in edits:
 n=text.count(old);assert n;transforms['shipment-bundle.openapi.yaml'].append({'from':old,'to':new,'count':n});text=text.replace(old,new)
(pub/'shipment-bundle.openapi.yaml').write_text(text)
annexes=[('shipment-root-semantics-candidate.md','shipment-root-semantics-v3.0.0.md',[('# Shipment root candidate R2 semantics','# Shipment root semantics — SHIPMENT-BUNDLE 3.0.0 / wire v1'),('- Candidate metadata is R2 only; contract version remains 2.0.0 and status is CANDIDATE.','- Publication metadata proposal is SHIPMENT-BUNDLE 3.0.0 / wire v1. Prepared bytes have FROZEN metadata; actual publication requires the separate owner release decision.')]),('returns-semantics-candidate.md','returns-semantics-v3.0.0.md',[('# Returns R2 — NEW UNPUBLISHED CANDIDATE','# Returns semantics — SHIPMENT-BUNDLE 3.0.0 / wire v1'),('Root R2 schema/semantics dependency is pinned separately in root-binding.md. No root candidate is merged here.','Root schema is composed in this bundle; shipment-root-semantics-v3.0.0.md is its normative annex. Publication does not establish producer runtime uptake.')]),('claims-semantics-r2.md','claims-semantics-v3.0.0.md',[('# Claims R2 normative candidate — D187 approved design, not release authority','# Claims semantics — SHIPMENT-BUNDLE 3.0.0 / wire v1'),('This is a NEW reconstructed candidate; historical hashes/PASS do not apply. Scope: Claims operations only. Baseline metadata 2.0.0 is retained solely for composition; no final release version chosen. wire v1 unchanged.','Publication proposal: SHIPMENT-BUNDLE 3.0.0 / wire v1. Scope: Claims operations only. The approved reconstructed design is unchanged; candidate-to-final metadata and path deltas are bound separately. Actual publication requires the separate owner release decision.')])]
for source,dest,edits in annexes:
 text=(s/source).read_text();transforms[dest]=[]
 for old,new in edits:
  assert text.count(old)==1;transforms[dest].append({'from':old,'to':new,'count':1});text=text.replace(old,new)
 (pub/dest).write_text(text)
for name in ['carrier-semantics-v1.1.0.md','loads-semantics-v2.0.0.md']:shutil.copy2(s/name,pub/name)
(raw/'metadata-path-transformations.json').write_text(json.dumps(transforms,indent=2))
files=['shipment-bundle.openapi.yaml']+[x[1] for x in annexes];patch='';delta=''
for name in files:
 path='docs/analysis/contracts/'+name;old=(r/path).read_text() if (r/path).is_file() else '';new=(pub/name).read_text();patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path if old else '/dev/null',tofile='b/'+path))
 source='shipment-bundle-combined-candidate.yaml' if name=='shipment-bundle.openapi.yaml' else next(x[0] for x in annexes if x[1]==name)
 delta+=''.join(difflib.unified_diff((s/source).read_text().splitlines(True),new.splitlines(True),fromfile='candidate/'+source,tofile='final/'+name))
(w/'publication.patch').write_text(patch);(w/'candidate-to-final.patch').write_text(delta)
manifest=[{'path':'docs/analysis/contracts/'+n,'sha256':H(pub/n),'before':H(r/'docs/analysis/contracts'/n) if (r/'docs/analysis/contracts'/n).is_file() else 'ABSENT'} for n in files];(w/'publication-manifest.json.txt').write_text(json.dumps(manifest,indent=2)+'\n')
# Preserve raw target/seal indentation from R2 authority. Only pin/path/status envelope changes.
a=(g/'authority-candidate.json.txt').read_text();current=json.loads((r/'docs/reference/architecture/docs-path-authority.json').read_text());obj=json.loads(a);assert obj['sealedInputs'][:17]==current['sealedInputs'][:17];assert len(obj['sealedInputs'])==22
old=next(t['sha256'] for t in obj['canonicalTargets'] if t['path'].endswith('shipment-bundle.openapi.yaml'));new=H(pub/'shipment-bundle.openapi.yaml');assert a.count(old)==1;a=a.replace(old,new)
a=a.replace('docs/records/decisions/2026-09/mvp6-guard-payload-path-disposition-r2.json','docs/records/decisions/2026-09/mvp6-combined-final-release-guard-owner-decision-01.json')
(w/'authority-binding-candidate.json.txt').write_text(a)
# Policy/fixture/relocation review delta excludes old R2 authority/decision sections; no application.
parts=(g/'final.patch').read_text().split('diff --git ');kept=[];excluded=[]
for part in parts:
 if not part.strip():continue
 header=part.splitlines()[0]
 if 'docs/reference/architecture/docs-path-authority.json' in header or 'docs/records/decisions/' in header:excluded.append(header)
 else:kept.append('diff --git '+part)
assert kept
(w/'guard-policy-fixture-relocation.patch').write_text(''.join(kept));(raw/'guard-section-selection.json').write_text(json.dumps({'excludedSupersededBindings':excluded,'retainedSections':[x.splitlines()[0] for x in kept]},indent=2))
print(w);print(json.dumps(manifest,indent=2))
