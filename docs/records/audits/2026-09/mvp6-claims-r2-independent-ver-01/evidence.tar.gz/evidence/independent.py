from pathlib import Path
import ast,copy,json,re,hashlib,subprocess,tempfile,itertools
from decimal import Decimal
import yaml
W=Path(__file__).parent;P=W/'claims-r2';R=Path('/Users/natig/Projects/ERP-vNext-recovery');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=yaml.safe_load((R/'docs/analysis/contracts/shipment-bundle.openapi.yaml').read_text());c=yaml.safe_load((P/'claims-r2.openapi.yaml').read_text());checks=[]
def ck(n,x):checks.append({'id':n,'pass':bool(x)})
ck('baseline-current',sha(R/'docs/analysis/contracts/shipment-bundle.openapi.yaml')==sha(P/'baseline.openapi.yaml'))
desc=b['paths']['/claims/{claimId}/transition']['post']['description'];pairs=set()
for source,targets in re.findall(r'(\w+)->([\w|]+)',desc):
 for target in targets.split('|'):pairs.add((source,target))
ck('canonical-seven',len(pairs)==7)
fixtures=json.loads((P/'lifecycle-fixtures.json').read_text());states=b['components']['schemas']['ClaimStatus']['enum'];ck('49-complete',len(fixtures)==49 and {(f['from'],f['to']) for f in fixtures}==set(itertools.product(states,states)))
for f in fixtures:ck('canonical-'+f['from']+'-'+f['to'],f['expectedStatus']==(200 if (f['from'],f['to']) in pairs else 422) and ((f['from'],f['to']) in pairs or f['expectedCode']=='INVALID_CLAIM_TRANSITION'))
ck('shared',b['components']==c['components']);ck('top-level',all(b[k]==c[k] for k in b if k!='paths'));ck('nonclaims',all(b['paths'][k]==c['paths'][k] for k in b['paths'] if not k.startswith('/claims')))
for k in ['/claims','/claims/{claimId}/transition']:
 for m,op in b['paths'][k].items():ck('allowed-delta-'+k+'-'+m,{a:v for a,v in op.items() if a not in ['description','responses']}=={a:v for a,v in c['paths'][k][m].items() if a not in ['description','responses']})
def refs(x):
 if isinstance(x,dict):
  if '$ref' in x:
   ref=x['$ref'];assert ref.startswith('#/');v=c
   for part in ref[2:].split('/'):v=v[part.replace('~1','/').replace('~0','~')]
  for v in x.values():refs(v)
 elif isinstance(x,list):
  for v in x:refs(v)
refs(c);ck('all-local-refs',True)
policy=json.loads(c['paths']['/claims']['post']['description'].split('\n')[1]);ck('Withdrawn',policy['permissions']['Withdrawn']=='investigate');ck('codes',policy['errors']['lifecycle']==[422,'INVALID_CLAIM_TRANSITION'] and policy['errors']['payload']==[409,'IDEMPOTENCY_KEY_REUSED'] and policy['errors']['root']==[409,'CLAIM_CORRELATION_MISMATCH']);ck('no-worker',not policy['worker'] and not policy['publisher'])
# Isolate actual adapter functions without executing author top-level assertions.
tree=ast.parse((P/'verify-r2.py').read_text());ns={'re':re,'Decimal':Decimal,'json':json,'copy':copy};nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['root','transition','fp','Store']];exec(compile(ast.Module(body=nodes,type_ignores=[]),'adapter-functions','exec'),ns)
for f in fixtures:
 out=ns['transition'](policy,f['from'],f['to'],{'create','investigate','decide','settle'},amount='0' if f['to']=='Approved' else None);ck('execute-'+f['from']+'-'+f['to'],out[0]==f['expectedStatus'])
for n,v,req,changed,status,code in json.loads((P/'root-fixtures.json').read_text()):ck('root-'+n,ns['root'](policy,v,req,changed)==[status,code])
mutation_ids=[x for x in json.loads((P/'r2-results.json').read_text())['checks'] if x['id'].startswith('MUTATION-')];ck('seven-mutations',len(mutation_ids)==7 and all(x['pass'] for x in mutation_ids))
# Expose the limits of the state model, not product bugs.
s=ns['Store'](policy);s.create('t','k','1');changed=s.create('t','k','999');s.create('t','k2','1');s.create('foreign','k','1');ck('state-replay-count',len(s.docs)==3);ck('state-original-actor',s.audits[0]=='a')
limitations={'changedPayloadStoreResult':changed,'expectedFullPolicyResult':409,'assessment':'Store does not implement fingerprint/root/current authorization; standalone root()/fp() are separate tests. Full stateful replay policy unverified.','failpoints':'all four indices take same unconditional post-write rollback branch; not four distinct write-boundary failpoints','mutationScope':'7 policy mutants only; worker mutant checks flag, not execution/process absence','rootMissingNull':'both map to Python None; no JSON parsing distinction tested','amount':'Decimal conversion comparisons do not validate storage/capacity or BSON persistence','recoveredModel':'14 constant declaration checks plus simplified/constant mutation witnesses; 40 is not 40 behavior tests'}
(W/'evidence-limitations.json').write_text(json.dumps(limitations,indent=2))
dep=json.loads((P/'root-dependency.json').read_text());rp=Path(dep['artifact']);ck('root-dependency-hash',rp.exists() and sha(rp)==dep['observedSHA256']);ck('producer-not-embedded',b['components']['schemas']['ShipmentDetail']==c['components']['schemas']['ShipmentDetail'])
T=Path(tempfile.mkdtemp(prefix='patch-',dir=W));f=T/'docs/analysis/contracts/shipment-bundle.openapi.yaml';f.parent.mkdir(parents=True);f.write_bytes((P/'baseline.openapi.yaml').read_bytes());run=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(P/'candidate.patch')],cwd=T,capture_output=True,text=True);ck('patch-exact',run.returncode==0 and f.read_bytes()==(P/'claims-r2.openapi.yaml').read_bytes());(W/'patch.log').write_text(run.stdout+run.stderr)
(W/'independent-results.json').write_text(json.dumps({'checks':checks,'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'canonicalEdges':sorted(pairs),'runtime':False},indent=2))
print(len(checks),'checks',sum(not x['pass'] for x in checks),'failures');assert all(x['pass'] for x in checks)
