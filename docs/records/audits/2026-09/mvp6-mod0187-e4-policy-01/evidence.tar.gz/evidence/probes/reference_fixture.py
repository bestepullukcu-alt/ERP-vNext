#!/usr/bin/env python3
import argparse,json,time
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--port',type=int,required=True);p.add_argument('--state',required=True);p.add_argument('--log',required=True);a=p.parse_args()
seen={}; last={}
def state(): return json.loads(Path(a.state).read_text())
def emit(row):
    with open(a.log,'a') as f:f.write(json.dumps(row,separators=(',',':'))+'\n')
class H(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        cfg=state();corr=self.headers.get('X-Correlation-Id','');tenant=self.headers.get('X-Tenant-Id');le=self.headers.get('X-Legal-Entity-Id')
        if self.path.startswith('/api/shipment-bundle/shipments/'):
            sid=self.path.rsplit('/',1)[-1]; sc=cfg.get('shipments',{}).get(sid,cfg.get('defaultShipment'))
            last[corr]=sid
        elif self.path == '/api/shipment-bundle/carriers':
            sid=last.get(corr);sc=cfg.get('carriersByShipment',{}).get(sid,cfg.get('defaultCarriers'))
        else: sc={'status':404,'body':{}}
        if sc is None: sc={'status':404,'body':{}}
        key=self.path+'|'+corr; n=seen.get(key,0);seen[key]=n+1
        delay=sc.get('delay',0)
        emit({'path':self.path,'method':'GET','correlation':corr,'tenant':tenant,'legalEntity':le,'authorizationPresent':bool(self.headers.get('Authorization')),'attempt':n+1,'delay':delay})
        if delay: time.sleep(delay)
        status=sc.get('status',200); raw=sc.get('raw')
        body=sc.get('bodyAfter') if n and 'bodyAfter' in sc else sc.get('body')
        data=raw.encode() if raw is not None else json.dumps(body,separators=(',',':')).encode()
        self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers()
        try:self.wfile.write(data)
        except BrokenPipeError:pass
ThreadingHTTPServer(('127.0.0.1',a.port),H).serve_forever()
