#!/usr/bin/env python3
import os,base64,hashlib,hmac,http.client,json,subprocess,time
from pathlib import Path
from uuid import uuid4
SECRET=os.environ['CLAIMS_JWT_SECRET'];ISS='claims-e4-policy';AUD='claims-e4-policy-api';MONGO='mongodb://127.0.0.1:27931/?replicaSet=claims_e4_policy';DB='diten_claims_e4_policy';tenant,le,actor=uuid4(),uuid4(),uuid4()
def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
h=b64(b'{"alg":"HS256","typ":"JWT"}');p=b64(json.dumps({'sub':str(actor),'tenant_id':str(tenant),'legal_entity_id':str(le),'permission':['supplychain.claims.create','supplychain.shipments.read'],'iss':ISS,'aud':AUD,'exp':int(time.time())+600},separators=(',',':')).encode());tok=h+'.'+p+'.'+b64(hmac.new(SECRET.encode(),(h+'.'+p).encode(),hashlib.sha256).digest())
def mongo(s):return subprocess.run(['mongosh','--quiet',MONGO,'--eval',s],text=True,capture_output=True,check=True).stdout.strip()
def shipment():
 sid,root=uuid4(),uuid4();mongo(f'db.getSiblingDB({json.dumps(DB)}).sce_shipments.insertOne({{_id:{json.dumps(str(sid))},TenantId:{json.dumps(str(tenant))},LegalEntityId:{json.dumps(str(le))},IsDeleted:false,CreatedAt:new Date(),Version:1,ShipmentNumber:{json.dumps("SHP-HDR-"+sid.hex)},SourceModule:"MOD-0141",SourceType:"SALES_ORDER",SourceDocumentId:"SO",WarehouseReferenceId:"WH",ShipToReference:"C",Lines:[],PlannedShipAt:new Date(),Status:"Delivered",CorrelationId:{json.dumps(str(uuid4()))},LifecycleCorrelationId:{json.dumps(str(root))}}})');return sid,root
def call(sid,root,key,mods=None):
 body=json.dumps({'shipmentId':str(sid),'reasonCode':'HDR','claimedAmount':'1','currency':'USD'},separators=(',',':')).encode();base=[('Authorization','Bearer '+tok),('X-Tenant-Id',str(tenant)),('X-Legal-Entity-Id',str(le)),('X-Correlation-Id',str(root)),('Idempotency-Key',key),('Content-Type','application/json'),('Content-Length',str(len(body)))];
 if mods:base=mods(base)
 c=http.client.HTTPConnection('127.0.0.1',5071,timeout=15);c.putrequest('POST','/api/shipment-bundle/claims');[c.putheader(k,v) for k,v in base];c.endheaders(body);r=c.getresponse();raw=r.read();hs={k.lower():v for k,v in r.getheaders()};c.close();
 try:b=json.loads(raw) if raw else None
 except:b=raw.decode(errors='replace')
 return {'status':r.status,'headers':hs,'body':b}
rows={};sid,root=shipment();rows['ascii128']=call(sid,root,'a'*128);sid,root=shipment();rows['ascii129']=call(sid,root,'a'*129)
sid,root=shipment();rows['duplicate-correlation']=call(sid,root,'dup-corr',lambda x:x+[('X-Correlation-Id',str(root))])
sid,root=shipment();rows['duplicate-key']=call(sid,root,'dup-key',lambda x:x+[('Idempotency-Key','second')])
sid,root=shipment();rows['missing-correlation']=call(sid,root,'missing-corr',lambda x:[p for p in x if p[0]!='X-Correlation-Id'])
sid,root=shipment();rows['duplicate-tenant']=call(sid,root,'dup-tenant',lambda x:x+[('X-Tenant-Id',str(tenant))])
def err(name,code='INVALID_REQUEST'):return rows[name]['status']==400 and isinstance(rows[name]['body'],dict) and rows[name]['body']['error']['code']==code and rows[name]['body']['error']['correlationId']==rows[name]['headers'].get('x-correlation-id')
checks={'ascii128':rows['ascii128']['status']==201,'ascii129':err('ascii129'),'duplicateCorrelation':err('duplicate-correlation'),'duplicateKey':err('duplicate-key'),'missingCorrelation':err('missing-correlation'),'duplicateTenant':err('duplicate-tenant')};out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'rows':rows,'evidenceKind':'real-http-header-boundary'};Path('/private/tmp/mvp6-mod0187-e4-policy-01-iCdUbt/evidence/raw/header-boundary.json').write_text(json.dumps(out,indent=2));print(json.dumps({'status':out['status'],'checks':checks}));raise SystemExit(0 if out['status']=='PASS' else 1)
