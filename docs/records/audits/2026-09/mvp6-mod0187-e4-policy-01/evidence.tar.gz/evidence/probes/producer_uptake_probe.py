#!/usr/bin/env python3
import os,base64,hashlib,hmac,http.client,json,os,subprocess,time
from pathlib import Path
from uuid import UUID,uuid4
API='http://127.0.0.1:5071';DB='diten_claims_e4_policy';MONGO='mongodb://127.0.0.1:27931/?replicaSet=claims_e4_policy';SECRET=os.environ['CLAIMS_JWT_SECRET'];ISS='claims-e4-policy';AUD='claims-e4-policy-api'
tenant,le,actor=uuid4(),uuid4(),uuid4();perms=['supplychain.claims.read','supplychain.claims.create','supplychain.claims.investigate','supplychain.claims.decide','supplychain.claims.settle','supplychain.shipments.read','supplychain.carriers.read']
def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
def jwt():
 h=b64(b'{"alg":"HS256","typ":"JWT"}');p=b64(json.dumps({'sub':str(actor),'tenant_id':str(tenant),'legal_entity_id':str(le),'permission':perms,'iss':ISS,'aud':AUD,'exp':int(time.time())+900},separators=(',',':')).encode());return h+'.'+p+'.'+b64(hmac.new(SECRET.encode(),(h+'.'+p).encode(),hashlib.sha256).digest())
TOK=jwt()
def mongo(s):
 p=subprocess.run(['mongosh','--quiet',MONGO,'--eval',s],text=True,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr)
 return p.stdout.strip()
def req(method,path,corr,body=None,key=None):
 u=http.client.HTTPConnection('127.0.0.1',5071,timeout=15);raw=json.dumps(body,separators=(',',':')).encode() if body is not None else None
 h={'Authorization':'Bearer '+TOK,'X-Tenant-Id':str(tenant),'X-Legal-Entity-Id':str(le),'X-Correlation-Id':str(corr)}
 if key:h['Idempotency-Key']=key
 if raw is not None:h['Content-Type']='application/json'
 u.request(method,path,body=raw,headers=h);r=u.getresponse();data=r.read();hs={k.lower():v for k,v in r.getheaders()};u.close()
 return {'status':r.status,'headers':hs,'body':json.loads(data) if data else None}
def shipdoc(sid,root,carrier=None,root_mode='value'):
 d={'_id':str(sid),'TenantId':str(tenant),'LegalEntityId':str(le),'IsDeleted':False,'CreatedAt':{'$date':'2026-09-21T10:00:00Z'},'Version':1,'ShipmentNumber':'SHP-E4-'+str(sid)[:8],'SourceModule':'MOD-0141','SourceType':'SALES_ORDER','SourceDocumentId':'SO-E4','WarehouseReferenceId':'WH-E4','ShipToReference':'C-E4','Lines':[],'PlannedShipAt':{'$date':'2026-09-20T08:00:00Z'},'Status':'Delivered','CorrelationId':str(uuid4())}
 if carrier is not None:d['CarrierId']=str(carrier)
 if root_mode=='value':d['LifecycleCorrelationId']=str(root)
 elif root_mode=='null':d['LifecycleCorrelationId']=None
 return d
def insert(coll,doc):
 s=json.dumps(doc).replace('{"$date": "2026-09-21T10:00:00Z"}','new Date("2026-09-21T10:00:00Z")').replace('{"$date": "2026-09-20T08:00:00Z"}','new Date("2026-09-20T08:00:00Z")');mongo(f'db.getSiblingDB({json.dumps(DB)}).{coll}.insertOne({s})')
rows={}
# Valid non-nil root through actual Shipment detail and Claims consumer.
sid,root=uuid4(),uuid4();insert('sce_shipments',shipdoc(sid,root));rows['shipment-detail']=req('GET',f'/api/shipment-bundle/shipments/{sid}',root);body={'shipmentId':str(sid),'reasonCode':'REAL','claimedAmount':'1','currency':'USD'};rows['claims-create-root']=req('POST','/api/shipment-bundle/claims',root,body,'e4-real-root')
# Valid authoritative nil root is preserved and accepted.
sid_nil=uuid4();nil=UUID(int=0);insert('sce_shipments',shipdoc(sid_nil,nil));rows['shipment-detail-nil']=req('GET',f'/api/shipment-bundle/shipments/{sid_nil}',nil);rows['claims-create-nil']=req('POST','/api/shipment-bundle/claims',nil,{'shipmentId':str(sid_nil),'reasonCode':'NIL','claimedAmount':'1','currency':'USD'},'e4-real-nil')
# Missing BSON field is emitted as explicit null by producer and rejected incomplete by Claims.
sid_missing=uuid4();insert('sce_shipments',shipdoc(sid_missing,uuid4(),root_mode='missing'));rows['shipment-detail-missing']=req('GET',f'/api/shipment-bundle/shipments/{sid_missing}',uuid4());rows['claims-create-missing']=req('POST','/api/shipment-bundle/claims',uuid4(),{'shipmentId':str(sid_missing),'reasonCode':'MISSING','claimedAmount':'1','currency':'USD'},'e4-real-missing')
# Actual Carrier list seam and explicit matching carrier.
cid=uuid4();carrier={'_id':str(cid),'TenantId':str(tenant),'LegalEntityId':str(le),'IsDeleted':False,'CreatedAt':{'$date':'2026-09-21T10:00:00Z'},'Version':1,'CarrierCode':'E4REAL','DisplayName':'E4 Real Carrier','SupportedModes':['Road'],'ExternalReference':None,'Status':'Suspended','CreatedBy':str(actor)};insert('carriers',carrier);sid_carrier,root_carrier=uuid4(),uuid4();insert('sce_shipments',shipdoc(sid_carrier,root_carrier,cid));rows['carrier-list']=req('GET','/api/shipment-bundle/carriers',root_carrier);rows['claims-create-carrier']=req('POST','/api/shipment-bundle/claims',root_carrier,{'shipmentId':str(sid_carrier),'carrierId':str(cid),'reasonCode':'REAL-CARRIER','claimedAmount':'1','currency':'USD'},'e4-real-carrier')
checks={'nonNilDetail':rows['shipment-detail']['status']==200 and rows['shipment-detail']['body'].get('lifecycleCorrelationId')==str(root),'nonNilCreate':rows['claims-create-root']['status']==201,'nilDetail':rows['shipment-detail-nil']['status']==200 and rows['shipment-detail-nil']['body'].get('lifecycleCorrelationId')==str(nil),'nilCreate':rows['claims-create-nil']['status']==201,'missingEmitsNull':rows['shipment-detail-missing']['status']==200 and rows['shipment-detail-missing']['body'].get('lifecycleCorrelationId') is None,'missingRejected':rows['claims-create-missing']['status']==503 and rows['claims-create-missing']['body']['error']['code']=='CLAIM_REFERENCE_INCOMPLETE','carrierList':rows['carrier-list']['status']==200 and any(x['carrierId']==str(cid) and x['status']=='Suspended' for x in rows['carrier-list']['body']['items']),'carrierCreate':rows['claims-create-carrier']['status']==201}
out={'status':'PASS' if all(checks.values()) else 'FAIL','evidenceKind':'real-producer-uptake','tenantId':str(tenant),'legalEntityId':str(le),'rows':rows,'checks':checks,'tokenRecorded':False,'secretRecorded':False};Path(os.environ['CLAIMS_EVIDENCE']).write_text(json.dumps(out,indent=2));print(json.dumps({'status':out['status'],'checks':checks}));raise SystemExit(0 if out['status']=='PASS' else 1)
