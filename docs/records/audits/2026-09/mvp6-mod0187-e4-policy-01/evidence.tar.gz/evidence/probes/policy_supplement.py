#!/usr/bin/env python3
import os,base64,hashlib,hmac,http.client,json,subprocess,time
from pathlib import Path
from uuid import uuid4
SECRET=os.environ['CLAIMS_JWT_SECRET'];ISS='claims-e4-policy';AUD='claims-e4-policy-api';MONGO='mongodb://127.0.0.1:27931/?replicaSet=claims_e4_policy';DB='diten_claims_e4_policy';tenant,le,actor=uuid4(),uuid4(),uuid4();perms=['supplychain.claims.create','supplychain.claims.investigate','supplychain.claims.decide','supplychain.claims.settle','supplychain.shipments.read']
def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
def jwt(ten=tenant,legal=le,ps=perms):
 h=b64(b'{"alg":"HS256","typ":"JWT"}');p=b64(json.dumps({'sub':str(actor),'tenant_id':str(ten),'legal_entity_id':str(legal),'permission':ps,'iss':ISS,'aud':AUD,'exp':int(time.time())+900},separators=(',',':')).encode());return h+'.'+p+'.'+b64(hmac.new(SECRET.encode(),(h+'.'+p).encode(),hashlib.sha256).digest())
def mongo(s):return subprocess.run(['mongosh','--quiet',MONGO,'--eval',s],text=True,capture_output=True,check=True).stdout.strip()
def shipment(ten=tenant,legal=le):
 sid,root=uuid4(),uuid4();mongo(f'db.getSiblingDB({json.dumps(DB)}).sce_shipments.insertOne({{_id:{json.dumps(str(sid))},TenantId:{json.dumps(str(ten))},LegalEntityId:{json.dumps(str(legal))},IsDeleted:false,CreatedAt:new Date(),Version:1,ShipmentNumber:{json.dumps("SHP-SUP-"+sid.hex)},SourceModule:"MOD-0141",SourceType:"SALES_ORDER",SourceDocumentId:"SO",WarehouseReferenceId:"WH",ShipToReference:"C",Lines:[],PlannedShipAt:new Date(),Status:"Delivered",CorrelationId:{json.dumps(str(uuid4()))},LifecycleCorrelationId:{json.dumps(str(root))}}})');return sid,root
def req(method,path,corr,key=None,body=None,ten=tenant,legal=le,ps=perms,raw=None):
 if raw is None and body is not None:raw=json.dumps(body,separators=(',',':')).encode()
 h={'Authorization':'Bearer '+jwt(ten,legal,ps),'X-Tenant-Id':str(ten),'X-Legal-Entity-Id':str(legal),'X-Correlation-Id':str(corr)}
 if key:h['Idempotency-Key']=key
 if raw is not None:h['Content-Type']='application/json'
 c=http.client.HTTPConnection('127.0.0.1',5071,timeout=15);c.request(method,path,body=raw,headers=h);r=c.getresponse();data=r.read();hs={k.lower():v for k,v in r.getheaders()};c.close();return {'status':r.status,'headers':hs,'body':json.loads(data) if data else None}
def create(key='new',amount='250',reason='SUP',evidence=None):
 sid,root=shipment();b={'shipmentId':str(sid),'reasonCode':reason,'claimedAmount':amount,'currency':'USD'}
 if evidence is not None:b['evidenceReferenceIds']=evidence
 r=req('POST','/api/shipment-bundle/claims',root,key,b);return sid,root,r.get('body',{}).get('claimId'),r
def trans(cid,root,key,target,extras=None,ten=tenant,legal=le,ps=perms):
 b={'targetStatus':target,'occurredAt':'2026-09-21T12:00:00Z'};b.update(extras or {});return req('POST',f'/api/shipment-bundle/claims/{cid}/transition',root,key,b,ten,legal,ps)
rows={};checks={}
# R06 approval omission versus explicit null.
for name,extras in [('missing',{}),('null',{'approvedAmount':None})]:
 _,root,cid,_=create('r06-'+name);trans(cid,root,'r06-'+name+'-i','Investigating');r=trans(cid,root,'r06-'+name+'-a','Approved',extras);rows['r06-'+name]=r;checks['r06-'+name]=r['status']==422 and r['body']['error']['code']=='CLAIM_APPROVAL_AMOUNT_INVALID'
# R07 omitted and null resolution/note retained as BSON null in audit.
for name,extras in [('omitted',{}),('null',{'resolutionCode':None,'note':None})]:
 _,root,cid,_=create('r07-'+name);r=trans(cid,root,'r07-'+name+'-i','Investigating',extras);doc=json.loads(mongo(f'JSON.stringify(db.getSiblingDB({json.dumps(DB)}).claims_audit.findOne({{ClaimId:{json.dumps(cid)},Version:2}},{{ResolutionCode:1,Note:1,_id:0}}))'));rows['r07-'+name]={'response':r,'audit':doc};checks['r07-'+name]=r['status']==200 and doc=={'ResolutionCode':None,'Note':None}
# R10 decoded string escape equivalence.
sid,root=shipment();raw1=('{'+'"shipmentId":"'+str(sid)+'","reasonCode":"A","claimedAmount":"1","currency":"USD"}').encode();raw2=('{'+'"currency":"USD","claimedAmount":"1","reasonCode":"\\u0041","shipmentId":"'+str(sid)+'"}').encode();o=req('POST','/api/shipment-bundle/claims',root,'r10-escape',raw=raw1);p=req('POST','/api/shipment-bundle/claims',root,'r10-escape',raw=raw2);rows['r10-escape']={'original':o,'replay':p};checks['r10-escape']=o['status']==201 and p['status']==201 and p['body'].get('idempotentReplay') is True
# R10 transition optional omission equals explicit null.
_,root,cid,_=create('r10-trans-null');body={'targetStatus':'Investigating','occurredAt':'2026-09-21T12:00:00Z'};o=req('POST',f'/api/shipment-bundle/claims/{cid}/transition',root,'r10-trans-key',body);b2=dict(body);b2.update({'resolutionCode':None,'approvedAmount':None,'note':None});p=req('POST',f'/api/shipment-bundle/claims/{cid}/transition',root,'r10-trans-key',b2);rows['r10-transition-null']={'original':o,'replay':p};checks['r10-transition-null']=o['status']==200 and p['status']==200 and p['body'].get('idempotentReplay') is True
# R11 known foreign tenant aggregate is hidden as 404 after authorization.
_,root,cid,_=create('r11-foreign-source');foreign=uuid4();r=trans(cid,root,'r11-foreign','Withdrawn',ten=foreign,legal=le,ps=['supplychain.claims.investigate']);rows['r11-foreign']=r;checks['r11-foreign']=r['status']==404 and r['body']['error']['code']=='CLAIM_NOT_FOUND'
out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'rows':rows,'evidenceKind':'real-http-supplement'};Path('/private/tmp/mvp6-mod0187-e4-policy-01-iCdUbt/evidence/raw/policy-supplement.json').write_text(json.dumps(out,indent=2));print(json.dumps({'status':out['status'],'checks':checks}));raise SystemExit(0 if out['status']=='PASS' else 1)
