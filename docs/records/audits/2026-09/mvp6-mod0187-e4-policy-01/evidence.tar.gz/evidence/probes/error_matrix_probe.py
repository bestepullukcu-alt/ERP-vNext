#!/usr/bin/env python3
import os,base64,hashlib,hmac,http.client,json,subprocess,time
from pathlib import Path
from uuid import uuid4
SECRET=os.environ['CLAIMS_JWT_SECRET'];ISS='claims-e4-policy';AUD='claims-e4-policy-api';MONGO='mongodb://127.0.0.1:27931/?replicaSet=claims_e4_policy';DB='diten_claims_e4_policy';tenant,le,actor=uuid4(),uuid4(),uuid4()
def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
h=b64(b'{"alg":"HS256","typ":"JWT"}');p=b64(json.dumps({'sub':str(actor),'tenant_id':str(tenant),'legal_entity_id':str(le),'permission':['supplychain.claims.read'],'iss':ISS,'aud':AUD,'exp':int(time.time())+600},separators=(',',':')).encode());tok=h+'.'+p+'.'+b64(hmac.new(SECRET.encode(),(h+'.'+p).encode(),hashlib.sha256).digest())
def mongo(s):return subprocess.run(['mongosh','--quiet',MONGO,'--eval',s],text=True,capture_output=True,check=True).stdout.strip()
def get():
 corr=uuid4();c=http.client.HTTPConnection('127.0.0.1',5071,timeout=15);c.request('GET','/api/shipment-bundle/claims',headers={'Authorization':'Bearer '+tok,'X-Tenant-Id':str(tenant),'X-Legal-Entity-Id':str(le),'X-Correlation-Id':str(corr)});r=c.getresponse();raw=r.read();hs={k.lower():v for k,v in r.getheaders()};c.close();return {'status':r.status,'headers':hs,'body':json.loads(raw) if raw else None}
mongo('db.adminCommand({configureFailPoint:"failCommand",mode:"alwaysOn",data:{failCommands:["find"],errorCode:91}})');storage=get();mongo('db.adminCommand({configureFailPoint:"failCommand",mode:"off"})')
mongo(f'db.getSiblingDB({json.dumps(DB)}).claims.insertOne({{_id:{json.dumps(str(uuid4()))},TenantId:{json.dumps(str(tenant))},LegalEntityId:{json.dumps(str(le))},IsDeleted:false,CreatedAt:new Date(),Version:1,ClaimNumber:"CLM-invalid-guid",ShipmentId:"not-a-guid",ReasonCode:"X",ClaimedAmount:"1",Currency:"USD",EvidenceReferenceIds:[],Status:"Open",CorrelationRoot:{json.dumps(str(uuid4()))},LastEventId:{json.dumps(str(uuid4()))}}})')
internal=get()
def exact(r,status,code,msg):return r['status']==status and r['body']['error']['code']==code and r['body']['error']['message']==msg and r['body']['contractVersion']=='v1' and r['body']['error']['correlationId']==r['headers'].get('x-correlation-id')
checks={'storage':exact(storage,503,'CLAIM_STORAGE_UNAVAILABLE','Claim storage is unavailable.'),'internal':exact(internal,500,'INTERNAL_ERROR','An internal error occurred.'),'noLeak':all('Exception' not in json.dumps(x) and 'not-a-guid' not in json.dumps(x) for x in (storage,internal))};out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'rows':{'storage':storage,'internal':internal},'evidenceKind':'controlled-mongo-fault'};Path('/private/tmp/mvp6-mod0187-e4-policy-01-iCdUbt/evidence/raw/error-matrix-extra.json').write_text(json.dumps(out,indent=2));print(json.dumps({'status':out['status'],'checks':checks}));raise SystemExit(0 if out['status']=='PASS' else 1)
