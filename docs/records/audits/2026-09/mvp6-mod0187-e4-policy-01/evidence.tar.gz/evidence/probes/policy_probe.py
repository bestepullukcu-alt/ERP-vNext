#!/usr/bin/env python3
import base64,hashlib,hmac,http.client,json,os,subprocess,time,urllib.error,urllib.parse,urllib.request
from pathlib import Path
from uuid import UUID,uuid4

API=os.environ['CLAIMS_API_URL'].rstrip('/'); FIXTURE=os.environ['CLAIMS_FIXTURE_URL'].rstrip('/')
DB=os.environ['CLAIMS_TEST_DB']; MONGO=os.environ['CLAIMS_MONGO_URI']; STATE=Path(os.environ['CLAIMS_FIXTURE_STATE']); OUT=Path(os.environ['CLAIMS_EVIDENCE'])
ISS=os.environ['CLAIMS_JWT_ISSUER'];AUD=os.environ['CLAIMS_JWT_AUDIENCE'];SECRET=os.environ['CLAIMS_JWT_SECRET']
tenant,le,actor,actor2,foreign_tenant=uuid4(),uuid4(),uuid4(),uuid4(),uuid4()
all_perms=['supplychain.claims.read','supplychain.claims.create','supplychain.claims.investigate','supplychain.claims.decide','supplychain.claims.settle','supplychain.shipments.read','supplychain.carriers.read']
tests={}; row_tests={f'R{i:02d}':[] for i in list(range(1,19))+[21]}; fixture_state={'shipments':{},'carriersByShipment':{}}

def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
def token(perms=all_perms,who=actor,ten=tenant,legal=le,raw_payload=None,secret=SECRET):
    h=b64(b'{"alg":"HS256","typ":"JWT"}')
    if raw_payload is None: raw_payload=json.dumps({'sub':str(who),'tenant_id':str(ten),'legal_entity_id':str(legal),'actor_type':'tenant_user','permission':perms,'iss':ISS,'aud':AUD,'exp':int(time.time())+1800},separators=(',',':')).encode()
    p=b64(raw_payload);s=b64(hmac.new(secret.encode(),(h+'.'+p).encode(),hashlib.sha256).digest());return h+'.'+p+'.'+s
VALID=token()

def record(row,tid,ok,expected,actual,kind='controlled-policy'):
    tests[tid]={'row':row,'pass':bool(ok),'expected':expected,'actual':actual,'evidenceKind':kind};row_tests[row].append(tid)
def mongo(script):
    p=subprocess.run(['mongosh','--quiet',MONGO,'--eval',script],text=True,capture_output=True)
    if p.returncode: raise RuntimeError(p.stderr)
    return p.stdout.strip()
def dbjs(expr):return json.loads(mongo(f'JSON.stringify({expr})'))
def counts(ten=tenant,legal=le):
    q=f'{{TenantId:{json.dumps(str(ten))},LegalEntityId:{json.dumps(str(legal))}}}'
    return dbjs('{'+','.join(f'{k}:db.getSiblingDB({json.dumps(DB)}).{c}.countDocuments({q})' for k,c in [('claims','claims'),('receipts','claims_receipts'),('audit','claims_audit'),('outbox','claims_outbox')])+'}')
def delta(a,b):return {k:b[k]-a[k] for k in a}
def req(method,path,body=None,key=None,corr=None,perms=all_perms,who=actor,ten=tenant,legal=le,raw=None,content_type='application/json',tok=None,headers_extra=None,duplicate_headers=None,timeout=12):
    corr=corr if corr is not None else uuid4(); tok=tok if tok is not None else token(perms,who,ten,legal)
    headers={'Authorization':'Bearer '+tok,'X-Tenant-Id':str(ten),'X-Legal-Entity-Id':str(legal),'X-Correlation-Id':str(corr)}
    if key is not None:headers['Idempotency-Key']=key
    if raw is None and body is not None:raw=json.dumps(body,separators=(',',':')).encode()
    if raw is not None:headers['Content-Type']=content_type
    if headers_extra:headers.update(headers_extra)
    u=urllib.parse.urlsplit(API);c=http.client.HTTPConnection(u.hostname,u.port,timeout=timeout);c.putrequest(method,path)
    for k,v in headers.items():
        if v is not None:c.putheader(k,str(v))
    for k,vals in duplicate_headers or []:
        for v in vals:c.putheader(k,v)
    if raw is not None:c.putheader('Content-Length',str(len(raw)))
    c.endheaders(raw)
    try:r=c.getresponse(); data=r.read(); hs={k.lower():v for k,v in r.getheaders()}; status=r.status
    except Exception as e:c.close();return {'transportError':type(e).__name__+':'+str(e)}
    c.close()
    try:parsed=json.loads(data) if data else None
    except Exception:parsed=data.decode(errors='replace')
    return {'status':status,'headers':hs,'body':parsed,'requestSha256':hashlib.sha256(raw or b'').hexdigest()}
def error(r,status,code):
    try:return r['status']==status and r['body']['error']['code']==code and r['body']['contractVersion']=='v1' and r['body']['error']['correlationId']==r['headers']['x-correlation-id']
    except Exception:return False
def shipment(sid,status='Delivered',root=None,carrier='OMIT'):
    b={'shipmentId':str(sid),'shipmentNumber':'SHP-'+str(sid)[:8],'sourceDocumentId':'SO-E4','status':status,'loadId':None,'plannedShipAt':'2026-09-20T08:00:00Z','plannedDeliverAt':None,'actualDeliverAt':None,'sourceModule':'MOD-0141','sourceType':'SALES_ORDER','warehouseReferenceId':'WH-E4','shipToReference':'C-E4','lines':[],'pod':None,'contractVersion':'v1','lifecycleCorrelationId':str(root if root is not None else uuid4())}
    if carrier!='OMIT':b['carrierId']=None if carrier is None else str(carrier)
    return b
def carriers(cid,status='Active'):
    return {'items':[{'carrierId':str(cid),'carrierCode':'C-'+str(cid)[:6],'displayName':'Carrier','status':status,'supportedModes':['Road']}],'total':1,'contractVersion':'v1'}
def set_scenario(sid,ship,carrier_cfg=None,**opts):
    fixture_state['shipments'][str(sid)]={'status':opts.get('http_status',200),'body':ship,**{k:v for k,v in opts.items() if k in ('raw','delay','bodyAfter')}}
    if carrier_cfg is not None:fixture_state['carriersByShipment'][str(sid)]={'status':200,'body':carrier_cfg}
    STATE.write_text(json.dumps(fixture_state))
def create(sid,root,key,amount='10',carrier=None,evidence='OMIT',reason='DAMAGED',currency='USD',**kw):
    b={'shipmentId':str(sid),'reasonCode':reason,'claimedAmount':amount,'currency':currency}
    if carrier is not None:b['carrierId']=str(carrier)
    if evidence!='OMIT':b['evidenceReferenceIds']=evidence
    return req('POST','/api/shipment-bundle/claims',b,key,root,**kw)
def transition(cid,root,key,target,at='2026-09-21T10:00:00Z',approved='OMIT',resolution='OMIT',note='OMIT',**kw):
    b={'targetStatus':target,'occurredAt':at}
    if approved!='OMIT':b['approvedAmount']=approved
    if resolution!='OMIT':b['resolutionCode']=resolution
    if note!='OMIT':b['note']=note
    return req('POST',f'/api/shipment-bundle/claims/{cid}/transition',b,key,root,**kw)
def assert_status(row,tid,r,status,code=None,kind='controlled-policy'):
    ok=r.get('status')==status if code is None else error(r,status,code);record(row,tid,ok,{'status':status,'code':code},r,kind);return ok

# R01: all eight source states and zero-write rejects.
for i,status in enumerate(['Draft','Planned','Dispatched','InTransit','Delivered','Exception','Closed','Cancelled'],1):
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,status,root));before=counts();r=create(sid,root,f'e4-r01-{i}');after=counts();eligible=status in {'Dispatched','InTransit','Delivered','Exception','Closed'}
    ok=(r.get('status')==201 if eligible else error(r,422,'CLAIM_SHIPMENT_INELIGIBLE')) and (eligible or delta(before,after)=={'claims':0,'receipts':0,'audit':0,'outbox':0})
    record('R01',f'E4-R01-S{i:02d}',ok,{'eligible':eligible,'status':201 if eligible else 422,'zeroWriteIfRejected':True},{'response':r,'delta':delta(before,after)})

# R02: explicit carrier status/mismatch/incomplete/malformed/not-found. Every case captures real outbound HTTP to the fixture.
for i,status in enumerate(['Active','Suspended','Retired'],1):
    sid,root,cid=uuid4(),uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root,cid),carriers(cid,status));r=create(sid,root,f'e4-r02-ok-{i}',carrier=cid);assert_status('R02',f'E4-R02-C{i:02d}',r,201)
for suffix,ship_carrier,explicit,st,code in [('mismatch',uuid4(),uuid4(),422,'CLAIM_CARRIER_MISMATCH'),('null',None,uuid4(),422,'CLAIM_CARRIER_MISMATCH')]:
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root,ship_carrier),carriers(explicit));r=create(sid,root,'e4-r02-'+suffix,carrier=explicit);assert_status('R02','E4-R02-C04' if suffix=='mismatch' else 'E4-R02-C05',r,st,code)
sid,root,cid=uuid4(),uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root,'OMIT'),carriers(cid));assert_status('R02','E4-R02-C06',create(sid,root,'e4-r02-omit',carrier=cid),503,'CLAIM_REFERENCE_INCOMPLETE')
for n,field in enumerate(['carrierId','carrierCode','displayName','status','supportedModes'],7):
    sid,root,cid=uuid4(),uuid4(),uuid4();cb=carriers(cid);del cb['items'][0][field];set_scenario(sid,shipment(sid,'Delivered',root,cid),cb);assert_status('R02',f'E4-R02-C{n:02d}',create(sid,root,f'e4-r02-field-{field}',carrier=cid),502,'CLAIM_REFERENCE_INVALID')
sid,root,cid=uuid4(),uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root,cid),carriers(uuid4()));assert_status('R02','E4-R02-C12',create(sid,root,'e4-r02-absent',carrier=cid),404,'CLAIM_NOT_FOUND')

# R03 observation-time snapshot and no reread on replay/transition.
sid,root=uuid4(),uuid4();first=shipment(sid,'Delivered',root);after_ship=shipment(sid,'Cancelled',root);set_scenario(sid,first,bodyAfter=after_ship)
r=create(sid,root,'e4-r03-create');cid=r.get('body',{}).get('claimId'); log_before=Path(os.environ['CLAIMS_FIXTURE_LOG']).read_text().count(str(sid))
fixture_state['shipments'][str(sid)]['body']=after_ship;STATE.write_text(json.dumps(fixture_state))
rep=create(sid,root,'e4-r03-create');tr=transition(cid,root,'e4-r03-transition','Investigating') if cid else {}
log_after=Path(os.environ['CLAIMS_FIXTURE_LOG']).read_text().count(str(sid));snap=dbjs(f'db.getSiblingDB({json.dumps(DB)}).claims.findOne({{_id:{json.dumps(cid)}}},{{ReferenceSnapshot:1,_id:0}})') if cid else None
record('R03','E4-R03-O01',r.get('status')==201 and snap and snap['ReferenceSnapshot']['ShipmentStatus']=='Delivered',{'snapshotStatus':'Delivered'},{'response':r,'snapshot':snap})
record('R03','E4-R03-O02',rep.get('status')==201 and rep.get('body',{}).get('idempotentReplay') is True,{'replay':201},rep)
record('R03','E4-R03-O03',tr.get('status')==200,{'transition':200},tr)
record('R03','E4-R03-O04',log_before==log_after==1,{'shipmentReads':1},{'before':log_before,'after':log_after})

# R04/R21 reference faults and four-collection zero-write.
faults=[]
sid,root=uuid4(),uuid4();set_scenario(sid,{},http_status=404);faults.append(('F01',sid,root,404,'CLAIM_NOT_FOUND'))
sid,root=uuid4(),uuid4();set_scenario(sid,{},raw='{');faults.append(('F02',sid,root,502,'CLAIM_REFERENCE_INVALID'))
sid,root=uuid4(),uuid4();b=shipment(uuid4(),'Delivered',root);set_scenario(sid,b);faults.append(('F03',sid,root,502,'CLAIM_REFERENCE_INVALID'))
sid,root=uuid4(),uuid4();b=shipment(sid,'Delivered',root);del b['status'];set_scenario(sid,b);faults.append(('F04',sid,root,503,'CLAIM_REFERENCE_INCOMPLETE'))
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root),delay=6);faults.append(('F05',sid,root,503,'CLAIM_REFERENCE_UNAVAILABLE'))
for tid,sid,root,st,code in faults:
    before=counts();r=create(sid,root,'e4-r04-'+tid.lower());after=counts();ok=error(r,st,code) and delta(before,after)=={'claims':0,'receipts':0,'audit':0,'outbox':0};record('R04','E4-R04-'+tid,ok,{'status':st,'code':code,'zeroWrites':True},{'response':r,'delta':delta(before,after)})
# Separate connection refusal uses a second API phase and is reported by shell handoff, so this row remains pending until merged.

# R05 evidence wire/storage.
for idx,evidence in enumerate(['OMIT',[],['','e1','e1']],1):
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));r=create(sid,root,f'e4-r05-{idx}',evidence=evidence);cid=r.get('body',{}).get('claimId');stored=dbjs(f'db.getSiblingDB({json.dumps(DB)}).claims.findOne({{_id:{json.dumps(cid)}}},{{EvidenceReferenceIds:1,_id:0}})') if cid else None;want=[] if evidence=='OMIT' else evidence;record('R05',f'E4-R05-E{idx:02d}',r.get('status')==201 and stored and stored['EvidenceReferenceIds']==want,{'status':201,'stored':want},{'response':r,'stored':stored})
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));r=req('POST','/api/shipment-bundle/claims',{'shipmentId':str(sid),'reasonCode':'D','claimedAmount':'1','currency':'USD','evidenceReferenceIds':None},'e4-r05-null',root);assert_status('R05','E4-R05-E04',r,400,'INVALID_REQUEST')
record('R05','E4-R05-E05',all('/evidence' not in json.loads(x)['path'].lower() for x in Path(os.environ['CLAIMS_FIXTURE_LOG']).read_text().splitlines()),{'evidenceLookupCount':0},{'fixtureLog':os.environ['CLAIMS_FIXTURE_LOG']})

# Helpers for amount/lifecycle chains.
def new_claim(amount='250',key=None):
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));r=create(sid,root,key or 'new-'+str(uuid4()),amount=amount);return sid,root,r.get('body',{}).get('claimId'),r
def to_investigating(cid,root,prefix):return transition(cid,root,prefix+'-inv','Investigating')

# R06 amount boundaries and retention within this process.
for i,amount in enumerate(['-1','0','-0'],1):
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));assert_status('R06',f'E4-R06-A{i:02d}',create(sid,root,f'e4-r06-bad-{i}',amount=amount),422,'CLAIM_AMOUNT_INVALID')
for i,approved in enumerate([None,'-0.01','250.01'],4):
    _,root,cid,_=new_claim('250','e4-r06-new-'+str(i));to_investigating(cid,root,'e4-r06-'+str(i));r=transition(cid,root,'e4-r06-approve-'+str(i),'Approved',approved=approved);assert_status('R06',f'E4-R06-A{i:02d}',r,422,'CLAIM_APPROVAL_AMOUNT_INVALID')
for i,approved in enumerate(['0','-0','249.99','250'],7):
    _,root,cid,_=new_claim('250','e4-r06-new-ok-'+str(i));to_investigating(cid,root,'e4-r06-ok-'+str(i));r=transition(cid,root,'e4-r06-approve-ok-'+str(i),'Approved',approved=approved);assert_status('R06',f'E4-R06-A{i:02d}',r,200)
    if i==7 and cid:
        s=transition(cid,root,'e4-r06-settle','Settled',approved=None);c=transition(cid,root,'e4-r06-close','Closed');stored=dbjs(f'db.getSiblingDB({json.dumps(DB)}).claims.findOne({{_id:{json.dumps(cid)}}},{{ApprovedAmount:1,Status:1,_id:0}})');record('R06','E4-R06-A11',s.get('status')==200 and c.get('status')==200 and stored.get('ApprovedAmount')=='0',{'approvedAmount':'0','status':'Closed'},{'settle':s,'close':c,'stored':stored})
_,root,cid,_=new_claim();r=transition(cid,root,'e4-r06-nonapproved','Withdrawn',approved='1');assert_status('R06','E4-R06-A12',r,422,'CLAIM_APPROVED_AMOUNT_NOT_ALLOWED')

# R07 multiple claims and note/resolution audit retention; absence of finance collections.
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));created=[create(sid,root,'e4-r07-'+str(i),amount='999999999999999999999') for i in range(2)];record('R07','E4-R07-M01',all(x.get('status')==201 for x in created),{'statuses':[201,201]},created)
cid=created[0].get('body',{}).get('claimId');tr=transition(cid,root,'e4-r07-note','Investigating',resolution='',note='');audit=dbjs(f'db.getSiblingDB({json.dumps(DB)}).claims_audit.findOne({{ClaimId:{json.dumps(cid)},Version:2}},{{ResolutionCode:1,Note:1,_id:0}})') if cid else None;record('R07','E4-R07-M02',tr.get('status')==200 and audit=={'ResolutionCode':'','Note':''},{'emptyStringsRetained':True},{'response':tr,'audit':audit})
names=dbjs(f'db.getSiblingDB({json.dumps(DB)}).getCollectionNames()');finance=[x for x in names if any(w in x.lower() for w in ('finance','ledger','payment','stock'))];record('R07','E4-R07-M03',not finance,{'financeCollections':[]},finance)

# R08 current-process exact long value; restart belongs to Lane C.
longv='1234567890123456789012345678901234567890.1234567890123456789012345678901234567890';_,root,cid,r=new_claim(longv,'e4-r08-long');stored=dbjs(f'db.getSiblingDB({json.dumps(DB)}).claims.findOne({{_id:{json.dumps(cid)}}},{{ClaimedAmount:1,_id:0}})') if cid else None;lst=req('GET','/api/shipment-bundle/claims?shipmentId='+str(r.get('body',{}).get('shipmentId')),corr=uuid4());record('R08','E4-R08-P01',r.get('status')==201 and stored and stored['ClaimedAmount']==longv and any(x['claimedAmount']==longv for x in lst.get('body',{}).get('items',[])),{'exact':longv},{'create':r,'stored':stored,'list':lst})

# R09 lexical and currency matrix.
valid=[('000250.00','USD'),('0.0000000000000000000000000000000000000001','ZZZ'),('1.5','JPY')]
for i,(amount,currency) in enumerate(valid,1):
    _,_,_,r=new_claim(amount,'e4-r09-valid-'+str(i)) if currency=='USD' else (lambda sid,root:(sid,root,None,create(sid,root,'e4-r09-valid-'+str(i),amount=amount,currency=currency)))(uuid4(),uuid4())
    # For non-USD the lambda lacks a scenario; repair by explicit retry below when needed.
    if currency!='USD':
        sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));r=create(sid,root,'e4-r09-valid2-'+str(i),amount=amount,currency=currency)
    assert_status('R09',f'E4-R09-L{i:02d}',r,201)
invalid=['1e2','+1','1.','.1',' 1','١','0','-0']
for i,amount in enumerate(invalid,4):
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));r=create(sid,root,'e4-r09-invalid-'+str(i),amount=amount);st,code=(400,'INVALID_REQUEST') if i<10 else (422,'CLAIM_AMOUNT_INVALID');assert_status('R09',f'E4-R09-L{i:02d}',r,st,code)
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));raw=json.dumps({'shipmentId':str(sid),'reasonCode':'D','claimedAmount':1,'currency':'USD'}).encode();assert_status('R09','E4-R09-L12',req('POST','/api/shipment-bundle/claims',key='e4-r09-number',corr=root,raw=raw),400,'INVALID_REQUEST')
for i,currency in enumerate(['usd','USDD'],13):
    sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));assert_status('R09',f'E4-R09-L{i:02d}',create(sid,root,f'e4-r09-cur-{i}',currency=currency),400,'INVALID_REQUEST')

# R10 create fingerprint equivalence/conflict and root precedence.
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));base={'shipmentId':str(sid),'reasonCode':'A','claimedAmount':'250','currency':'USD'};orig=req('POST','/api/shipment-bundle/claims',key='e4-r10-create',corr=root,raw=json.dumps(base,separators=(',',':')).encode());reordered=req('POST','/api/shipment-bundle/claims',key='e4-r10-create',corr=root,raw=json.dumps(dict(reversed(list(base.items()))),separators=(',',':')).encode());assert_status('R10','E4-R10-I01',reordered,201)
changed=dict(base);changed['claimedAmount']='250.00';assert_status('R10','E4-R10-I02',req('POST','/api/shipment-bundle/claims',changed,'e4-r10-create',root),409,'IDEMPOTENCY_KEY_REUSED');assert_status('R10','E4-R10-I03',req('POST','/api/shipment-bundle/claims',changed,'e4-r10-create',uuid4()),409,'CLAIM_CORRELATION_MISMATCH')
sid2,root2=uuid4(),uuid4();set_scenario(sid2,shipment(sid2,'Delivered',root2));b={'shipmentId':str(sid2),'reasonCode':'A','claimedAmount':'1','currency':'USD'};o=req('POST','/api/shipment-bundle/claims',b,'e4-r10-null',root2);bnull=dict(b);bnull['carrierId']=None;n=req('POST','/api/shipment-bundle/claims',bnull,'e4-r10-null',root2);record('R10','E4-R10-I04',o.get('status')==201 and n.get('status')==201 and n.get('body',{}).get('idempotentReplay') is True,{'replay':True},{'original':o,'replay':n})
sid3,root3=uuid4(),uuid4();set_scenario(sid3,shipment(sid3,'Delivered',root3));b={'shipmentId':str(sid3),'reasonCode':'A','claimedAmount':'1','currency':'USD'};req('POST','/api/shipment-bundle/claims',b,'e4-r10-evidence',root3);b['evidenceReferenceIds']=[];r=req('POST','/api/shipment-bundle/claims',b,'e4-r10-evidence',root3);assert_status('R10','E4-R10-I05',r,201)
sid4,root4=uuid4(),uuid4();set_scenario(sid4,shipment(sid4,'Delivered',root4));create(sid4,root4,'e4-r10-array',evidence=['a','b']);assert_status('R10','E4-R10-I06',create(sid4,root4,'e4-r10-array',evidence=['b','a']),409,'IDEMPOTENCY_KEY_REUSED')

# R11-R13 permission and self-approval.
_,root,cid,_=new_claim('10','e4-r11-base');r=transition(cid,root,'e4-r11-createonly','Withdrawn',perms=['supplychain.claims.create']);assert_status('R11','E4-R11-P01',r,403,'FORBIDDEN')
r=transition(cid,root,'e4-r11-investigate','Withdrawn',perms=['supplychain.claims.investigate']);assert_status('R11','E4-R11-P02',r,200)
foreign_id=uuid4();r=transition(foreign_id,root,'e4-r11-foreign','Withdrawn',perms=['supplychain.claims.investigate']);assert_status('R11','E4-R11-P03',r,404,'CLAIM_NOT_FOUND')
_,root,cid,_=new_claim('10','e4-r12-rej');to_investigating(cid,root,'e4-r12-rej');transition(cid,root,'e4-r12-reject','Rejected');assert_status('R12','E4-R12-P01',transition(cid,root,'e4-r12-close','Closed',perms=['supplychain.claims.decide']),200)
_,root,cid,_=new_claim('10','e4-r12-set');to_investigating(cid,root,'e4-r12-set');transition(cid,root,'e4-r12-app','Approved',approved='1');transition(cid,root,'e4-r12-settle','Settled');assert_status('R12','E4-R12-P02',transition(cid,root,'e4-r12-close2','Closed',perms=['supplychain.claims.decide']),200)
_,root,cid,_=new_claim('10','e4-r12-deny');to_investigating(cid,root,'e4-r12-deny');transition(cid,root,'e4-r12-app2','Approved',approved='1');transition(cid,root,'e4-r12-settle2','Settled');assert_status('R12','E4-R12-P03',transition(cid,root,'e4-r12-denyclose','Closed',perms=['supplychain.claims.settle']),403,'FORBIDDEN')
_,root,cid,_=new_claim();assert_status('R12','E4-R12-P04',transition(cid,root,'e4-r12-open','Open',perms=['supplychain.claims.create']),422,'INVALID_CLAIM_TRANSITION')
_,root,cid,_=new_claim('10','e4-r13');to_investigating(cid,root,'e4-r13');assert_status('R13','E4-R13-P01',transition(cid,root,'e4-r13-createonly','Approved',approved='1',perms=['supplychain.claims.create']),403,'FORBIDDEN');assert_status('R13','E4-R13-P02',transition(cid,root,'e4-r13-decide','Approved',approved='1',perms=['supplychain.claims.decide']),200)

# R14 headers, identity, keys and query scope aliases.
assert_status('R14','E4-R14-H01',req('GET','/api/shipment-bundle/claims',corr=uuid4(),tok=token(secret='x'*32)),401,'UNAUTHENTICATED')
payload=('{'+'"sub":"'+str(actor)+'","sub":"'+str(actor2)+'","tenant_id":"'+str(tenant)+'","legal_entity_id":"'+str(le)+'","permission":["supplychain.claims.read"],"iss":"'+ISS+'","aud":"'+AUD+'","exp":'+str(int(time.time())+600)+'}').encode();assert_status('R14','E4-R14-H02',req('GET','/api/shipment-bundle/claims',corr=uuid4(),tok=token(raw_payload=payload)),403,'FORBIDDEN')
assert_status('R14','E4-R14-H03',req('GET','/api/shipment-bundle/claims',corr=uuid4(),headers_extra={'X-Tenant-Id':'bad'}),400,'INVALID_REQUEST')
assert_status('R14','E4-R14-H04',req('GET','/api/shipment-bundle/claims',corr=uuid4(),headers_extra={'X-Tenant-Id':str(uuid4())}),403,'FORBIDDEN')
for i,key in enumerate(['tenantid','LEGALENTITYID','tenant_ID','legal_ENTITY_id','X-TENANT-ID','x-LEGAL-entity-ID'],5):assert_status('R14',f'E4-R14-H{i:02d}',req('GET','/api/shipment-bundle/claims?'+urllib.parse.quote(key)+'=x',corr=uuid4()),400,'INVALID_REQUEST')
r=req('GET','/api/shipment-bundle/claims?ordinaryUnknown=x&tenantName=foreign',corr=UUID(int=0));record('R14','E4-R14-H11',r.get('status')==200 and r.get('headers',{}).get('x-correlation-id')==str(UUID(int=0)),{'status':200,'nilEcho':True},r)
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));assert_status('R14','E4-R14-H12',create(sid,root,'é'*129),400,'INVALID_REQUEST');assert_status('R14','E4-R14-H13',create(sid,root,'é'*128),201);sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));assert_status('R14','E4-R14-H14',create(sid,root,'comma,inside'),201)

# R15 precedence selections.
badbody=b'{}';assert_status('R15','E4-R15-O01',req('POST','/api/shipment-bundle/claims',key='x',corr='bad',raw=badbody,tok=token(secret='x'*32)),401,'UNAUTHENTICATED')
assert_status('R15','E4-R15-O02',req('POST','/api/shipment-bundle/claims',key='x',corr='bad',raw=badbody,perms=[]),403,'FORBIDDEN')
assert_status('R15','E4-R15-O03',req('POST','/api/shipment-bundle/claims',key='x',corr='bad',raw=badbody),400,'INVALID_REQUEST')
assert_status('R15','E4-R15-O04',req('POST','/api/shipment-bundle/claims',key='x',corr=uuid4(),raw=badbody,content_type='text/plain'),415,'UNSUPPORTED_MEDIA_TYPE')
assert_status('R15','E4-R15-O05',req('POST','/api/shipment-bundle/claims',key='x',corr=uuid4(),raw=badbody,perms=['supplychain.claims.create']),400,'INVALID_REQUEST')

# R16 transition replay/conflict/root precedence.
_,root,cid,_=new_claim('10','e4-r16-new');body={'targetStatus':'Investigating','occurredAt':'2026-09-21T10:11:12.00+03:00'};a=req('POST',f'/api/shipment-bundle/claims/{cid}/transition',body,'e4-r16-transition',root);b=req('POST',f'/api/shipment-bundle/claims/{cid}/transition',body,'e4-r16-transition',root);record('R16','E4-R16-R01',a.get('status')==200 and b.get('status')==200 and b.get('body',{}).get('idempotentReplay') is True,{'original':200,'replay':True},{'original':a,'replay':b})
changed=dict(body);changed['occurredAt']='2026-09-21T07:11:12Z';assert_status('R16','E4-R16-R02',req('POST',f'/api/shipment-bundle/claims/{cid}/transition',changed,'e4-r16-transition',root),409,'IDEMPOTENCY_KEY_REUSED');assert_status('R16','E4-R16-R03',req('POST',f'/api/shipment-bundle/claims/{cid}/transition',changed,'e4-r16-transition',uuid4()),409,'CLAIM_CORRELATION_MISMATCH')

# R17 all 49 HTTP lifecycle pairs using scoped fixture aggregates.
statuses=['Open','Investigating','Approved','Rejected','Settled','Closed','Withdrawn'];legal={('Open','Investigating'),('Open','Withdrawn'),('Investigating','Approved'),('Investigating','Rejected'),('Approved','Settled'),('Rejected','Closed'),('Settled','Closed')}; pair_results=[]
for si,source in enumerate(statuses):
  for ti,target in enumerate(statuses):
    cid,root=uuid4(),uuid4();doc={'_id':str(cid),'TenantId':str(tenant),'LegalEntityId':str(le),'IsDeleted':False,'CreatedAt':{'$date':'2026-09-21T10:00:00Z'},'Version':1,'CreatedBy':str(actor),'ClaimNumber':'CLM-'+cid.hex,'ShipmentId':str(uuid4()),'CarrierId':None,'ReasonCode':'FIXTURE','ClaimedAmount':'10','Currency':'USD','ApprovedAmount':'1' if source in ('Approved','Settled','Closed') else None,'EvidenceReferenceIds':[],'Status':source,'CorrelationRoot':str(root),'LastEventId':str(uuid4()),'ReferenceSnapshot':None}
    js=json.dumps(doc).replace('{"$date": "2026-09-21T10:00:00Z"}','new Date("2026-09-21T10:00:00Z")');mongo(f'db.getSiblingDB({json.dumps(DB)}).claims.insertOne({js})')
    approved='1' if target=='Approved' else 'OMIT';r=transition(cid,root,f'e4-r17-{si}-{ti}',target,approved=approved);want=200 if (source,target) in legal else 422;ok=r.get('status')==want and (want==200 or error(r,422,'INVALID_CLAIM_TRANSITION'));tid=f'E4-R17-{si*7+ti:02d}';record('R17',tid,ok,{'source':source,'target':target,'status':want},{'response':r});pair_results.append(ok)

# R18 exact observed safe error/header matrix summary. Individual producing tests above are rechecked here.
codes={}
for tid,t in tests.items():
    a=t['actual'];r=a.get('response',a) if isinstance(a,dict) else {}
    if isinstance(r,dict) and isinstance(r.get('body'),dict) and isinstance(r['body'].get('error'),dict): codes[r['body']['error']['code']]=r
expected_messages={'INVALID_REQUEST':'Request schema or context is invalid.','UNAUTHENTICATED':'Authentication is required.','FORBIDDEN':'The requested operation is not permitted.','CLAIM_NOT_FOUND':'Claim or referenced resource was not found.','UNSUPPORTED_MEDIA_TYPE':'Content type is not supported.','CLAIM_SHIPMENT_INELIGIBLE':'Shipment is not eligible for a claim.','CLAIM_CARRIER_MISMATCH':'Carrier does not match the shipment.','CLAIM_AMOUNT_INVALID':'Claimed amount must be greater than zero.','CLAIM_APPROVAL_AMOUNT_INVALID':'Approved amount must be between zero and the claimed amount.','CLAIM_APPROVED_AMOUNT_NOT_ALLOWED':'Approved amount is not allowed for this action.','INVALID_CLAIM_TRANSITION':'Claim transition is not allowed.','CLAIM_CORRELATION_MISMATCH':'Correlation does not match the lifecycle root.','IDEMPOTENCY_KEY_REUSED':'Idempotency key was used for a different request.','CLAIM_REFERENCE_INVALID':'Reference response is invalid.','CLAIM_REFERENCE_INCOMPLETE':'Required reference data is unavailable.','CLAIM_REFERENCE_UNAVAILABLE':'Reference service is unavailable.'}
for i,(code,msg) in enumerate(expected_messages.items(),1):
    r=codes.get(code);ok=bool(r) and r['body']['error']['message']==msg and r['body']['error']['correlationId']==r['headers'].get('x-correlation-id') and r['body'].get('contractVersion')=='v1' and (code!='UNAUTHENTICATED' or r['headers'].get('www-authenticate')=='Bearer');record('R18',f'E4-R18-E{i:02d}',ok,{'code':code,'message':msg,'correlationParity':True},r or {'missing':code})

# R21 controlled root modes, mismatch precedence, nil preservation.
for i,mode in enumerate(['missing','null','empty','malformed'],1):
    sid,root=uuid4(),uuid4();b=shipment(sid,'Delivered',root)
    if mode=='missing':del b['lifecycleCorrelationId']
    elif mode=='null':b['lifecycleCorrelationId']=None
    elif mode=='empty':b['lifecycleCorrelationId']=''
    else:b['lifecycleCorrelationId']='bad'
    set_scenario(sid,b);st,code=(502,'CLAIM_REFERENCE_INVALID') if mode=='malformed' else (503,'CLAIM_REFERENCE_INCOMPLETE');assert_status('R21',f'E4-R21-R{i:02d}',create(sid,root,'e4-r21-'+mode),st,code)
sid,root=uuid4(),uuid4();set_scenario(sid,shipment(sid,'Delivered',root));assert_status('R21','E4-R21-R05',create(sid,uuid4(),'e4-r21-mismatch'),409,'CLAIM_CORRELATION_MISMATCH')
sid=uuid4();nil=UUID(int=0);set_scenario(sid,shipment(sid,'Delivered',nil));assert_status('R21','E4-R21-R06',create(sid,nil,'e4-r21-nil'),201)

row_verdict={}
for row,ids in row_tests.items():
    fail=[x for x in ids if not tests[x]['pass']]
    row_verdict[row]='FAIL' if fail else ('PARTIAL' if row=='R08' else 'PASS')
out={'status':'FAIL' if any(v=='FAIL' for v in row_verdict.values()) else 'PARTIAL','source':'AUTH-05 immutable 97-path snapshot','api':API,'mongo':MONGO,'database':DB,'scope':{'tenantId':str(tenant),'legalEntityId':str(le)},'rows':row_verdict,'tests':tests,'countsFinal':counts(),'fixtureLog':os.environ['CLAIMS_FIXTURE_LOG'],'notes':['Controlled fixture evidence is not live producer uptake.','R08 process-boundary persistence/capacity/unknown-commit remains Lane C.','R19-R20/R22-R26 not assessed.']}
OUT.write_text(json.dumps(out,indent=2));print(json.dumps({'status':out['status'],'rows':row_verdict,'tests':len(tests),'failed':[k for k,v in tests.items() if not v['pass']]}));raise SystemExit(1 if out['status']=='FAIL' else 0)
