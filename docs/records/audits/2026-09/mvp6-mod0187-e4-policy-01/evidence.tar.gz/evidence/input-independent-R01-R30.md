# Independent R01–R30 acceptance matrix

`PASS` means the literal controlling row was independently satisfied at its stated boundary. `PARTIAL` means useful independent evidence passed, but one or more required observables remain unexecuted at the required E4/process boundary. No `PARTIAL` row is included in an all-green summary.

| Row | Verdict | Independent evidence and remaining exact acceptance |
|---|---|---|
| R01 | PARTIAL | Core covers the eight-state policy; live HTTP exercised Delivered only. Exact 8-status E4 matrix remains open. |
| R02 | PARTIAL | Core covers carrier omission/status/mismatch rules. Actual Carrier list wire requests and all status/missing-field cases remain open. |
| R03 | PARTIAL | Real Shipment snapshot persisted and replay avoided writes; change-after-read observation-time scenario remains open at E4. |
| R04 | PARTIAL | Live connection refusal gave 503 and 0/0/0/0; full 404/malformed/identity/incomplete/timeout E4 matrix remains open. |
| R05 | PARTIAL | Live create/list/transition bodies passed; complete omission/null/duplicate/order retention matrix remains component-level. |
| R06 | PARTIAL | Exact decimal text crossed HTTP/Mongo; complete approve-zero/bounds/retention/restart matrix remains component-level. |
| R07 | PARTIAL | Eight different keys proved no one-Claim-per-Shipment constraint; full resolution/note retention and finance-absence row is not fully E4. |
| R08 | PARTIAL | Capacity/rollback tests passed in core; long coefficient two-process restart and unknown-commit boundary remain open. |
| R09 | PARTIAL | Changed lexical payload conflict passed live; the full lexical rejection/retention matrix remains component-level. |
| R10 | PARTIAL | Identical replay and changed payload passed live; all lexical time/amount/order/null variants and wrong-root precedence remain open at E4. |
| R11 | PARTIAL | Open→Investigating and missing action permission passed live; exact Withdrawn/grant/foreign-scope cases remain component-level. |
| R12 | PARTIAL | Lifecycle/grant cases pass in core; required close/settle/Open-target live HTTP cases remain open. |
| R13 | PARTIAL | Signed actors and a missing action grant were live; self-approval permutations remain component-level. |
| R14 | PARTIAL | Tenant mismatch and missing/malformed bearer were live; duplicate identity, optional-scope and header/key/query matrix remains component-level. |
| R15 | PARTIAL | Signed context/header enforcement passed selected live cases; full precedence and wrong-root+changed-payload E4 matrix remains open. |
| R16 | PARTIAL | Create original replay, changed payload conflict and restart replay passed; transition replay and wrong-root precedence remain open at E4. |
| R17 | PARTIAL | Exact 49-pair lifecycle policy passes core; the controlling row requires all pairs via real HTTP. |
| R18 | PARTIAL | Live 200/201/401/403/409/503 shapes passed; the complete declared status/error/header matrix was not replayed live. |
| R19 | PARTIAL | Unique Mongo receipt index and eight-way same-key race passed; two-target/same-key and required 20-way race remain open. |
| R20 | PARTIAL | Actor/scope/receipt durability passes core and restart; revoked-grant/different-actor/closed-soft-delete cases remain open at E4. |
| R21 | PARTIAL | Real Shipment endpoint and authoritative root uptake passed; missing/null/empty/malformed/mismatch root cases remain component-level. |
| R22 | PARTIAL | Collision and atomicity tests pass core; no independent live forced definite collision was run. |
| R23 | PARTIAL | Eight different-key and eight same-key live races passed. The literal row requires 20 concurrent requests. |
| R24 | PARTIAL | Same-key create convergence passed live and approve/reject CAS passes core; live transition race/loser observations remain open. |
| R25 | PARTIAL | Live dependency refusal zero-write plus core distinct-stage rollback/lost-response passed; independent process-boundary failpoint and unknown-commit/restart proof remain open. |
| R26 | PARTIAL | Live counts stayed stable and outbox stayed Pending; exact event timestamp/causation/payload fields remain component-level. |
| R27 | PASS | No Claims worker/publisher/transport registration; actual Claims outbox remained Pending through restart; no delivery claim. |
| R28 | PASS | Exact 47 Claims paths were present in the verified 97-entry source binding; Program.cs/Returns/shared bytes were unchanged by VER. |
| R29 | PASS | Fresh restore/build, DLL hashes, process PIDs/commands, HTTP/DB, fixed DB + fresh tenants, restart and cleanup are archived. |
| R30 | PASS | Published YAML/annex and DEV/VER/owner authority hashes matched; live responses remained wire `v1`; no CT/rollout/version-consent claim. |

Summary: **4 PASS, 26 PARTIAL, 0 FAIL**. Overall verdict: **PARTIAL**.

