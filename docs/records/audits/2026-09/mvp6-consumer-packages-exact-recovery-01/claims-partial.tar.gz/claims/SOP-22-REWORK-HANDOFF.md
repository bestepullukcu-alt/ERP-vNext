# SOP §22 — MOD-0187 Claims candidate evidence rework

**Verdict: PASS for the four candidate-evidence findings only (E1/E2).** This handoff is a successor package; the prior candidate and all repository/canonical files remain unchanged. It is not runtime acceptance, publication, pack promotion, JWT authorization, Mongo persistence evidence, or consumer uptake.

## Scope and authority

The work is limited to V01–V04 from the independent Claims candidate report. Approved D187 semantics are consumed as recorded in `semantics-candidate.md`; no new business rule was introduced. Any unapproved owner/contract decision remains a gate.

## Finding → correction → evidence

| Finding | Correction | Evidence |
|---|---|---|
| V01 permission/fingerprint checks were literal equalities | `rework-model.py` evaluates permission and lexical amount/time fingerprint functions against independent oracle cases; mutation witnesses fail when permission or normalization is changed | `rework-results.json`, V01-PERM-1..5, V01-FP-1..3, MUTANT-permission, MUTANT-fingerprint |
| V02 root variants only checked status-key presence | Executable evaluator covers missing, null, empty, malformed, valid-same, valid-different and valid-different-payload, with exact HTTP status/code and precedence | `rework-results.json`, V02-ROOT-missing/null/empty/malformed/same/different/different-payload and MUTANT-root-bypass |
| V03 semantics were unexercised | Model scenarios cover approved amount retention through lifecycle, tenant/LE/operation/target receipt scope, duplicate claims with distinct keys, and unknown-commit recovery; all are explicitly E1/E2 model evidence | `rework-results.json`, V03-AMOUNT-RETENTION, V03-RECEIPT-SCOPE, V03-DUPLICATE-CLAIM-DIFFERENT-KEY, V03-UNKNOWN-COMMIT-RECOVERY |
| V04 lacked exact R01–R30 linkage | Complete decision → annex/OpenAPI pointer → test ID → result crosswalk | `r01-r30-crosswalk.json` and `.md` |

## Results

`python3 rework-model.py` produced **40 tests, 40 passed, 0 failed**. Mutation witnesses are negative controls and all rejected the intentionally wrong behavior. Lifecycle fixture inventory is **49 pairs: 7 allowed (HTTP 200) and 42 rejected (HTTP 422)**. The unchanged candidate patch applies cleanly to the recorded baseline and produces a byte-identical candidate YAML (`PATCH_APPLY=PASS`).

The root evaluator records the approved precedence: missing/null/empty → 503 `CLAIM_REFERENCE_INCOMPLETE`; malformed → 502 `CLAIM_REFERENCE_INVALID`; valid different root → 409 `CLAIM_CORRELATION_MISMATCH`; valid same root → accepted; changed payload with same root → 409. No write, persistence, or producer backfill is inferred.

## Manifest and hashes

See `manifest.json`. The inherited candidate hashes are patch `d503b149806492f583943c19a229135c535175ba8c02c9746db3503aec0d56c6`, candidate YAML `412b6cd7119be0ecf4aa3cbf8267abd4ac560f978838187556313cb342d866e0`, baseline `93c696e2fba13dbc8fbfcf2cd1ae0ae0bd93cd9d0935b3ee743229e810163571`. Rework files are hash-listed in the manifest.

## Explicit limits and remaining gates

No production HTTP, Mongo transaction, JWT/RBAC middleware, real outbox, restart, or consumer rollout was run. The model cannot prove persistence, wire behavior, or uptake. R01–R30 rows marked `ANNEX-BOUND`, `PROCESS GATE`, or `CANDIDATE ONLY` remain claims about the approved candidate semantics, not runtime evidence. Canonical publication, guard activation, pack promotion, and DEV/VER GO remain outside this work.

**Source writer status:** complete for this candidate-only rework; outputs are immutable under `/private/tmp/mvp6-claims-candidate-rework-01`.
