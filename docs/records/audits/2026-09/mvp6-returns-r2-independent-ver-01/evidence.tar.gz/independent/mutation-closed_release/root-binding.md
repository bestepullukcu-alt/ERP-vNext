# Exact Root R2 dependency — not publication/uptake

- `shipment-bundle-2.0.0-root-r2-candidate.yaml` SHA256 `dab5a2f9974283e2404a29a7fb8ed07a77ae8ed843929b1c7b4546c5615dd7cb`
- `semantics-r2.md` SHA256 `fceac091e75a4407210c80b81ca6b6757cc7199d4e09546dda39f3f8271c269b`

Source: /private/tmp/mvp6-root-candidate-reconstruct-r2-01/; permanent root archive: docs/records/audits/2026-09/mvp6-root-candidate-reconstruct-r2-01/root-r2-candidate.tar.gz. Read-only copies included in root-dependency. Root info.version2.0.0, CANDIDATE revision R2, wirev1; not old2.1.0/91d505. Root schema is optional nullable UUID and accepts nil. Consumer additionally rejects unavailable root for create; no successful create from missing/null. No root patch merged; combined publication/composition requires separate VER and release decisions.
