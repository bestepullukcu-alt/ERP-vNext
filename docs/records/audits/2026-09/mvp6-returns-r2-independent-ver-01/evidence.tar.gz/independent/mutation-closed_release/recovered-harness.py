from pathlib import Path
import json,yaml,copy,hashlib,subprocess,tempfile,re
from fractions import Fraction
from datetime import datetime,timezone
from jsonschema import Draft202012Validator,FormatChecker,RefResolver
for family,folder in [('returns','mvp6-returns-consumer-candidate-m1wjuxx1'),('claims','mvp6-claims-consumer-candidate-nl5wzkxj')]:
 O=Path('/private/tmp')/folder;b=yaml.safe_load((O/'baseline.openapi.yaml').read_text());c=yaml.safe_load((O/'shipment-bundle.consumer-candidate.yaml').read_text());checks=[]
 def ck(n,v):
  checks.append({'name':n,'pass':bool(v)})
  assert v,n
 isr=family=='returns';name='Return' if isr else 'Claim';a='/'+family;t=a+'/{'+name.lower()+'Id}/transition'
 rest=copy.deepcopy(c)
 for p in [a,t]:rest['paths'][p]=b['paths'][p]
 ck('all non-owned content identical',rest==b);ck('shared schemas exact',c['components']==b['components'])
 for p in [a,t]:
  for method in c['paths'][p]:
   old=b['paths'][p][method];new=c['paths'][p][method];ck(p+method+' request schema identical',new.get('requestBody')==old.get('requestBody'));ck(p+method+' keeps success statuses',set(old['responses'])<=set(new['responses']))
 refs=[];examples=[];resolver=RefResolver.from_schema(c);fc=FormatChecker()
 def walk(x):
  if isinstance(x,dict):
   if '$ref' in x:
    y=c
    for k in x['$ref'][2:].split('/'):y=y[k.replace('~1','/').replace('~0','~')]
    refs.append(x['$ref'])
   if 'schema' in x:
    values=([x['example']] if 'example' in x else [])+[v['value'] for v in x.get('examples',{}).values() if 'value' in v]
    for v in values:
     errors=list(Draft202012Validator(x['schema'],resolver=resolver,format_checker=fc).iter_errors(v));examples.append({'pass':not errors,'errors':[e.message for e in errors]})
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(c);ck('refs resolved',len(refs)>0);ck('all examples valid',all(v['pass'] for v in examples))
 schema=c['components']['schemas']['Create'+name+'Command'];valid=copy.deepcopy(c['paths'][a]['post']['requestBody']['content']['application/json']['example']);validator=Draft202012Validator(schema,resolver=resolver,format_checker=fc)
 for key,value in [('evidenceReferenceIds',None),('shipmentId','bad'),('unexpectedScope','x')]:
  x=copy.deepcopy(valid);x[key]=value;ck('negative schema '+key,not validator.is_valid(x))
 x=copy.deepcopy(valid);x['evidenceReferenceIds']=['','e','e'];ck('opaque evidence accepts empty duplicates',validator.is_valid(x))
 # Executable design oracles, not production concurrency or persistence.
 decimal=lambda s: Fraction(s) if re.fullmatch(r'-?[0-9]+(?:\.[0-9]+)?',s) else None
 ck('lossless huge amount',decimal('123456789012345678901234567890.1234567890123456789')==Fraction(1234567890123456789012345678901234567890123456789,10**19))
 for bad in ['1e2','+1','.1','1.',' 1','١']:ck('lexical negative '+bad,decimal(bad) is None)
 if isr:
  edges={('Requested','Authorized'),('Requested','Rejected'),('Authorized','InTransit'),('Authorized','Cancelled'),('InTransit','Received'),('Received','Dispositioned'),('Dispositioned','Closed')};states=b['components']['schemas']['ReturnStatus']['enum']
  ck('no invented InTransit Cancelled',('InTransit','Cancelled') not in edges)
  counted={'Requested','Authorized','InTransit','Received','Dispositioned','Closed'}
  ck('closed counted', 'Closed' in counted);ck('release only rejection cancellation',set(states)-counted=={'Rejected','Cancelled'})
  ck('numeric fingerprint',decimal('1.0')==decimal('1.00'))
  ck('instant fingerprint',datetime.fromisoformat('2026-09-20T09:00:00+00:00')==datetime.fromisoformat('2026-09-20T12:00:00+03:00'))
  ck('cap6plus6 rejected',decimal('6')+decimal('6')>decimal('10'));ck('cap4plus6 accepted',decimal('4')+decimal('6')<=decimal('10'))
  ck('manual disposition whitespace allowed',len(' ')>=1)
 else:
  edges={('Open','Investigating'),('Open','Withdrawn'),('Investigating','Approved'),('Investigating','Rejected'),('Approved','Settled'),('Rejected','Closed'),('Settled','Closed')};states=b['components']['schemas']['ClaimStatus']['enum']
  perms={'Investigating':'investigate','Withdrawn':'investigate','Approved':'decide','Rejected':'decide','Settled':'settle','Closed':'decide','Open':'create'}
  ck('withdrawn investigate not create',perms['Withdrawn']=='investigate');ck('closed decide',perms['Closed']=='decide');ck('self approval requires decide',perms['Approved'] not in {'create'})
  ck('lexical amount differs','250'!='250.00');ck('lexical time differs','2026-09-20T09:00:00Z'!='2026-09-20T12:00:00+03:00')
  for s,good in [('0',True),('-0',True),('250',True),('250.01',False),('-1',False)]:ck('approved bound '+s,(0<=decimal(s)<=250)==good)
  for s in ['0','-0','-1']:ck('claimed positive '+s,not decimal(s)>0)
  ck('tiny positive',decimal('0.'+'0'*40+'1')>0)
  for cur,good in [('ZZZ',True),('JPY',True),('usd',False),('USDD',False)]:ck('currency '+cur,bool(re.fullmatch('[A-Z]{3}',cur))==good)
  matrix=json.loads((O/'error-matrix.json').read_text());ck('reconciled payload code','IDEMPOTENCY_KEY_REUSED' in matrix['transitionClaim']['codes']['409']);ck('reconciled lifecycle code','INVALID_CLAIM_TRANSITION' in matrix['transitionClaim']['codes']['422'])
 pairs=[{'from':s,'to':z,'status':200 if (s,z) in edges else 422} for s in states for z in states];ck('exact seven frozen arrows',sum(x['status']==200 for x in pairs)==7)
 (O/'lifecycle-fixtures.json').write_text(json.dumps(pairs,indent=2))
 # Root fixtures cannot establish live uptake. Check candidate declarations and shared frozen schema absence.
 ck('root producer not patched','lifecycleCorrelationId' not in c['components']['schemas']['ShipmentDetail']['allOf'][1]['properties'])
 matrix=json.loads((O/'error-matrix.json').read_text());create=matrix['create'+name]['codes'];ck('root missing null503 declared',str(503) in create);ck('malformed502 declared',str(502) in create);ck('root mismatch409 declared',str(409) in create)
 T=O/'apply-check';p=T/'docs/analysis/contracts/shipment-bundle.openapi.yaml';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/'baseline.openapi.yaml').read_bytes());z=subprocess.run(['patch','--fuzz=0','-p1','-i',str(O/'candidate.patch')],cwd=T,capture_output=True,text=True);ck('patch applies exactly',z.returncode==0 and p.read_bytes()==(O/'shipment-bundle.consumer-candidate.yaml').read_bytes())
 (O/'tests.json').write_text(json.dumps({'checks':checks,'pass':len(checks),'examples':len(examples),'refs':len(refs),'examples_results':examples,'evidence':'Schema and design oracles only. No actual persistence/CAS/HTTP/JWT/consumer uptake.'},indent=2));print(family,len(checks),len(examples))
