# MVP6-RETURNS-CANDIDATE-RECONSTRUCT-R2-VER-01 — independent candidate VER
Role read-only-auditor/testing-agent; candidate-only E1/E2. Start after writer-complete; no runtime authority.
Read AGENTS/CT SOP, actual D186 user approval, README, authority, normative annex, crosswalk, harness review and manifests.
Extract permanent tar to a new disposable directory, verify every SHA256; source/repo/other lanes read-only.
Verify baseline93c696…3571, exact new candidate/patch and Root R2 pins; neither historical2.1.0 nor old CT PASS substitutes.
Apply candidate.patch to exact baseline, compare bytes; AST diff only Returns2paths/3operations. Shared schemas/non-Returns
and canonical lifecycle unchanged. Run python3 verify_r2.py in your copy; do not run recovered-harness.py blindly.
Independently challenge model and fixtures:64pairs7edges; forbidden InTransit→Cancelled; numeric arbitrary precision and
submicro instant equivalence; root missing/null/malformed/nil/same/different; receipt root-before-payload; authz-before-replay;
entitlement release/count/cap, manual Received, opaque refs, Pending/no publisher. Inspect full normative policies, identify
unmodeled constraints rather than extending PASS to them. Test negative controls must fail on intentionally wrong behavior.
Root schema/semantics hashes in root-binding.md must match read-only snapshots and producer lane output. No published seam
or producer/consumer uptake assumed. Check patch metadata inheritance warning vs actual candidate authority.
Report PASS/REWORK/PARTIAL, command exits, exact input/output hashes and limits. No candidate fixes in VER; separate rework.
No canonical/runtime/guard/pack/Program/git changes, release consent, promotion or DEV GO. SOP22 in unique temp.
