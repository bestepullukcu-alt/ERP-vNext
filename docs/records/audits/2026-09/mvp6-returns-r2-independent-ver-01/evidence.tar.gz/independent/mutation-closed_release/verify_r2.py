from pathlib import Path
import json,yaml,copy,re,subprocess,hashlib
from jsonschema import Draft202012Validator,FormatChecker,RefResolver
from returns_model import *
P=Path(__file__).parent; b=yaml.safe_load((P/'baseline.openapi.yaml').read_text());c=yaml.safe_load((P/'shipment-bundle.returns-r2.yaml').read_text());checks=[]
def ck(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
rest=copy.deepcopy(c)
for p in ['/returns','/returns/{returnId}/transition']:rest['paths'][p]=b['paths'][p]
ck('non-Returns unchanged including all shared components',rest==b)
for p in ['/returns','/returns/{returnId}/transition']:
 for m,op in b['paths'][p].items():ck('request unchanged '+p+m,op.get('requestBody')==c['paths'][p][m].get('requestBody'))
resolver=RefResolver.from_schema(c);fc=FormatChecker();stats={'refs':0,'examples':0}
def walk(x):
 if isinstance(x,dict):
  if '$ref' in x:
   y=c
   for k in x['$ref'][2:].split('/'):y=y[k.replace('~1','/').replace('~0','~')]
   stats['refs']+=1
  if 'schema' in x:
   for v in ([x['example']] if 'example' in x else [])+[a['value'] for a in x.get('examples',{}).values() if 'value' in a]:
    ck('example '+str(stats['examples']),not list(Draft202012Validator(x['schema'],resolver=resolver,format_checker=fc).iter_errors(v)));stats['examples']+=1
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(c)
# Independent lifecycle oracle extracted from current canonical prose, not model constant.
desc=b['paths']['/returns/{returnId}/transition']['post']['description'];oracle=set()
for start,ends in re.findall(r'(\w+)->([\w|]+)',desc):
 for end in ends.split('|'):oracle.add((start,end))
states=b['components']['schemas']['ReturnStatus']['enum'];fixtures=[]
for s in states:
 for t in states:
  expected=200 if (s,t) in oracle else 422;actual=200 if (s,t) in EDGES else 422;ck('lifecycle '+s+' '+t,actual==expected);fixtures.append({'from':s,'to':t,'expected':expected})
ck('canonical64 pairs7edges',len(fixtures)==64 and len(oracle)==7);ck('forbidden InTransit Cancelled',('InTransit','Cancelled') not in EDGES)
root='aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa';other='bbbbbbbb-1111-4111-8111-aaaaaaaaaaaa';nil=str(uuid.UUID(int=0))
for present,value,request,expected in [(False,None,root,503),(True,None,root,503),(True,'',root,502),(True,'bad',root,502),(True,17,root,502),(True,root,root,200),(True,root,other,409),(True,nil,nil,200)]:ck('root '+repr((present,value,request)),root_status(present,value,request)[0]==expected)
body={'shipmentId':root,'lines':[{'shipmentLineNumber':'1','quantity':'6.0','uomId':'EA'}]};source={'root':root,'status':'Delivered','lines':{'1':{'quantity':'10','uomId':'EA'}}};scope=('tenant','le');st=Store()
ck('create6',st.mutate(scope,'a',body,root,source,grants={'create'})[0]==201)
ck('serialized race second6 fails',st.mutate(scope,'b',body,root,source,grants={'create'})==(422,'RETURN_QUANTITY_EXCEEDED'))
rep=copy.deepcopy(body);rep['lines'][0]['quantity']='6.00';w=st.writes
ck('numeric replay',st.mutate(scope,'a',rep,root,grants={'create'})==(201,'REPLAY') and st.writes==w)
rep['lines'][0]['quantity']='5';ck('payload conflict',st.mutate(scope,'a',rep,root,grants={'create'})==(409,'IDEMPOTENCY_KEY_REUSED'))
ck('root precedes payload',st.mutate(scope,'a',rep,other,grants={'create'})==(409,'CORRELATION_ROOT_MISMATCH'))
ck('authz before replay',st.mutate(scope,'a',body,root,grants=set())[0]==403)
t={'targetStatus':'Rejected','occurredAt':'2026-09-20T12:00:00.123456789+03:00'}
ck('reject releases',st.mutate(scope,'rej',t,root,target='a',grants={'transition','authorize'})[0]==200 and list(st.used.values())==[0])
ck('release replay once',st.mutate(scope,'rej',t,root,target='a',grants={'transition','authorize'})==(200,'REPLAY') and list(st.used.values())==[0])
u=copy.deepcopy(t);u['occurredAt']='2026-09-20T09:00:00.123456789Z';ck('exact instant replay',st.mutate(scope,'rej',u,root,target='a',grants={'transition','authorize'})==(200,'REPLAY'))
u['occurredAt']='2026-09-20T09:00:00.123456788Z';ck('submicro precision conflict',st.mutate(scope,'rej',u,root,target='a',grants={'transition','authorize'})[1]=='IDEMPOTENCY_KEY_REUSED')
for state in ['Draft','InTransit','Delivered','Closed']:
 ss=copy.deepcopy(source);ss['status']=state;ck('eligibility '+state,Store().mutate(scope,'c',body,root,ss,grants={'create'})[0]==(201 if state in ['Delivered','Closed'] else 422))
for q in ['0','-1']:
 bad=copy.deepcopy(body);bad['lines'][0]['quantity']=q;ck('nonpositive '+q,Store().mutate(scope,'c',bad,root,source,grants={'create'})[0]==422)
f=Store();ck('fault rollback',f.mutate(scope,'a',body,root,source,grants={'create'},fault=True)[0]==503 and f.writes==0 and not f.used)
f=Store();ck('unknown commit not zero',f.mutate(scope,'a',body,root,source,grants={'create'},unknown=True)[0]==503 and f.writes==1);ck('unknown receipt recovery',f.mutate(scope,'a',body,root,grants={'create'})==(201,'REPLAY') and f.writes==1)
ck('closed counted and only release states',set(states)-COUNTED=={'Rejected','Cancelled'})
ck('arbitrary precision',quantity('123456789012345678901234567890.00000000000000000000001')>quantity('123456789012345678901234567890'))
# negative control for mutated lifecycle oracle
ck('mutation witness added forbidden edge',(EDGES|{('InTransit','Cancelled')})!=oracle)
# Additional real evaluator cases; setup creates no external HTTP client.
a=Store();a.mutate(scope,'a',body,root,source,grants={'create'})
for target,grant in [('Authorized','authorize'),('InTransit','transit'),('Received','receive'),('Dispositioned','disposition'),('Closed','close')]:
 cmd={'targetStatus':target,'occurredAt':'2026-09-20T09:00:00Z','inventoryTransactionReferenceId':''}
 if target=='Dispositioned':
  ck('disposition required',a.mutate(scope,'disp-fail',cmd,root,target='a',grants={'transition',grant})==(422,'DISPOSITION_REQUIRED'));cmd['dispositionCode']=' '
 ck('manual lifecycle '+target,a.mutate(scope,target,cmd,root,target='a',grants={'transition',grant})[0]==200)
ck('closed retains entitlement',list(a.used.values())==[6]);ck('HTTP zero model',a.external_calls=={'inventory':0,'warehouse':0});ck('Pending only',all(e['status']=='Pending' for e in a.pending))
bad=copy.deepcopy(body);bad['lines'][0]['uomId']='BOX';ck('UoM mismatch',Store().mutate(scope,'a',bad,root,source,grants={'create'})==(422,'RETURN_UOM_MISMATCH'))
bad=copy.deepcopy(body);bad['lines']*=2;ck('duplicate lines',Store().mutate(scope,'a',bad,root,source,grants={'create'})==(422,'DUPLICATE_RETURN_LINE'))
bad=copy.deepcopy(body);bad['lines'].append({'shipmentLineNumber':'2','quantity':'1','uomId':'EA'});a=Store();ck('multiline failure no partial commit',a.mutate(scope,'a',bad,root,source,grants={'create'})[0]==404 and not a.used and not a.records)
a=Store();small=copy.deepcopy(body);small['lines'][0]['quantity']='4';ck('4 plus6 first',a.mutate(scope,'a',small,root,source,grants={'create'})[0]==201);ck('4 plus6 second',a.mutate(scope,'b',body,root,source,grants={'create'})[0]==201)
validator=Draft202012Validator(c['components']['schemas']['CreateReturnCommand'],resolver=resolver,format_checker=fc)
valid=copy.deepcopy(c['paths']['/returns']['post']['requestBody']['content']['application/json']['example'])
for key,value in [('shipmentId','bad'),('evidenceReferenceIds',None),('extraScope','x')]:
 bad=copy.deepcopy(valid);bad[key]=value;ck('schema negative '+key,not validator.is_valid(bad))
valid['evidenceReferenceIds']=['','x','x'];ck('opaque evidence permissive',validator.is_valid(valid))
T=P/'apply-check';target=T/'docs/analysis/contracts/shipment-bundle.openapi.yaml';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((P/'baseline.openapi.yaml').read_bytes())
z=subprocess.run(['patch','--fuzz=0','-p1','-i',str(P/'candidate.patch')],cwd=T,capture_output=True,text=True);ck('exact patch application',z.returncode==0 and target.read_bytes()==(P/'shipment-bundle.returns-r2.yaml').read_bytes())
(P/'lifecycle-fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n');(P/'tests.json').write_text(json.dumps({'checks':checks,'stats':stats,'evidence':'NEW E1/E2 model/schema only; no actual HTTP JWT transaction concurrency or producer uptake'},indent=2)+'\n');print('PASS',len(checks),stats)
