# Recovered harness independent inspection
Recovered-harness.py has no verified historical hash; its measured hash is in this NEW manifest only.
Do not run it in place: hardcoded old absolute Returns/Claims directories and output writes are present.
Insufficient checks: canonical edges hardcoded, quantity capacity arithmetic rather than store mutation,
instant datetime precision limited to microseconds, root only tests response-status presence, fixed-string assertions.
It is preserved as historical untrusted reference, not acceptance oracle. New verify_r2.py tests a separate executable
returns_model.py against canonical lifecycle prose, numeric/instant equivalence and receipt/state behaviors.
293 fresh checks include174 schema examples,64 lifecycle pairs and targeted behavioral/negative controls.
279 refs resolved. Root dependency adds6 fresh UUID/null format cases, both dependency hashes verified.
Evidence limits: model simulates serialized cap race and rollback/unknown commit, not database transactions or parallel race.
Source snapshot drift/required-field classification, full header/JWT precedence, number collision, event causation and
all write-position fault injection are normative annex requirements not exhaustively modeled. Independent VER must
report these limits and expand isolated evidence if required, without claiming current model proves runtime behavior.
