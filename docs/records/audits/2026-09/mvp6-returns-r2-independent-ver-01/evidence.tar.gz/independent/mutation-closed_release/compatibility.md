# Unpublished candidate policy
Returns R2 package is CANDIDATE. YAML info.version2.0.0/FROZEN bytes remain inherited baseline metadata solely to
avoid modifying shared metadata in a Returns-only patch; this file has NO canonical/frozen authority. It is identified
by new package manifest/hash. Release version/status disposition belongs to single composition/publication owner.
Only two Returns path blocks/three operations changed. Shared Decimal/Error, non-Returns components/paths/webhooks,
requests and lifecycle preserved. Added response branches/grants/business restrictions require exact release consent;
not automatically backward compatible. Root R2 dependency is pinned but unmerged and unpublished.
New artifact/model results never inherit previous CT acceptance. No runtime, warehouse ingress, stock writes, uptake,
consumer release consent, guard activation, pack promotion or DEV GO established.
