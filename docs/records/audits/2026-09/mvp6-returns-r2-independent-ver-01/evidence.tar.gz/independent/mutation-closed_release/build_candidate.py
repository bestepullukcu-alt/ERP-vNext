from pathlib import Path
import yaml,json,copy,difflib,hashlib
P=Path(__file__).parent;raw=(P/'baseline.openapi.yaml').read_text();b=yaml.safe_load(raw);c=copy.deepcopy(b)
assert hashlib.sha256(raw.encode()).hexdigest()=='93c696e2fba13dbc8fbfcf2cd1ae0ae0bd93cd9d0935b3ee743229e810163571'
codes=json.loads((P/'params.json').read_text());root='aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa';matrix={}
for path,method,statuses in [('/returns','get',[200,400,401,403,404,500,503]),('/returns','post',[201,400,401,403,404,409,415,422,500,502,503]),('/returns/{returnId}/transition','post',[200,400,401,403,404,409,415,422,500,503])]:
 op=c['paths'][path][method];op['description']=op.get('description','')+'\nUnpublished Returns R2 candidate. Normative semantics-candidate.md governs module-specific validation, numeric/instant replay, entitlement, manual receiving and inherited Shipment root. No Inventory/Warehouse HTTP, worker or publisher.'
 op['parameters'] += [{'name':n,'in':'header','required':True,'schema':{'type':'string','format':'uuid'},'description':'Validation against trusted JWT scope only; exact lexical/duplicate rules and precedence in normative annex.'} for n in ['X-Tenant-Id','X-Legal-Entity-Id']]
 responses={};branches={}
 for st in statuses:
  headers={'X-Correlation-Id':{'description':'Current valid request trace; rejection-only generated trace if invalid/missing. Never a replacement business root.','schema':{'type':'string','format':'uuid'}}}
  if st<300:
   response=copy.deepcopy(op['responses'][str(st)]);response['headers']=headers
   media=response['content']['application/json'];ex=media.get('example',{})
   for item in [ex]+ex.get('items',[]):
    if 'rmaNumber' in item:item['rmaNumber']='RMA-'+item['returnId'].replace('-','').upper()
   if method=='post':
    original=media.pop('example');replay=copy.deepcopy(original);replay['idempotentReplay']=True;media['examples']={'committed':{'value':original},'replay':{'value':replay}}
  else:
   cs=list(codes[str(st)])
   if method=='get':cs=['PERSISTENCE_UNAVAILABLE'] if st==503 else cs[:1]
   elif path.endswith('/transition'):
    if st==404:cs=['RETURN_NOT_FOUND']
    if st==409:cs=['CORRELATION_ROOT_MISMATCH','IDEMPOTENCY_KEY_REUSED']
    if st==422:cs=['INVALID_RETURN_TRANSITION','DISPOSITION_REQUIRED']
    if st==503:cs=['PERSISTENCE_UNAVAILABLE']
   elif st==422:cs=[x for x in cs if x not in ['INVALID_RETURN_TRANSITION','DISPOSITION_REQUIRED']]
   branches[str(st)]=cs
   if st==401:headers['WWW-Authenticate']={'schema':{'type':'string','const':'Bearer'}}
   response={'description':'Returns-specific branch; normative annex defines precedence.','headers':headers,'content':{'application/json':{'schema':{'$ref':'#/components/schemas/Error'},'examples':{code:{'value':{'error':{'code':code,'message':code.replace('_',' '),'correlationId':root},'contractVersion':'v1'}} for code in cs}}}}
  responses[str(st)]=response
 op['responses']=responses;matrix[op['operationId']]={'statuses':statuses,'codes':branches}
new=raw
for path in ['/returns','/returns/{returnId}/transition']:
 start=new.index('  '+path+':\n');nxt=new.find('\n  /',start+3);end=nxt+1 if nxt!=-1 else new.index('webhooks:',start)
 block=yaml.safe_dump({path:c['paths'][path]},sort_keys=False,allow_unicode=True,width=110);block=''.join('  '+l if l.strip() else l for l in block.splitlines(True));new=new[:start]+block+new[end:]
assert yaml.safe_load(new)==c
(P/'shipment-bundle.returns-r2.yaml').write_text(new)
(P/'candidate.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(True),new.splitlines(True),fromfile='a/docs/analysis/contracts/shipment-bundle.openapi.yaml',tofile='b/docs/analysis/contracts/shipment-bundle.openapi.yaml')))
(P/'error-matrix.json').write_text(json.dumps(matrix,indent=2)+'\n')
