# D186 approved design → candidate → evidence
| Decision | Pointer / normative section | Fresh evidence |
|---|---|---|
|01 eligibility/lines/UoM|createReturn; annex D18601/02|eligibility positive/negative, duplicate, UoM, nonpositive model|
|02 entitlement|createReturn/transitionReturn; annex01/02|6+6 reject,4+6 accept, reject/replay release once, Closed retains; serialized model only|
|03 manual Received|transitionReturn; annex03/04|model requires transition+receive, full permitted path; physical receiving unproven|
|04 Inventory boundary|TransitionReturnCommand unchanged; annex03/04|opaque empty ref, whitespace disposition; model no clients. Runtime HTTP0 unmeasured|
|05 root/error/replay|all3 operations; annex05/common|root variants,root-before-payload,authz-before-replay,numeric and submicro instant, schema errors/examples|
|06 storage/events|annex06|modeled rollback/unknown recovery/Pending; real DB/restart/number-collision/event causation not proven|

Canonical ReturnStatus has8 states;64 source×target cases,7 edges. No InTransit→Cancelled.
