from pathlib import Path
import yaml,json,hashlib,subprocess,shutil,sys
from jsonschema import Draft202012Validator,FormatChecker
p=Path(__file__).parent;pkg=p/'returns-r2';results={}
r=yaml.safe_load((pkg/'root-dependency/shipment-bundle-2.0.0-root-r2-candidate.yaml').read_text())
s=r['components']['schemas']['ShipmentDetail']['allOf'][1]['properties']['lifecycleCorrelationId']
v=Draft202012Validator(s,format_checker=FormatChecker())
results['root6']=[{'value':x['value'],'expected':x['valid'],'actual':v.is_valid(x['value'])} for x in json.loads((pkg/'root-schema-checks.json').read_text())]
model=(pkg/'returns_model.py').read_text()
mutations={
'forbidden_edge':("EDGES={", "EDGES={('InTransit','Cancelled'),"),
'nil_lost':("if not present or value is None:","if not present or value is None or value=='00000000-0000-0000-0000-000000000000':"),
'lexical_quantity':("if k=='quantity':return quantity(v)","if k=='quantity':return v"),
'no_release':("self.used[k]-=q","self.used[k]-=0"),
'no_uom_check':("if l['uomId']!=src['uomId']:","if False:"),
'no_payload_conflict':("if old['fp']!=fp:","if False:"),
'external_call':("self.external_calls={'inventory':0,'warehouse':0}","self.external_calls={'inventory':1,'warehouse':0}"),
'closed_release':("'Dispositioned','Closed'}","'Dispositioned'}"),
}
results['mutations']=[]
for name,(old,new) in mutations.items():
 assert old in model,name
 d=p/('mutation-'+name);shutil.copytree(pkg,d,ignore=shutil.ignore_patterns('apply-check','__pycache__'))
 (d/'returns_model.py').write_text(model.replace(old,new,1))
 z=subprocess.run([sys.executable,str(d/'verify_r2.py')],capture_output=True,text=True)
 (d/'mutation.stdout').write_text(z.stdout);(d/'mutation.stderr').write_text(z.stderr)
 results['mutations'].append({'mutation':name,'exit':z.returncode,'caught':z.returncode!=0,'last_error':z.stderr.splitlines()[-1] if z.stderr else ''})
results['root_hashes']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (pkg/'root-dependency').iterdir()}
(p/'independent-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
