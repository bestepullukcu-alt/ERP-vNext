"""Candidate-only semantic model. No HTTP/JWT/database implementation."""
import re,uuid,json,copy
from fractions import Fraction
from datetime import datetime,timezone,timedelta
DEC=re.compile(r'-?[0-9]+(?:\.[0-9]+)?\Z');UID=re.compile(r'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\Z')
EDGES={('InTransit','Cancelled'),('Requested','Authorized'),('Requested','Rejected'),('Authorized','InTransit'),('Authorized','Cancelled'),('InTransit','Received'),('Received','Dispositioned'),('Dispositioned','Closed')}
COUNTED={'Requested','Authorized','InTransit','Received','Dispositioned','Closed'}
GRANTS={'Authorized':'authorize','Rejected':'authorize','InTransit':'transit','Cancelled':'cancel','Received':'receive','Dispositioned':'disposition','Closed':'close'}
def quantity(s):
 if not isinstance(s,str) or not DEC.fullmatch(s):raise ValueError('decimal')
 return Fraction(s)
def instant(s):
 m=re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(\.\d+)?(Z|[+-]\d\d:\d\d)',s)
 if not m:raise ValueError('instant')
 dt=datetime.fromisoformat(m[1]+m[3].replace('Z','+00:00')).astimezone(timezone.utc);delta=dt-datetime(1970,1,1,tzinfo=timezone.utc)
 return Fraction(delta.days*86400+delta.seconds)+Fraction(m[2] or '0')
def fingerprint(body):
 def norm(v,k=''):
  if isinstance(v,dict):
   d=dict(v)
   if k=='':
    for n in ['inventoryTransactionReferenceId','dispositionCode','note']:d.setdefault(n,None)
    if 'shipmentId' in d:d.setdefault('evidenceReferenceIds',[])
   return tuple(sorted((key,norm(val,key)) for key,val in d.items()))
  if isinstance(v,list):return tuple(norm(x) for x in v)
  if k=='quantity':return quantity(v)
  if k=='occurredAt':return instant(v)
  if k in ['shipmentId','returnId'] and v is not None:return uuid.UUID(v)
  return v
 return norm(body)
def root_status(present,value,request):
 if not present or value is None:return 503,'RETURN_SHIPMENT_ROOT_UNAVAILABLE'
 if not isinstance(value,str) or not UID.fullmatch(value):return 502,'RETURN_SHIPMENT_ROOT_INVALID'
 if uuid.UUID(value)!=uuid.UUID(request):return 409,'CORRELATION_ROOT_MISMATCH'
 return 200,None
class Store:
 def __init__(self):self.receipts={};self.used={};self.records={};self.writes=0;self.external_calls={'inventory':0,'warehouse':0};self.pending=[]
 def mutate(self,scope,key,body,root,source=None,target=None,grants=(),fault=False,unknown=False):
  op='transition' if target else 'create';required={'transition',GRANTS.get(body.get('targetStatus'),'transition')} if target else {'create'}
  if not required<=set(grants):return 403,'INVALID_REQUEST'
  rid=(*scope,op,target,key);fp=fingerprint(body)
  if rid in self.receipts:
   old=self.receipts[rid]
   if old['root']!=root:return 409,'CORRELATION_ROOT_MISMATCH'
   if old['fp']!=fp:return 409,'IDEMPOTENCY_KEY_REUSED'
   return old['status'],'REPLAY'
  snapshot=copy.deepcopy(self.__dict__)
  if target:
   rec=self.records.get((*scope,target))
   if rec is None:return 404,'RETURN_NOT_FOUND'
   if rec['root']!=root:return 409,'CORRELATION_ROOT_MISMATCH'
   to=body['targetStatus'];fr=rec['state']
   if (fr,to) not in EDGES:return 422,'INVALID_RETURN_TRANSITION'
   if to=='Dispositioned' and (not isinstance(body.get('dispositionCode'),str) or len(body['dispositionCode'])<1):return 422,'DISPOSITION_REQUIRED'
   if fr in COUNTED and to not in COUNTED:
    for k,q in rec['items']:self.used[k]-=q
   rec['state']=to;status=200
  else:
   lines=body['lines']
   if len({l['shipmentLineNumber'] for l in lines})!=len(lines):return 422,'DUPLICATE_RETURN_LINE'
   if any(quantity(l['quantity'])<=0 for l in lines):return 422,'INVALID_RETURN_QUANTITY'
   rs=root_status('root' in source,source.get('root'),root)
   if rs[0]!=200:return rs
   if source['status'] not in {'Delivered','Closed'}:return 422,'SHIPMENT_NOT_RETURNABLE'
   items=[]
   for l in lines:
    src=source['lines'].get(l['shipmentLineNumber'])
    if src is None:return 404,'SHIPMENT_LINE_NOT_FOUND'
    if l['uomId']!=src['uomId']:return 422,'RETURN_UOM_MISMATCH'
    k=(*scope,body['shipmentId'],l['shipmentLineNumber']);q=quantity(l['quantity'])
    if self.used.get(k,0)+q>quantity(src['quantity']):return 422,'RETURN_QUANTITY_EXCEEDED'
    items.append((k,q))
   for k,q in items:self.used[k]=self.used.get(k,0)+q
   target=key;self.records[(*scope,target)]={'state':'Requested','root':root,'items':items};status=201
  self.receipts[rid]={'fp':fp,'root':root,'status':status};self.writes+=1;self.pending.append({'root':root,'status':'Pending'})
  if fault:self.__dict__=snapshot;return 503,'PERSISTENCE_UNAVAILABLE'
  if unknown:return 503,'PERSISTENCE_UNAVAILABLE' # committed but response unknown; retry recovers receipt
  return status,None
