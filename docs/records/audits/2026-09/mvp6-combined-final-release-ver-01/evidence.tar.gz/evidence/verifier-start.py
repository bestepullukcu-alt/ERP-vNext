import pathlib,tempfile,json,hashlib,tarfile,subprocess,shutil
R=pathlib.Path('/Users/natig/Projects/ERP-vNext-recovery'); P=R/'docs/records/audits/2026-09/mvp6-combined-final-release-pack-01'; C=R/'docs/records/audits/2026-09/mvp6-r2-combined-release-candidate-01'; W=pathlib.Path(tempfile.mkdtemp(prefix='mvp6-final-independent-ver-',dir='/private/tmp')); print(W); pathlib.Path('/private/tmp/final-independent-location').write_text(str(W))
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records={}
def checkmanifest(base,file):
 n=0
 for l in file.read_text().splitlines():
  h,p=l.split(None,1); p=p.lstrip('*'); assert H(base/p)==h,(p,h,H(base/p)); records[str((base/p).resolve())]=h;n+=1
 return n
counts={'outer':checkmanifest(P,P/'SHA256SUMS')}
for name,pack in [('author',P),('prior-ver',R/'docs/records/audits/2026-09/mvp6-combined-candidate-ver-01')]:
 dest=W/name;dest.mkdir()
 with tarfile.open(pack/'evidence.tar.gz') as t:
  for m in t.getmembers(): assert not m.name.startswith('/') and '..' not in pathlib.Path(m.name).parts and not m.issym() and not m.islnk()
  t.extractall(dest)
 manifest=pack/'evidence-manifest.sha256';counts[name]=checkmanifest(dest/'evidence',manifest)
 records[str(pack/'evidence.tar.gz')]=H(pack/'evidence.tar.gz')
(W/'manifest-results.json').write_text(json.dumps(counts,indent=2))
A=W/'applied';(A/'docs/analysis/contracts').mkdir(parents=True)
base=R/'docs/analysis/contracts/shipment-bundle.openapi.yaml'; assert H(base)=='93c696e2fba13dbc8fbfcf2cd1ae0ae0bd93cd9d0935b3ee743229e810163571'
shutil.copy2(base,A/base.relative_to(R));records[str(base)]=H(base)
x=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(P/'publication.patch')],cwd=A,text=True,capture_output=True);(W/'patch.log').write_text(x.stdout+x.stderr);assert x.returncode==0
manifest=json.loads((P/'publication-manifest.json.txt').read_text());assert len(manifest)==4
assert sorted(str(p.relative_to(A)) for p in A.rglob('*') if p.is_file())==sorted(x['path'] for x in manifest)
for row in manifest: assert H(A/row['path'])==row['sha256']==H(P/'publication'/row['path'])
# Preserve exact inspected repo bytes, not broad concurrent-lane claims.
for p in [P/'publication.patch',P/'candidate-to-final.patch',C/'shipment-bundle-combined-candidate.yaml',R/'tests/architecture/TenantArchitecture.ArchitectureTests/DocsPathGuardTests.cs']: records[str(p)]=H(p)
(W/'input-pins.json').write_text(json.dumps(records,indent=2));(W/'git-preflight.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=R,text=True)+subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True)+subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True))
