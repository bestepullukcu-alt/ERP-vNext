exec(open('/private/tmp/final-independent-location').read() and '');import pathlib,json,hashlib,sys,re,copy,subprocess
W=pathlib.Path(pathlib.Path('/private/tmp/final-independent-location').read_text());R=pathlib.Path('/Users/natig/Projects/ERP-vNext-recovery');P=R/'docs/records/audits/2026-09/mvp6-combined-final-release-pack-01';C=R/'docs/records/audits/2026-09/mvp6-r2-combined-release-candidate-01';F=W/'applied/docs/analysis/contracts';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,'/private/tmp/mvp6-combined-final-release-q16pebui/tooldeps')
import yaml,openapi_spec_validator,jsonschema
mapping={'shipment-bundle.openapi.yaml':'shipment-bundle-combined-candidate.yaml','shipment-root-semantics-v3.0.0.md':'shipment-root-semantics-candidate.md','returns-semantics-v3.0.0.md':'returns-semantics-candidate.md','claims-semantics-v3.0.0.md':'claims-semantics-r2.md'}
edits=json.loads((W/'author/evidence/metadata-path-transformations.json').read_text());proof=[]
for a,b in mapping.items():
 text=(F/a).read_text()
 for edit in edits[a][::-1]:
  assert text.count(edit['to'])==edit['count'];text=text.replace(edit['to'],edit['from'])
 assert text.encode()==(C/b).read_bytes();proof.append({'final':a,'candidate':b,'candidateSha256':H(C/b),'inverseExact':True})
assert H(C/'shipment-bundle-combined-candidate.yaml')=='d763b571a1c6b88cbfadc56af2c51da1c0009589e3b82bcbe122329b17213c88'
d=yaml.safe_load((F/'shipment-bundle.openapi.yaml').read_text());old=yaml.safe_load((C/'shipment-bundle-combined-candidate.yaml').read_text());assert d['components']==old['components'] and d['webhooks']==old['webhooks'];errors=list(openapi_spec_validator.OpenAPIV31SpecValidator(d).iter_errors());assert not errors
refs=[];examples=[]
resolver=jsonschema.RefResolver.from_schema(d)
def traverse(x,path='$'):
 if isinstance(x,dict):
  if '$ref' in x:
   ref=x['$ref'];assert ref.startswith('#/');v=d
   for k in ref[2:].split('/'):v=v[k.replace('~1','/').replace('~0','~')]
   refs.append({'at':path,'ref':ref})
  if 'schema' in x:
   vals=([x['example']] if 'example' in x else [])+[z['value'] for z in x.get('examples',{}).values() if isinstance(z,dict) and 'value' in z]
   for val in vals:
    jsonschema.Draft202012Validator(x['schema'],resolver=resolver,format_checker=jsonschema.FormatChecker()).validate(val);examples.append(path)
  for k,v in x.items():traverse(v,path+'/'+k)
 elif isinstance(x,list):
  for n,v in enumerate(x):traverse(v,path+'/'+str(n))
traverse(d)
links=set(re.findall(r'[A-Za-z][A-Za-z0-9.-]*\.md',(F/'shipment-bundle.openapi.yaml').read_text()));assert len(links)==5
for link in links:
 p=F/link
 if not p.exists():assert H(P/'publication/docs/analysis/contracts'/link)==H(R/'docs/analysis/contracts'/link)
neg=[]
for name,mutate in [('bad-version',lambda x:x.update(openapi='bad')),('missing-title',lambda x:x['info'].pop('title'))]:
 x=copy.deepcopy(d);mutate(x);assert list(openapi_spec_validator.OpenAPIV31SpecValidator(x).iter_errors());neg.append(name)
# independently inspect each raw provenance line using the production regex
au=json.loads((P/'authority-binding-candidate.json.txt').read_text());live=json.loads((R/'docs/reference/architecture/docs-path-authority.json').read_text());r2=json.loads((R/'docs/records/audits/2026-09/mvp6-guard-payload-path-disposition-r2/authority-candidate.json.txt').read_text());assert len(live['sealedInputs'])==17 and len(au['sealedInputs'])==22;assert au['sealedInputs'][:17]==live['sealedInputs'];assert au['sealedInputs']==r2['sealedInputs']
seals=[]
for s in au['sealedInputs']:
 assert H(R/s['path'])==s['sha256']; assert H(R/s['provenancePath'])==s['provenanceSha256'];line=(R/s['provenancePath']).read_text().splitlines()[s['provenanceLine']-1];assert re.search('`'+re.escape(s['path'])+r':\d+`; baseline SHA256 `'+s['sha256']+'`',line)
 seals.append({'path':s['path'],'sha256':s['sha256'],'provenance':s['provenancePath'],'line':s['provenanceLine'],'lineText':line})
assert au['status']=='UNAPPROVED';assert au['decision']['sha256']==H(P/'guard-owner-decision-draft.json.txt')
used=set()
for s in au['sealedInputs']:
 assert s['kind'] in ('active-tool','historical-data');assert bool(s['targets'])==(s['kind']=='active-tool');used.update(s['targets'])
assert used=={t['path'] for t in au['canonicalTargets']}
for t in au['canonicalTargets']:
 p=W/'applied'/t['path'];assert H(p if p.exists() else R/t['path'])==t['sha256']
(W/'checks.json').write_text(json.dumps({'verdict':'PASS','inverse':proof,'openapiErrors':0,'validator':openapi_spec_validator.__version__,'refs':len(refs),'examples':len(examples),'links':sorted(links),'negativeControls':neg,'historicalSeals':17,'totalSeals':22,'models':'not rerun; pinned prior independent archive unchanged'},indent=2));(W/'refs.json').write_text(json.dumps(refs,indent=2));(W/'examples.json').write_text(json.dumps(examples,indent=2));(W/'seals.json').write_text(json.dumps(seals,indent=2));print((W/'checks.json').read_text())
