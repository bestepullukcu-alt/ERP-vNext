using System.Text.Json;using System.Text;using System.Security.Cryptography;
using var doc=JsonDocument.Parse(File.ReadAllBytes(args[0]));
var payload=doc.RootElement.GetProperty("canonicalTargets").GetRawText()+"\n"+doc.RootElement.GetProperty("sealedInputs").GetRawText();
var bytes=Encoding.UTF8.GetBytes(payload);File.WriteAllBytes(args[1],bytes);
Console.WriteLine(Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());Console.WriteLine(bytes.Length);
