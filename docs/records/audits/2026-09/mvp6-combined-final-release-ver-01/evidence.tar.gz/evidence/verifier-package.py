from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess,datetime
R=Path('/Users/natig/Projects/ERP-vNext-recovery');P=R/'docs/records/audits/2026-09/mvp6-combined-final-release-pack-01';W=Path(Path('/private/tmp/final-independent-location').read_text());O=R/'docs/records/audits/2026-09/mvp6-combined-final-release-ver-01';O.mkdir(exist_ok=False);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();E=W/'fresh-evidence';E.mkdir()
assert (W/'independent-payload.txt').read_bytes()==(P/'guard-payload.txt').read_bytes();assert H(W/'independent-payload.txt')=='85154a3e3368bfe187447bde269d0041a5863f3ef8b57b8e4397de97635cb270'
for n in ['manifest-results.json','patch.log','input-pins.json','git-preflight.txt','checks.json','refs.json','examples.json','seals.json','reader.log','independent-payload.txt']:shutil.copy2(W/n,E/n)
for n in ['start','checks','package']:shutil.copy2('/private/tmp/final-independent-'+n+'.py',E/('verifier-'+n+'.py'))
shutil.copytree(W/'reader',E/'reader',ignore=shutil.ignore_patterns('obj','bin'))
shutil.copytree(W/'applied',E/'applied');shutil.copy2(P/'candidate-to-final.patch',E/'reviewed-delta.patch');shutil.copy2(P/'publication.patch',E/'publication.patch');shutil.copy2(P/'authority-binding-candidate.json.txt',E/'authority-input.json.txt');shutil.copy2(W/'author/evidence/metadata-path-transformations.json',E/'reviewed-metadata-transformations.json')
pins=json.loads((W/'input-pins.json').read_text());unchanged=[]
for path,h in pins.items():assert H(Path(path))==h;unchanged.append((path,h))
(E/'inspected-input-no-change.tsv').write_text('path\tsha256\tend_matches\n'+''.join(f'{p}\t{h}\ttrue\n' for p,h in unchanged))
for rel in ['tests/architecture/TenantArchitecture.ArchitectureTests/DocsPathGuardTests.cs','docs/records/decisions/2026-09/mvp6-guard-complete-disposition-owner-approval-01.json','docs/records/audits/2026-09/mvp6-guard-approval-validation-01/SOP-22.md','docs/records/audits/2026-09/mvp6-guard-payload-path-disposition-r2/README.md','docs/records/audits/2026-09/mvp6-combined-candidate-ver-01/SOP-22.md']:
 dest=E/'inspected'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dest)
(E/'commands-and-exits.txt').write_text('''Fresh independent verifier commands (2026-09-20):
python3 /private/tmp/final-independent-start.py -> initial exit1: verifier assumed archive root; actual archive prefix evidence/. Corrected verifier only; retry exit0 in unique dc9t24cs workspace. No input changed.
patch --batch --fuzz=0 -p1 -i <final-pack>/publication.patch (disposable baseline) -> exit0, four actual outputs.
python3 /private/tmp/final-independent-checks.py -> exit0; checks.json records actual results. LibreSSL urllib3/RefResolver deprecation warnings only; no external schema access required.
dotnet run --project <workspace>/reader/reader.csproj -- <final-pack>/authority-binding-candidate.json.txt <workspace>/independent-payload.txt -> exit0; reader.log contains CSSM warning followed by correct payload hash and11185bytes.
No model rerun; prior independent376-file manifest rehashed. No production ReadAuthority/full guard execution, no synthetic fixture approval or stamping.
''')
shutil.copy2(P/'PUBLICATION-MANIFEST.sha256',O/'FINAL-HASHES.sha256');shutil.copy2(W/'checks.json',O/'fresh-results.json.txt')
manifest=json.loads((P/'publication-manifest.json.txt').read_text());table='\n'.join('|`'+x['path']+'`|`'+x['sha256']+'`|' for x in manifest)
report=f'''# MVP6-COMBINED-FINAL-RELEASE-VER-01 — SOP §22

Date:2026-09-20. Independent verifier `/root/final_release_independent_ver` did not author the final package. **PASS — bounded E1/E2 final proposal consistency; publication/activation HELD.** This report grants no approval.

Branch `feature/mvp6-logistics`; HEAD `4a8d4d4b339528a88e6220fb8402e5a2c771136c`. Existing dirty/concurrent work is preserved; preflight archived. Disposable `{W}`. Owned changes only this report directory and independent disposable workspace.

## Exact final proposal pins

|Proposed publication file|SHA256|
|---|---|
{table}

Publication patch `944a228d076807d643fa1ce714a982aab2e8438e064aea3479a90b4e11b75396`. Baseline YAML `93c696e2fba13dbc8fbfcf2cd1ae0ae0bd93cd9d0935b3ee743229e810163571`; three annex additions. Four-file patch actually applied with fuzz0 in disposable baseline; complete output file-set and all four hashes match. Loads/Carrier annexes are unchanged dependencies, not publication additions.

## Fresh tests and compatibility

Outer27-file manifest, final-author archive and prior independent archive manifests were individually rehashed (exact counts in manifest-results.json). Prior verifier's candidate pin `d763b571a1c6b88cbfadc56af2c51da1c0009589e3b82bcbe122329b17213c88` confirmed. Actual candidate-to-final patch was reviewed and every declared replacement inverse-tested against original four candidate files. Reversing only metadata/version/status/path/release-label edits recovers ALL original bytes; no remaining semantic delta. Shared components/webhooks compare equal. The Returns packaging reference changes from separate root-binding.md to the same-bundle root annex; producer uptake is explicitly not implied.

Fresh OpenAPI3.1 `openapi-spec-validator0.7.2` full validation: **0errors**;298local refs resolve;236 schema-bound examples validate including formats;5annex links resolve. Bad OpenAPI version and missing required title negative controls reject. Library warnings are retained as tooling warnings. Reused validator dependencies were read-only from prior disposable tooldeps; independent verifier source and fresh result paths are archived. Schema/model does not enforce actual always-emit, HTTP, JWT, Mongo or consumer uptake.

Previous independent model evidence is **historical for this run**, reused through exact candidate pin + byte-inverse proof + prior376-file evidence manifest verification. No redundant model/composition reruns, no promotion of declarations to execution.

## Independent guard binding

Independently authored/compiled .NET8 calculator uses the exact production algorithm at DocsPathGuardTests.cs:220–222: `GetRawText(canonicalTargets) + "\\n" + GetRawText(sealedInputs)`, UTF8 SHA256. Output byte-equals proposed payload: **11185bytes**, `85154a3e3368bfe187447bde269d0041a5863f3ef8b57b8e4397de97635cb270`. No JSON reserialization/canonicalization/BOM/trailing newline.

All22seals have matching actual source SHA256, provenance file SHA256 and exact production-regex source/hash binding at declared provenanceLine. All22objects equal R2 disposition; first17objects equal live historical authority. Active-tool targets cover exactly the2declared canonical targets; YAML binds final hash, Carrier remains unchanged. New annexes are publication-manifest-bound, not invented unused guard targets. Draft decision hash matches authority.decision.sha256. Authority `5fb3b8c92ee2ce42e79953700960c3f20ec71dbdad3b926eb1213dffbd2f525e`; draft decision `9a1214f8f6440832ee306de9e481ddf5cdaa07953a6b102ab3be5d42e49d3a3b` both remain UNAPPROVED.

This verifies binding calculations, NOT production activation. Current ReadAuthority requires APPROVED status and recorded owner before hashing. Current docs/records prefix policy also still needs the separately proposed exact exception disposition for two roadmap inputs. No synthetic APPROVED record was created, no fixture or policy patch applied, and no production-mode success is claimed. Final approved decision file stamping will change decision/authority hashes; payload arrays must stay exact or be reapproved.

## Existing versus missing real authority

|Authority|Existing evidence and scope|Final proposal disposition|
|---|---|---|
|Root/D186/D187 design and candidate preparation|Actual user messages in this conversation explicitly grant only design/candidate preparation, with inherited root and module-specific policies|Preserved; business decisions not reopened|
|3.0.0 / wirev1 release version and final annex paths|Final pack task authorizes proposal preparation; candidate status/FROZEN labels do not confer publication|Proposal only; owner selection still required|
|Consumer release consent|Existing design grants exclude release consent; old91d505 root grant is a different artifact|Missing for exact final5dfe7… YAML+three annexes; owner identity/scope required|
|Canonical publication|Current tasks authorize preparation/verification only|Missing exact four-file/patch grant; OWNER-DECISION-TEXTS.md blockB is a draft|
|Guard policy-code|R2 README explicitly awaiting owner; two exact path/hash exceptions, boundary tests and rule|Missing C1 application authority; no broad exclusion|
|Fixture application|R2 records distinguish new87932c… byte-preserving fixture diff from old fix|Missing exact C2 application grant; prior fixture testing is not consent|
|Working artifact relocation|Approval-validation record preserves prior byte-identical relocation permission|Preserved only its prior bounded scope; not new policy or activation|
|Guard payload and production activation|Actual DOCS_PATH_OWNER_DECISION approves old634208…42202 payload only|Does not cover85154a…cb270; final C3 grant and actual decision file hash binding still missing|

Actual durable owner decision: `docs/records/decisions/2026-09/mvp6-guard-complete-disposition-owner-approval-01.json`. Approval-validation and R2 disposition inspected snapshots retained. No inferred approval from author-provided text. No consumer consent carried across versions/hashes. Historical root11-path disposable runtime approval is tied to91d505… and does not authorize this final contract uptake.

## Remaining release gates / SOP22 close

Only remaining release actions: accountable owner selects exact version/paths; separately records final consumer consent and four-file publication authority; separately grants policy/fixture/new payload activation scopes. Then authorized single owner must validate coordinated publication+approved binding using actual production-mode ReadAuthority and full DocsPathGuard in disposable checkout before baseline recheck/application. This verifier did not execute those future authorized stages or waive prior guard/suite failures.

Golden flow: four-file baseline→publication proposal. Subflows: exact inverse compatibility, unchanged annex dependencies, raw payload binding. Failure paths: schema negatives, absent approvals fail closed; verifier archive-prefix instrumentation correction recorded. Persistence/security/RBAC/tenant: unchanged contract only; no HTTP/Mongo/JWT tests. Audit/observability: independent scripts, application logs, .NET output, refs/examples/seal lines, exact manifests and archive. Migration/rollback: none applied; no operational DB/backfill. Runtime uptake, Loads multi-Shipment root decision, rollout, E5/G5, pack promotion and DEV GO remain outside this PASS. Inspected pinned inputs unchanged at end; no repo-wide no-change claim across concurrent lanes. No canonical/guard/runtime/pack/git changes.
'''
# derive actual manifest count rather than narration assumption
counts=json.loads((W/'manifest-results.json').read_text());report=report.replace('Outer27-file',f"Outer{counts['outer']}-file");(O/'SOP-22.md').write_text(report)
(E/'fresh-manifest.sha256').write_text(''.join(f'{H(p)}  {p.relative_to(E)}\n' for p in sorted(E.rglob('*')) if p.is_file()))
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:t.add(E,arcname='evidence')
shutil.copy2(E/'fresh-manifest.sha256',O/'evidence-manifest.sha256');(O/'SHA256SUMS').write_text(''.join(f'{H(p)}  {p.relative_to(O)}\n' for p in sorted(O.rglob('*')) if p.is_file()))
print('REPORT',O/'SOP-22.md');print('ARCHIVE',H(O/'evidence.tar.gz'));print('COUNTS',counts)
