using Ocelot.Configuration.File;
using System.Text.Json;
using Xunit;

namespace Diten.ApiGateway.Tests;

public sealed class ShipmentRouteCoverageTests
{
    private static FileConfiguration Load() => JsonSerializer.Deserialize<FileConfiguration>(
        File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "ocelot.json")),
        new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;

    [Fact]
    public void Shipment_routes_expose_only_the_five_published_operations()
    {
        var routes = Load().Routes
            .Where(route => route.UpstreamPathTemplate.StartsWith("/api/shipment-bundle/shipments", StringComparison.Ordinal))
            .ToArray();

        Assert.Equal(4, routes.Length);
        AssertMethods(routes, "/api/shipment-bundle/shipments", "GET", "POST");
        AssertMethods(routes, "/api/shipment-bundle/shipments/{shipmentId}", "GET");
        AssertMethods(routes, "/api/shipment-bundle/shipments/{shipmentId}/transition", "POST");
        AssertMethods(routes, "/api/shipment-bundle/shipments/{shipmentId}/pod", "POST");

        Assert.All(routes, route =>
        {
            var host = Assert.Single(route.DownstreamHostAndPorts);
            Assert.Equal("localhost", host.Host);
            Assert.Equal(5061, host.Port);
            Assert.DoesNotContain("{everything}", route.UpstreamPathTemplate, StringComparison.OrdinalIgnoreCase);
            Assert.DoesNotContain(route.UpstreamHttpMethod, method => method is "DELETE" or "OPTIONS" or "PATCH" or "PUT");
        });
    }

    private static void AssertMethods(IEnumerable<FileRoute> routes, string path, params string[] methods)
    {
        var route = Assert.Single(routes, candidate => candidate.UpstreamPathTemplate == path);
        Assert.Equal(methods.OrderBy(value => value, StringComparer.Ordinal),
            route.UpstreamHttpMethod.OrderBy(value => value, StringComparer.Ordinal));
    }
}
