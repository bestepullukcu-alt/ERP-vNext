using Diten.SupplyChainService.Api.ModuleRegistration;
using Xunit;

namespace Diten.SupplyChainService.Tests.Shipments;

public sealed class ShipmentTrackingPodManifestProviderTests
{
    private static readonly Diten.BuildingBlocks.ModuleRegistration.Abstractions.ModuleManifestDocument Manifest =
        new ShipmentTrackingPodManifestProvider().GetManifest();

    [Fact]
    public void Declares_exact_three_page_topology_and_existing_permissions()
    {
        Assert.Equal("shipment-tracking-pod", Manifest.ModuleCode);
        Assert.Equal("SupplyChainExecution", Manifest.Domain);
        Assert.Equal("DitenSupplyChainService", Manifest.Service);
        Assert.True(Manifest.IsTenantAssignable);
        Assert.False(Manifest.IsBaseline);

        Assert.Equal(3, Manifest.Pages.Count);
        var list = Assert.Single(Manifest.Pages, page => page.PageCode == "SHIPMENTS");
        Assert.Equal("/SupplyChain/Shipments", list.RoutePath);
        Assert.Equal("supplychain.shipments.read", list.RequiredPermission);
        Assert.True(list.IsNavigationVisible);

        var create = Assert.Single(Manifest.Pages, page => page.PageCode == "SHIPMENTS_CREATE");
        Assert.Equal("/SupplyChain/Shipments/Create", create.RoutePath);
        Assert.Equal("supplychain.shipments.create", create.RequiredPermission);
        Assert.False(create.IsNavigationVisible);

        var details = Assert.Single(Manifest.Pages, page => page.PageCode == "SHIPMENTS_DETAILS");
        Assert.Equal("/SupplyChain/Shipments/Details/{shipmentId}", details.RoutePath);
        Assert.Equal("supplychain.shipments.read", details.RequiredPermission);
        Assert.False(details.IsNavigationVisible);

        var keys = Manifest.Pages.SelectMany(page => page.Actions.Select(action => action.PermissionKey))
            .ToHashSet(StringComparer.Ordinal);
        Assert.Equal(4, keys.Count);
        Assert.Contains("supplychain.shipments.create", keys);
        Assert.Contains("supplychain.shipments.dispatch", keys);
        Assert.Contains("supplychain.shipments.cancel", keys);
        Assert.Contains("supplychain.shipments.pod.capture", keys);
        Assert.DoesNotContain(Manifest.Pages.SelectMany(page => page.Actions),
            action => action.ActionCode.Contains("RECONCILE", StringComparison.OrdinalIgnoreCase));
    }
}
