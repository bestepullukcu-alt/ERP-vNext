#!/usr/bin/env python3
from __future__ import annotations

import base64
import concurrent.futures
import hashlib
import hmac
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from uuid import uuid4


def b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()


def token(tenant: str, legal_entity: str, actor: str, permissions: list[str]) -> str:
    header = b64(b'{"alg":"HS256","typ":"JWT"}')
    payload = b64(json.dumps({
        "sub": actor,
        "tenant_id": tenant,
        "legal_entity_id": legal_entity,
        "actor_type": "tenant_user",
        "permission": ["supplychain.shipments." + p for p in permissions],
        "iss": "mod0183-tests",
        "aud": "mod0183-tests",
        "exp": int(time.time()) + 900,
    }, separators=(",", ":")).encode())
    unsigned = header + "." + payload
    signature = hmac.new(os.environ["VER_JWT_SECRET"].encode(), unsigned.encode(), hashlib.sha256).digest()
    return unsigned + "." + b64(signature)


def request(method: str, path: str, tenant: str, legal_entity: str, actor: str,
            permissions: list[str], correlation: str, key: str | None = None,
            body: dict | None = None) -> dict:
    raw = b"" if body is None else json.dumps(body, separators=(",", ":")).encode()
    headers = {
        "Authorization": "Bearer " + token(tenant, legal_entity, actor, permissions),
        "X-Tenant-Id": tenant,
        "X-Legal-Entity-Id": legal_entity,
        "X-Correlation-Id": correlation,
    }
    if key is not None:
        headers["Idempotency-Key"] = key
    if body is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(os.environ["VER_API_URL"] + path, data=raw if body is not None else None,
                                 method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            response_raw = response.read()
            return {
                "status": response.status,
                "requestBytes": len(raw),
                "correlation": response.headers.get("X-Correlation-Id"),
                "body": json.loads(response_raw) if response_raw else None,
            }
    except urllib.error.HTTPError as error:
        response_raw = error.read()
        return {
            "status": error.code,
            "requestBytes": len(raw),
            "correlation": error.headers.get("X-Correlation-Id"),
            "body": json.loads(response_raw) if response_raw else None,
        }


def mongo(expression: str):
    result = subprocess.run([
        "mongosh", "--quiet", os.environ["VER_MONGO_URI"], "--eval", expression
    ], text=True, capture_output=True, check=False)
    if result.returncode != 0:
        raise RuntimeError("Mongo query failed: " + result.stderr)
    text = result.stdout.strip()
    return json.loads(text) if text else None


def scoped_counts(tenant: str, legal_entity: str) -> dict:
    database = json.dumps(os.environ["VER_DB"])
    scope = "{TenantId:" + json.dumps(tenant) + ",LegalEntityId:" + json.dumps(legal_entity) + "}"
    collections = ["sce_shipments", "sce_shipment_history", "sce_shipment_audit", "sce_shipment_receipts", "sce_shipment_outbox"]
    script = "const d=db.getSiblingDB(" + database + "); EJSON.stringify({" + ",".join(
        json.dumps(name) + ":d.getCollection(" + json.dumps(name) + ").countDocuments(" + scope + ")"
        for name in collections
    ) + "})"
    return mongo(script)


def main():
    tenant = str(uuid4())
    legal_entity = str(uuid4())
    actor = str(uuid4())
    root = str(uuid4())
    key = "ver-root-create-" + str(uuid4())
    body = {
        "sourceModule": "MOD-0141",
        "sourceType": "SALES_ORDER",
        "sourceDocumentId": "ROOT-R2-VER-01",
        "warehouseReferenceId": "WH-ROOT-R2-VER",
        "shipToReference": "DEST-ROOT-R2-VER",
        "plannedShipAt": "2026-09-24T18:00:00Z",
        "plannedDeliverAt": "2026-09-25T18:00:00Z",
        "lines": [{
            "lineNumber": "1",
            "itemId": str(uuid4()),
            "skuId": str(uuid4()),
            "quantity": "1.000",
            "uomId": "EA",
            "inventoryReferenceId": "INV-ROOT-R2-VER",
        }],
    }
    before = scoped_counts(tenant, legal_entity)
    create = request("POST", "/api/shipment-bundle/shipments", tenant, legal_entity, actor,
                     ["create"], root, key, body)
    shipment_id = create["body"]["shipmentId"]
    detail_trace = str(uuid4())
    detail = request("GET", "/api/shipment-bundle/shipments/" + shipment_id, tenant,
                     legal_entity, actor, ["read"], detail_trace)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        concurrent_replays = list(pool.map(lambda _: request(
            "POST", "/api/shipment-bundle/shipments", tenant, legal_entity, actor,
            ["create"], root, key, body), range(4)))
    changed = dict(body)
    changed["shipToReference"] = "DIFFERENT-DESTINATION"
    conflict = request("POST", "/api/shipment-bundle/shipments", tenant, legal_entity,
                       actor, ["create"], root, key, changed)
    cross_tenant = request("GET", "/api/shipment-bundle/shipments/" + shipment_id,
                           str(uuid4()), legal_entity, actor, ["read"], str(uuid4()))
    cross_legal_entity = request("GET", "/api/shipment-bundle/shipments/" + shipment_id,
                                 tenant, str(uuid4()), actor, ["read"], str(uuid4()))
    forbidden = request("GET", "/api/shipment-bundle/shipments/" + shipment_id,
                        tenant, legal_entity, actor, [], str(uuid4()))
    after = scoped_counts(tenant, legal_entity)
    document = mongo(
        "const d=db.getSiblingDB(" + json.dumps(os.environ["VER_DB"]) + ");"
        "EJSON.stringify(d.sce_shipments.findOne({_id:" + json.dumps(shipment_id) +
        ",TenantId:" + json.dumps(tenant) + ",LegalEntityId:" + json.dumps(legal_entity) +
        "},{LifecycleCorrelationId:1,CorrelationId:1,IsDeleted:1}))"
    )
    outbox = mongo(
        "const d=db.getSiblingDB(" + json.dumps(os.environ["VER_DB"]) + ");"
        "EJSON.stringify(d.sce_shipment_outbox.find({TenantId:" + json.dumps(tenant) +
        ",LegalEntityId:" + json.dumps(legal_entity) + "}).toArray().map(x=>({CorrelationId:x.CorrelationId,Status:x.Status})))"
    )
    passed = (
        create["status"] == 201
        and detail["status"] == 200
        and detail["body"].get("lifecycleCorrelationId") == root
        and document.get("LifecycleCorrelationId") == root
        and document.get("CorrelationId") == root
        and all(row["status"] == 200 and row["body"].get("idempotentReplay") is True for row in concurrent_replays)
        and conflict["status"] == 409
        and cross_tenant["status"] == 404
        and cross_legal_entity["status"] == 404
        and forbidden["status"] == 403
        and before == {name: 0 for name in before}
        and after == {
            "sce_shipments": 1,
            "sce_shipment_history": 1,
            "sce_shipment_audit": 1,
            "sce_shipment_receipts": 1,
            "sce_shipment_outbox": 1,
        }
        and len(outbox) == 1
        and outbox[0].get("CorrelationId") == root
        and outbox[0].get("Status") == "Pending"
    )
    evidence = {
        "status": "PASS" if passed else "FAIL",
        "tenant": tenant,
        "legalEntity": legal_entity,
        "actor": actor,
        "shipmentId": shipment_id,
        "authoritativeRoot": root,
        "create": create,
        "detail": detail,
        "concurrentReplays": concurrent_replays,
        "changedPayloadConflict": conflict,
        "crossTenant": cross_tenant,
        "crossLegalEntity": cross_legal_entity,
        "permissionDenied": forbidden,
        "before": before,
        "after": after,
        "persisted": document,
        "outbox": outbox,
    }
    Path(os.environ["VER_EVIDENCE"]).write_text(json.dumps(evidence, indent=2) + "\n")
    Path(os.environ["VER_STATE"]).write_text(json.dumps({
        "tenant": tenant,
        "legalEntity": legal_entity,
        "actor": actor,
        "shipmentId": shipment_id,
        "root": root,
        "before": before,
        "after": after,
    }, indent=2) + "\n")
    print(evidence["status"])
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
