using Diten.SupplyChainService.Domain.Features.CapacityPlans;
using Diten.SupplyChainService.Persistence.Features.CapacityPlans;
using Diten.SupplyChainService.Infrastructure.Features.CapacityPlans;
using MongoDB.Driver;
using Xunit;
using Xunit.Abstractions;

namespace Diten.SupplyChainService.Tests.CapacityPlans;
[Collection("CapacityMongo")]
public sealed class CapacityWireProbeVerificationOnly(ITestOutputHelper output)
{
    [Fact]
    public async Task Duplicate_scenario_name_sequential_and_racing_outcomes()
    {
        var db = new MongoClient("mongodb://127.0.0.1:57193/?replicaSet=rsmod192ver&serverSelectionTimeoutMS=5000")
            .GetDatabase("DitenSupplyChain_Mod0192_Test");
        foreach (var name in new[]{"capacity_plans","capacity_scenarios","capacity_evaluations","capacity_receipts","capacity_active_slots","capacity_audit","capacity_outbox"})
            await db.DropCollectionAsync(name);
        await new CapacitySchema(db).StartAsync(CancellationToken.None);
        var repo = new CapacityRepository(db,new DemandFixtureReader(),new ConstraintFixtureReader());
        var scope = new CapacityScope(DemandFixtureReader.Tenant,DemandFixtureReader.LegalEntity,Guid.NewGuid());
        var plan = new CapacityPlan {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            Name="FY2027 Capacity Baseline",HorizonStart=new DateOnly(2027,1,1),HorizonEnd=new DateOnly(2027,12,31),
            DemandPlanId="dp-2027",DemandPlanVersion="3",SourceCapturedAt=DateTimeOffset.UtcNow,
            SourceChecksum="sha256:ee56d4f9a3c8",CreatedAt=DateTimeOffset.UtcNow,Version=1,CreatedBy=scope.ActorId};
        var p=await repo.CreatePlanAsync(scope,"probe-plan","probe-plan-fp",Guid.NewGuid(),plan,CancellationToken.None);
        Assert.Equal(201,p.StatusCode);
        CapacityScenario Scenario() => new() {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            CapacityPlanId=plan.Id,Name="Duplicate name",CreatedAt=DateTimeOffset.UtcNow,Version=1,CreatedBy=scope.ActorId,
            ConstraintRefs=[new("line-4-hours","SUPPLY-CONSTRAINTS","8")],Adjustments=[new("line-4","2027-W03","80.000","HOUR")]};
        var first=await repo.CreateScenarioAsync(scope,plan.Id,"first","fp-first",Guid.NewGuid(),Scenario(),CancellationToken.None);
        var second=await repo.CreateScenarioAsync(scope,plan.Id,"second","fp-second",Guid.NewGuid(),Scenario(),CancellationToken.None);
        output.WriteLine($"sequential first={first.StatusCode}/{first.ErrorCode}; second={second.StatusCode}/{second.ErrorCode}");
        Assert.Equal(201,first.StatusCode);
        Assert.Equal(409,second.StatusCode);
        Assert.Equal("CAPACITY_SCENARIO_NAME_CONFLICT",second.ErrorCode);
        var raceName="Race duplicate";
        CapacityScenario Race() {var s=Scenario();s.Name=raceName;return s;}
        var race=await Task.WhenAll(repo.CreateScenarioAsync(scope,plan.Id,"race-a","fp-race-a",Guid.NewGuid(),Race(),CancellationToken.None),
            repo.CreateScenarioAsync(scope,plan.Id,"race-b","fp-race-b",Guid.NewGuid(),Race(),CancellationToken.None));
        output.WriteLine($"race a={race[0].StatusCode}/{race[0].ErrorCode}; b={race[1].StatusCode}/{race[1].ErrorCode}");
        Assert.Single(race,x=>x.StatusCode==201);
    }
}
