#!/bin/zsh
# Q154 parallel-slot trial (R4 preparation; report only): slot 6 (build) and slot 7 (build-s7) at the same time.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q154_LANE=1
Q=~/mvp6-env/q154; L=$Q/logs/parallel; mkdir -p $L $Q/tmp-s6 $Q/tmp-s7
SC=services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj
AP=services/Diten.Platform/tests/Diten.Platform.Application.Tests/Diten.Platform.Application.Tests.csproj
lane() { slot=$1; dir=$2
  ( export TMPDIR=$Q/tmp-s$slot/; eval "$($Q/B/src/scripts/test-env/mvp6-test-mongo-env.sh --slot $slot --rs rsq154s$slot)" || exit 2
    cd $Q/B/$dir
    echo "slot$slot capacity start $(date +%H:%M:%S)" >> $L/TIMES.txt
    dotnet test $SC --no-build --disable-build-servers --filter "FullyQualifiedName~CapacityPlans" --results-directory $L --logger "trx;LogFileName=s$slot-capacity.trx" > $L/s$slot-capacity.log 2>&1
    echo "slot$slot capacity end $(date +%H:%M:%S) rc $? :: $(grep -E '(Passed|Failed)!' $L/s$slot-capacity.log | tail -1 | sed 's/^ *//')" >> $L/TIMES.txt
    echo "slot$slot platform start $(date +%H:%M:%S)" >> $L/TIMES.txt
    dotnet test $AP --no-build --disable-build-servers --filter "FullyQualifiedName~PlatformSchemaContractMongoTests|FullyQualifiedName~TaskCommentOrderMongoTests" --results-directory $L --logger "trx;LogFileName=s$slot-platform.trx" > $L/s$slot-platform.log 2>&1
    echo "slot$slot platform end $(date +%H:%M:%S) rc $? :: $(grep -E '(Passed|Failed)!' $L/s$slot-platform.log | tail -1 | sed 's/^ *//')" >> $L/TIMES.txt ) }
lane 6 build & p6=$!
lane 7 build-s7 & p7=$!
wait $p6 $p7
echo PARALLEL-DONE
