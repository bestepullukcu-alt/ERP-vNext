#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q154_LANE=1
Q=~/mvp6-env/q154; L=$Q/logs/build; mkdir -p $L; S=$L/BUILD-SUMMARY.tsv; printf "tree\ttarget\texit\twarnings\terrors\n" > $S
b() { tree=$1; t=$2; n=$tree--${${t:t}:r}; cd $Q/$tree/build
  dotnet build $t -c Debug --disable-build-servers -p:UseSharedCompilation=false > $L/$n.log 2>&1; rc=$?
  w=$(grep -E '^ *[0-9]+ Warning\(s\)' $L/$n.log | tail -1 | awk '{print $1}'); e=$(grep -E '^ *[0-9]+ Error\(s\)' $L/$n.log | tail -1 | awk '{print $1}')
  printf "%s\t%s\t%s\t%s\t%s\n" $tree $t $rc "$w" "$e" >> $S; }
T=services/Diten.Platform/tests
for tr in A B; do
  for t in $T/Diten.Platform.Application.Tests/Diten.Platform.Application.Tests.csproj $T/Diten.Platform.BackgroundJobs.Tests/Diten.Platform.BackgroundJobs.Tests.csproj $T/Diten.Platform.Eventing.Tests/Diten.Platform.Eventing.Tests.csproj services/Diten.SupplyChainService/Diten.SupplyChainService.sln tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj; do b $tr $t; done
done
echo BUILD-DONE
