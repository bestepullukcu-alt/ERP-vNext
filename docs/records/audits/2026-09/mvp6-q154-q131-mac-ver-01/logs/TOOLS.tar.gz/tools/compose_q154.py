#!/usr/bin/env python3
"""Q154 compose per BASE-STACK v1 §3 (cp only, fail-closed, never deletes).
tree A = BASE a8a236de -> Q117 83e6322c -> Q121 93bf1c07        (~/mvp6-env/q154/A/src)
tree B = A + overlay-q131a 4a4a0860 (preimages checked)          (~/mvp6-env/q154/B/src)
Staging: ~/mvp6-env/q154/stage/<layer>/ (kept). Copies use `cp -p`; clones `cp -c -Rp`. Any mismatch -> exit 2, nothing removed."""
import csv, hashlib, os, pathlib, subprocess, sys, tarfile
H = pathlib.Path.home() / "mvp6-env"; Q = H / "q154"
R = pathlib.Path("/Users/natig/Projects/ERP-vNext-recovery/docs/records/audits/2026-09")
LOG = []
def log(m): LOG.append(m); print(m)
def stop(m): log("STOP: " + m); (Q / "logs" / "COMPOSE-LOG.txt").write_text("\n".join(LOG) + "\n"); sys.exit(2)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def run(*a): subprocess.run(a, check=True)

ARCH = {"q117": (R / "mvp6-q117-test-guard-fixes-01/q117-fixes-overlay.tar.gz", "83e6322c1d4dd46c80b0b4de0a2b60493883a7b2d923c7685da689de702f800d"),
        "q121": (R / "mvp6-q121-mongo-guard-fixes-01/q121-mongo-guard-fixes-overlay.tar.gz", "93bf1c07249c43853870cd74150a1f0813bff1d74a8661259f8e14112258ea90"),
        "q131a": (R / "mvp6-q131a-port-uri-overlay-01/overlay-q131a.tar", "4a4a0860954f437265e21b90a4c028ac282a7444343b5d6d8ea8fa31b7434acf")}
P = "services/Diten.Platform/tests/Diten.Platform.Application.Tests/"
EXPECT = {
 "q117": {r["path"]: (r["base_sha256"], r["overlay_sha256"]) for r in csv.DictReader(open(R / "mvp6-q117-test-guard-fixes-01/OVERLAY-MANIFEST.tsv"), delimiter="\t")},
 "q121": {P + "Audit/PpmAuditRetentionPolicySeedMongoTests.cs": ("c22f0cdab58c2b229fa529c1cdb466d876a99a68abb1cae40952a8f1d4acbc46", "ea6fa3623810de341bb5b4fe2e3de9bf62a6cbce5557aa0dd623ba243238aa76"),
          P + "Persistence/DisposableStandaloneMongo.cs": ("0fb06a1d020ada8deaaaf0d702fe2007ac89d2104e585d1f2bca3868c9cb00ef", "4aaec42c9919961b08005eb9cd142e5dd7b82d651a5bf65c78acbce2f987fc48")},
 "q131a": {r["path"]: (r["preimage_sha256"], r["postimage_sha256"]) for r in csv.DictReader(open(R / "mvp6-q131a-port-uri-overlay-01/OVERLAY-MANIFEST.tsv"), delimiter="\t")},
}
BASEMAN = {r[0]: r[1] for r in list(csv.reader(open(H / "base/BASE-MANIFEST.tsv"), delimiter="\t"))[1:]}

def apply(layer, src, expected_tree):
    arch, h = ARCH[layer]
    if sha(arch) != h: stop(f"{layer} archive sha256 mismatch")
    st = Q / "stage" / layer
    if any(st.iterdir()): stop(f"stage/{layer} not empty")
    with tarfile.open(arch) as t:
        mem = t.getmembers()
        for m in mem:
            if m.issym() or m.islnk() or m.name.startswith("/") or ".." in m.name.split("/"): stop(f"{layer} unsafe member {m.name}")
        apple = [m.name for m in mem if os.path.basename(m.name).startswith("._")]
        t.extractall(st, members=[m for m in mem if m.isfile() and m not in apple and not os.path.basename(m.name).startswith("._")])
    files = sorted(str(p.relative_to(st)) for p in st.rglob("*") if p.is_file())
    exp = EXPECT[layer]
    if set(files) != set(exp): stop(f"{layer} member list != declared list: extra {sorted(set(files)-set(exp))[:3]} missing {sorted(set(exp)-set(files))[:3]}")
    added = 0
    for p in files:
        pre, post = exp[p]
        if sha(st / p) != post: stop(f"{layer} member sha256 mismatch {p}")
        tgt = src / p
        now = sha(tgt) if tgt.exists() else "-"
        if pre in ("-", "") or pre is None:
            if tgt.exists(): stop(f"{layer} NEW file already present {p}")
            added += 1
        elif now != pre: stop(f"{layer} preimage mismatch {p}: tree {now[:12]} != declared {pre[:12]}")
        tgt.parent.mkdir(parents=True, exist_ok=True); run("cp", "-p", str(st / p), str(tgt))
        if sha(tgt) != post: stop(f"{layer} copy mismatch {p}")
        expected_tree[p] = post
    log(f"{layer}: archive {h[:12]} OK; {len(files)} members = declared list; AppleDouble skipped {len(apple)}; preimages OK; {len(files)-added} replaced, {added} added")

def verify(src, expected_tree, label):
    seen = 0; bad = []; extra = []
    for d, _, fs in os.walk(src):
        for f in fs:
            p = os.path.relpath(os.path.join(d, f), src); seen += 1
            if p not in expected_tree: extra.append(p)
            elif sha(os.path.join(d, f)) != expected_tree[p]: bad.append(p)
    missing = len(expected_tree) - (seen - len(extra))
    log(f"{label}: files {seen}; expected {len(expected_tree)}; mismatches {len(bad)} {bad[:3]}; extra {len(extra)} {extra[:3]}; missing {missing}")
    if bad or extra or missing: stop(f"{label} verification failed")

def main():
    exp = dict(BASEMAN)
    A = Q / "A" / "src"
    if A.exists(): stop("A/src exists (use a new folder)")
    A.parent.mkdir(parents=True); run("cp", "-c", "-Rp", str(H / "base/src"), str(A)); run("chmod", "-R", "u+w", str(A))
    log("A: BASE cloned (cp -c -Rp) and made writable on the copy only")
    apply("q117", A, exp); apply("q121", A, exp); verify(A, exp, "tree A (BASE→Q117→Q121)")
    B = Q / "B" / "src"
    if B.exists(): stop("B/src exists")
    B.parent.mkdir(parents=True); run("cp", "-c", "-Rp", str(A), str(B))
    apply("q131a", B, exp); verify(B, exp, "tree B (A + overlay-q131a)")
    (Q / "logs" / "COMPOSE-LOG.txt").write_text("\n".join(LOG) + "\n")
main()
