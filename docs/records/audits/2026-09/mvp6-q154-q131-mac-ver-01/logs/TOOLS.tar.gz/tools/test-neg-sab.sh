#!/bin/zsh
# Q154 negative control (all variables UNSET) and sabotage (bad URIs) on tree B. No lane URI is exported here.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q154_LANE=1
Q=~/mvp6-env/q154; export TMPDIR=$Q/tmp/
for v in DITEN_PLATFORM_TEST_MONGO_URI MVP6_MOD0192_MONGO_URI MOD0183_TEST_MONGO MOD0184_TEST_MONGO MOD0185_TEST_MONGO MVP6_MOD0190_MONGO_URI RETURNS_MONGO_URI CLAIMS_TEST_MONGO MongoDbSettings__ConnectionString Eventing__MongoDb__ConnectionString; do unset $v; done
L=$Q/logs/negsab; mkdir -p $L; S=$L/NEGSAB-SUMMARY.tsv; printf "case\tsuite\tfilter\texit\tsummary\n" > $S
T=services/Diten.Platform/tests; AP=$T/Diten.Platform.Application.Tests/Diten.Platform.Application.Tests.csproj; BJ=$T/Diten.Platform.BackgroundJobs.Tests/Diten.Platform.BackgroundJobs.Tests.csproj
SC=services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj
PF="FullyQualifiedName~PlatformSchemaContractMongoTests|FullyQualifiedName~WorkflowTransitionGateMongoRepositoryTests|FullyQualifiedName~BusinessReferenceDataTenantAssignmentMongoTests|FullyQualifiedName~TaskCommentOrderMongoTests"
CF="FullyQualifiedName~CapacityPlans.CapacityIsolationTests|FullyQualifiedName~CapacityPlans.CapacityLeaseTests|FullyQualifiedName~CapacityPlans.CapacityConcurrencyTests"
t() { c=$1; n=$2; proj=$3; filt=$4; cd $Q/B/build; tn=$c--$n; echo "$(date +%H:%M:%S) start $tn" >> $L/RUN-ORDER.txt
  if [ -n "$filt" ]; then dotnet test $proj --no-build --disable-build-servers --filter "$filt" --results-directory $L --logger "trx;LogFileName=$tn.trx" > $L/$tn.log 2>&1
  else dotnet test $proj --no-build --disable-build-servers --results-directory $L --logger "trx;LogFileName=$tn.trx" > $L/$tn.log 2>&1; fi; rc=$?
  printf "%s\t%s\t%s\t%s\t%s\n" $c $n "${filt:+filtered}" $rc "$(grep -E '(Passed|Failed)!' $L/$tn.log | tail -1 | sed 's/^ *//')" >> $S; }
# N — negative control: nothing set
t N platform-application $AP ""
t N platform-backgroundjobs $BJ ""
t N capacityplans $SC "FullyQualifiedName~CapacityPlans"
# S — sabotage: one bad value at a time (fake values only; x:y is not a real credential)
sab() { c=$1; val=$2; export DITEN_PLATFORM_TEST_MONGO_URI="$val" MVP6_MOD0192_MONGO_URI="$val"; t $c platform-mongo $AP "$PF"; t $c platform-backgroundjobs $BJ ""; t $c capacity $SC "$CF"; unset DITEN_PLATFORM_TEST_MONGO_URI MVP6_MOD0192_MONGO_URI; }
sab S1-port27017     "mongodb://127.0.0.1:27017/?replicaSet=rsq154s6&serverSelectionTimeoutMS=2000"
sab S2-port-omitted  "mongodb://127.0.0.1/?replicaSet=rsq154s6&serverSelectionTimeoutMS=2000"
sab S3-credentials   "mongodb://<FAKE-USERINFO-REDACTED>@127.0.0.1:36994/?replicaSet=rsq154s6&serverSelectionTimeoutMS=2000"
sab S4-non-loopback  "mongodb://10.255.255.1:36994/?replicaSet=rsq154s6&serverSelectionTimeoutMS=2000"
sab S5-srv           "mongodb+srv://example.invalid/?replicaSet=rsq154s6"
export MVP6_MOD0192_MONGO_URI="mongodb://127.0.0.1:36994/?serverSelectionTimeoutMS=2000"; t S6-capacity-no-replicaset capacity $SC "$CF"; unset MVP6_MOD0192_MONGO_URI
echo NEGSAB-DONE
