#!/bin/zsh
# Q154 main runs. Env comes ONLY from the overlay script (slot 6, rsq154s6), identical for A and B runs.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q154_LANE=1
Q=~/mvp6-env/q154; mkdir -p $Q/tmp; export TMPDIR=$Q/tmp/
eval "$($Q/B/src/scripts/test-env/mvp6-test-mongo-env.sh --slot 6 --rs rsq154s6 --all-supplychain)" || { echo "env script failed"; exit 2; }
L=$Q/logs/test; mkdir -p $L; S=$L/TEST-SUMMARY.tsv; [ -f $S ] || printf "tree\tsuite\tfilter\texit\tsummary\n" > $S
t() { tree=$1; n=$2; proj=$3; filt=$4; cd $Q/$tree/build; tn=$tree--$n
  echo "$(date +%H:%M:%S) start $tn" >> $L/RUN-ORDER.txt
  if [ -n "$filt" ]; then dotnet test $proj --no-build --disable-build-servers --filter "$filt" --results-directory $L --logger "trx;LogFileName=$tn.trx" > $L/$tn.log 2>&1
  else dotnet test $proj --no-build --disable-build-servers --results-directory $L --logger "trx;LogFileName=$tn.trx" > $L/$tn.log 2>&1; fi; rc=$?
  printf "%s\t%s\t%s\t%s\t%s\n" $tree $n "${filt:--}" $rc "$(grep -E '(Passed|Failed)!' $L/$tn.log | tail -1 | sed 's/^ *//')" >> $S; }
T=services/Diten.Platform/tests
t B platform-application $T/Diten.Platform.Application.Tests/Diten.Platform.Application.Tests.csproj ""
t B platform-backgroundjobs $T/Diten.Platform.BackgroundJobs.Tests/Diten.Platform.BackgroundJobs.Tests.csproj ""
t A platform-eventing $T/Diten.Platform.Eventing.Tests/Diten.Platform.Eventing.Tests.csproj ""
t B platform-eventing $T/Diten.Platform.Eventing.Tests/Diten.Platform.Eventing.Tests.csproj ""
t A architecture tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj ""
t B architecture tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj ""
t B supplychain-single services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj ""
echo MAIN-DONE
