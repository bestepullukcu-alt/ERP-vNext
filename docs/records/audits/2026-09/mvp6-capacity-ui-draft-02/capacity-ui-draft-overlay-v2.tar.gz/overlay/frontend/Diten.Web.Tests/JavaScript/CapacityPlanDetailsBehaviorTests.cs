using System.Text.RegularExpressions;
using Xunit;

namespace Diten.Web.Tests.JavaScript;

// MOD-0192 Capacity — static behaviour contract of index.js / details.js / *.l10n.js (pack §23.3–§23.9, F192-LIST,
// F192-POLL). Runtime behaviour is covered by the Playwright scenarios for the Mac lane (Q88b).
// DRAFT overlay — not built, not run.
public sealed class CapacityPlanDetailsBehaviorTests
{
    private const string Js = "frontend/Diten.Web/wwwroot/assets/js/SupplyChain/CapacityPlans/";
    private readonly string _index = Read(Js + "index.js");
    private readonly string _details = Read(Js + "details.js");
    private static readonly string[] PublishedCodes =
    [
        "INVALID_REQUEST", "INVALID_CORRELATION_ID", "UNAUTHENTICATED", "FORBIDDEN", "UNKNOWN_CAPACITY_PLAN",
        "UNKNOWN_CAPACITY_SCENARIO", "UNKNOWN_CAPACITY_EVALUATION", "CAPACITY_PLAN_ALREADY_EXISTS",
        "CAPACITY_SCENARIO_NAME_CONFLICT", "CAPACITY_PLAN_STATE_CONFLICT", "EVALUATION_ALREADY_ACTIVE",
        "IDEMPOTENCY_KEY_REUSED", "INVALID_DEMAND_REFERENCE", "INVALID_CONSTRAINT_REFERENCE", "DEPENDENCY_UNAVAILABLE",
        "COMMIT_RESULT_UNRESOLVED"
    ];

    [Theory]
    [InlineData("index.js")]
    [InlineData("details.js")]
    public void Uses_only_the_same_origin_adapter_and_no_browser_storage(string file)
    {
        var script = Read(Js + file);
        Assert.Contains("/SupplyChain/CapacityPlans/api", script);
        foreach (var forbidden in new[] { ":5000", ":5061", "/api/supply-chain", "Authorization", "X-Tenant-Id", "X-Legal-Entity-Id",
                     "tenantId", "legalEntityId", "localStorage", "sessionStorage", "indexedDB", "document.cookie", "caches.open" })
        {
            Assert.DoesNotContain(forbidden, script);
        }
    }

    [Fact]
    public void Entry_page_makes_no_list_request_and_only_navigates_on_open_by_id()
    {
        // The only fetch on the entry page is the create POST (F192-LIST).
        Assert.Single(Regex.Matches(_index, @"\bfetch\("));
        Assert.Contains("method: 'POST'", _index);
        Assert.Contains("window.location.assign(detailsBase + encodeURIComponent(value))", _index);
        Assert.Contains("if (!UUID_PATTERN.test(value) || value === NIL_UUID)", _index);
    }

    [Fact]
    public void Create_plan_sends_the_seven_schema_fields_and_prefills_nothing()
    {
        var fields = Slice(_index, "const CREATE_FIELDS", "]);");
        foreach (var name in new[] { "'name'", "'horizonStart'", "'horizonEnd'", "'demandPlanId'", "'demandPlanVersion'", "'sourceCapturedAt'", "'sourceChecksum'" })
        {
            Assert.Contains(name, fields);
        }

        Assert.Equal(7, Regex.Matches(fields, @"\['\w+', 'plan\w+'\]").Count);
        Assert.DoesNotContain("toISOString", _index); // sourceCapturedAt is typed, never prefilled (0/7 on first open)
        Assert.Contains("created?.capacityPlanId", _index);
    }

    [Fact]
    public void Workspace_reads_only_the_three_bound_get_operations_and_never_a_list()
    {
        Assert.Contains("getJson(base, 'UNKNOWN_CAPACITY_PLAN')", _details);
        Assert.Contains("getJson(`${base}/scenarios/${encodeURIComponent(scenarioId)}`, 'UNKNOWN_CAPACITY_SCENARIO')", _details);
        Assert.Contains("getJson(`${base}/evaluations/${encodeURIComponent(evaluationId)}`, 'UNKNOWN_CAPACITY_EVALUATION')", _details);
        Assert.Equal(2, Regex.Matches(_details, @"\bfetch\(").Count); // getJson + postIntent
        Assert.DoesNotContain("getJson(`${base}/scenarios`", _details);
        Assert.DoesNotContain("getJson(`${base}/evaluations`", _details);
        foreach (var token in new[] { "method: 'DELETE'", "method: 'PUT'", "method: 'PATCH'", "/status", "/approve", "/archive", "/cancel", "/bulk", "/import", "/export", "?page", "search=" })
        {
            Assert.DoesNotContain(token, _details);
            Assert.DoesNotContain(token, _index);
        }
    }

    [Fact]
    public void Refresh_is_manual_one_get_per_click_with_no_timer()
    {
        foreach (var script in new[] { _index, _details })
        {
            foreach (var token in new[] { "setTimeout", "setInterval", "requestAnimationFrame", "EventSource", "WebSocket" })
            {
                Assert.DoesNotContain(token, script);
            }
        }

        Assert.Contains("const ACTIVE_EVALUATION = new Set(['Accepted', 'Running']);", _details);
        Assert.Contains("const canRefreshNow = () => !closed && evaluation !== null && ACTIVE_EVALUATION.has(evaluation.status);", _details);
        Assert.Contains("if (event.currentTarget.disabled || !canRefreshNow()) return;", _details);
        Assert.Contains("void loadEvaluation(evaluation.evaluationId);", _details);
    }

    [Fact]
    public void Actions_are_gated_by_key_and_loaded_state()
    {
        Assert.Contains("const canCreateScenarioNow = () => permissions.canCreateScenario && !closed && plan !== null;", _details);
        Assert.Contains("permissions.canEvaluate && !closed && plan !== null && scenario !== null", _details);
        Assert.Contains("!evaluationShownActive()", _details);
        Assert.Contains("!evaluationBlocked.has(", _details);
        Assert.DoesNotContain("status:", Slice(_details, "const buildScenarioBody", "const scenarioCheck"));
        Assert.DoesNotContain("status:", Slice(_details, "const buildEvaluateBody", "const evaluateCheck"));
    }

    [Fact]
    public void Bodies_follow_the_published_schemas()
    {
        var scenarioBody = Slice(_details, "const buildScenarioBody", "const scenarioCheck");
        Assert.Contains("constraintRefs: constraintRows().map(", scenarioBody); // always sent, [] when empty
        Assert.Contains("adjustments: adjustmentRows().map(", scenarioBody);
        Assert.Contains("availableCapacityDelta: cell(row, '.js-delta')", scenarioBody); // a JSON string as typed
        Assert.DoesNotContain("Number(", _details);
        Assert.DoesNotContain("parseFloat", _details);
        Assert.Contains("const DECIMAL_PATTERN = /^-?\\d+(\\.\\d+)?$/;", _details);
        Assert.Contains("const EVALUATION_MODES = Object.freeze(['Finite', 'Infinite']);", _details);
        Assert.Contains("resourceRefs: resourceRows().map(", _details);
        Assert.Contains("rows.length === 0", _details);
        Assert.DoesNotContain(".trim(", _details);
        Assert.DoesNotContain(".trim(", _index);
    }

    [Fact]
    public void No_native_dialog_and_no_confirmation_for_non_dangerous_actions()
    {
        foreach (var script in new[] { _index, _details })
        {
            Assert.DoesNotMatch(new Regex(@"(?<![\w.])(alert|confirm|prompt)\("), script);
            Assert.DoesNotContain("Swal.fire", script);
        }
    }

    [Fact]
    public void Idempotency_intents_reuse_key_for_identical_target_and_body_and_block_on_key_reuse()
    {
        Assert.Contains("current.target !== url || current.bodyText !== bodyText", _details);
        Assert.Contains("createIntent.bodyText !== bodyText", _index);
        Assert.Contains("failure.code === 'IDEMPOTENCY_KEY_REUSED'", _details);
        Assert.Contains("failure.code === 'IDEMPOTENCY_KEY_REUSED'", _index);
        Assert.Contains("'Idempotency-Key': key", _details);
        Assert.Contains("failure.code === 'EVALUATION_ALREADY_ACTIVE'", _details);
    }

    [Fact]
    public void Not_found_is_per_resource_and_late_responses_are_ignored()
    {
        Assert.Contains("if (gen !== generation.plan || closed) return;", _details);
        Assert.Contains("if (gen !== generation.scenario || closed) return;", _details);
        Assert.Contains("if (gen !== generation.evaluation || closed) return;", _details);
        Assert.Contains("failure.code === 'UNKNOWN_CAPACITY_PLAN') { closeWorkspace(failure); return true; }", _details);
        Assert.Contains("result.failure.code === 'UNKNOWN_CAPACITY_SCENARIO'", _details);
        Assert.Contains("result.failure.code === 'UNKNOWN_CAPACITY_EVALUATION'", _details);
        Assert.Contains("workspace.hidden = true;", _details);
    }

    [Theory]
    [InlineData("index.js")]
    [InlineData("details.js")]
    public void Every_published_error_code_is_localized(string file)
    {
        var script = Read(Js + file);
        Assert.All(PublishedCodes, code => Assert.Matches(new Regex($@"\b{code}: 'Err\w+'"), script));
    }

    [Theory]
    [InlineData("index.js")]
    [InlineData("details.js")]
    public void No_hard_coded_user_text(string file)
    {
        var script = Read(Js + file);
        Assert.DoesNotMatch(new Regex(@"showToast\?\.\('[A-Za-z]"), script);
        Assert.DoesNotMatch(new Regex(@"textContent = '[A-Za-z]"), script);
        Assert.DoesNotMatch(new Regex(@"textContent = `[A-Za-z]"), script);
    }

    [Theory]
    [InlineData("index.l10n.js", "capacity-index-l10n")]
    [InlineData("details.l10n.js", "capacity-details-l10n")]
    public void L10n_normalizer_warns_and_never_substitutes(string file, string payloadId)
    {
        var script = Read(Js + file);
        Assert.Contains($"document.getElementById('{payloadId}')", script);
        Assert.Contains("const requiredKeys", script);
        Assert.Contains("'ErrEvaluationAlreadyActive'", script);
        Assert.Contains("[L10N WARNING] Missing localization key", script);
    }

    // ── Q159: UI checklist r2 fixes (UI-PM-05, UI-PM-10) and the Details address (F-Q79-05 = A) ──────────────────

    [Fact]
    public void Section_skeletons_are_shown_through_display_not_only_d_none()
    {
        // UI-PM-05 (Q64d-D1 pattern): backbone-custom.css sets .backbone-skeleton { display: none }.
        var state = Slice(_details, "const setSectionState", "const closeWorkspace");
        Assert.Contains("skeleton.classList.toggle('d-none', state !== 'skeleton');", state);
        Assert.Contains("skeleton.style.display = state === 'skeleton' ? 'block' : 'none';", state);
    }

    [Fact]
    public void Rejected_submit_brings_focus_back_inside_the_open_panel()
    {
        // UI-PM-10 (Q122-D5 pattern): the disabled submit drops focus to BODY; finally re-enables and then restores focus.
        foreach (var script in new[] { _index, _details })
        {
            var restore = Slice(script, "const restorePanelFocus", "};");
            Assert.Contains("!panel.classList.contains('show') || panel.classList.contains('hiding')", restore);
            Assert.Contains("[aria-invalid=\"true\"]:not([disabled])", restore);
            Assert.Contains("submit && !submit.disabled ? submit :", restore);
            Assert.DoesNotContain("showConfirm", script);
        }
        Assert.Matches(new Regex(@"if \(submit\) submit\.disabled = false;\s*restorePanelFocus\('offcanvasCreatePlan', 'btnSubmitCreatePlan', 'planName'\);"),
            Slice(_index, "const submitCreate", "const handleCreateFailure"));
        Assert.Matches(new Regex(@"if \(submit\) submit\.disabled = false;\s*syncActions\(\);\s*restorePanelFocus\(panelId, submitId\);"),
            Slice(_details, "const postIntent", "// ─── Repeater rows"));
    }

    [Fact]
    public void Scenario_and_evaluation_ids_are_carried_in_the_details_address_only()
    {
        // F-Q79-05 = A (pack §23.4; CP-21…CP-23): replaceState on the query, UUID-only, no storage, no new request type.
        var write = Slice(_details, "const writeAddress", "let addressEvaluationId");
        Assert.Contains("if (isId(value)) url.searchParams.set(name, value);", write);
        Assert.Contains("window.history.replaceState(window.history.state, '', url.href)", write);
        Assert.DoesNotContain("pushState", _details);
        Assert.Contains("writeAddress({ scenarioId: scenario.scenarioId,", Slice(_details, "const loadScenario", "let lastScenarioId"));
        Assert.Contains("writeAddress({ evaluationId: evaluation.evaluationId });", Slice(_details, "const loadEvaluation", "// Text cell"));
        var open = Slice(_details, "const openFromAddress", "return {");
        Assert.Contains("new URLSearchParams(window.location.search)", open);
        Assert.Contains("if (isId(scenarioValue)) {", open);
        Assert.Contains("if (!isId(evaluationValue)) setSectionState('evaluation', 'error',", open);
        Assert.Contains("openFromAddress();", Slice(_details, "init: function", "document.addEventListener('DOMContentLoaded'"));
        Assert.Equal(2, Regex.Matches(_details, @"\bfetch\(").Count); // still only getJson + postIntent
    }

    private static string Slice(string text, string start, string end)
    {
        var from = text.IndexOf(start, StringComparison.Ordinal);
        Assert.True(from >= 0, start);
        var to = text.IndexOf(end, from, StringComparison.Ordinal);
        Assert.True(to > from, end);
        return text[from..to];
    }

    private static string Read(string path) => File.ReadAllText(Path.Combine(Root(), path));
    private static string Root() { var dir = new DirectoryInfo(AppContext.BaseDirectory); while (dir is not null && !File.Exists(Path.Combine(dir.FullName, "AGENTS.md"))) dir = dir.Parent; return dir?.FullName ?? throw new DirectoryNotFoundException(); }
}
