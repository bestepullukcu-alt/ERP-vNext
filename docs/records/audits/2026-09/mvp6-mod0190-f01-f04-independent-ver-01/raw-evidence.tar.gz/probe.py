import base64,hashlib,hmac,http.client,json,pathlib,subprocess,time,uuid
P=pathlib.Path('/private/tmp/mvp6-mod0190-f01-f04-ver-01')
scope=json.loads((P/'scope.json').read_text())
config=dict(line[7:].strip().split('=',1) for line in (P/'private.env').read_text().splitlines() if line.startswith('export '))
secret=config['JwtSettings__Secret']
COLS=['sandop_plans','sandop_snapshots','sandop_sign_offs','sandop_receipts','sandop_audit','sandop_outbox']
records=[];matrix=[]
def b64(obj):return base64.urlsafe_b64encode(json.dumps(obj,separators=(',',':')).encode()).rstrip(b'=').decode()
def jwt(permission):
 now=int(time.time());claims={'iss':config['JwtSettings__Issuer'],'aud':config['JwtSettings__Audience'],'sub':scope['actor'],'tenant_id':scope['tenant'],'legal_entity_id':scope['legalEntity'],'iat':now,'nbf':now-1,'exp':now+900,'permission':'supplychain.sandop-plans.'+permission}
 value=b64({'alg':'HS256','typ':'JWT'})+'.'+b64(claims)
 return value+'.'+base64.urlsafe_b64encode(hmac.new(secret.encode(),value.encode(),hashlib.sha256).digest()).rstrip(b'=').decode()
def call(tag,method,path,permission='read',body=None,key=None,correlations='valid',auth=True):
 payload=json.dumps(body,separators=(',',':')).encode('utf-8') if body is not None else b''
 headers=[('X-Tenant-Id',scope['tenant']),('X-Legal-Entity-Id',scope['legalEntity']),('Content-Type','application/json')]
 if correlations=='valid':headers.append(('X-Correlation-Id',str(uuid.uuid4())))
 elif correlations=='malformed':headers.append(('X-Correlation-Id','not-a-uuid'))
 elif correlations=='duplicate':headers.extend([('X-Correlation-Id',str(uuid.uuid4())),('X-Correlation-Id',str(uuid.uuid4()))])
 elif correlations!='missing':raise ValueError(correlations)
 if key is not None:headers.append(('Idempotency-Key',key))
 safe=list(headers)
 if auth:headers.append(('Authorization','Bearer '+jwt(permission)))
 headers.append(('Content-Length',str(len(payload))))
 conn=http.client.HTTPConnection('127.0.0.1',57983,timeout=20)
 conn.putrequest(method,path)
 for name,value in headers:conn.putheader(name,value)
 conn.endheaders(payload)
 res=conn.getresponse();raw=res.read();response_headers=dict(res.getheaders());conn.close()
 rec={'tag':tag,'method':method,'path':path,'requestHeaders':safe,'requestBodyUtf8':payload.decode(),'requestByteLength':len(payload),'requestBodySha256':hashlib.sha256(payload).hexdigest(),'status':res.status,'responseHeaders':response_headers,'responseBodyUtf8':raw.decode('utf-8','replace'),'responseByteLength':len(raw)}
 records.append(rec);(P/'http.json').write_text(json.dumps(records,indent=2));return rec
def code(rec):return json.loads(rec['responseBodyUtf8'])['error']['code']
def body(rec):return json.loads(rec['responseBodyUtf8'])
def mongo_eval(script,label):
 run=subprocess.run(['mongosh','--quiet','--port','57883','--eval',script],capture_output=True,text=True)
 (P/f'mongo-{label}.json').write_text(json.dumps({'exitCode':run.returncode,'stdout':run.stdout,'stderr':run.stderr},indent=2))
 if run.returncode!=0:raise RuntimeError((label,run.returncode,run.stderr))
 return json.loads(run.stdout.strip().splitlines()[-1])
def state(tag):
 q={'TenantId':scope['tenant'],'LegalEntityId':scope['legalEntity']}
 js='const q='+json.dumps(q)+';const d=db.getSiblingDB("DitenSupplyChain_Mod0190_Test");const n='+json.dumps(COLS)+';print(JSON.stringify(Object.fromEntries(n.map(x=>[x,{count:d.getCollection(x).countDocuments(q),docs:d.getCollection(x).find(q).sort({_id:1}).toArray()}]))));'
 value=mongo_eval(js,tag+'-query');(P/f'state-{tag}.json').write_text(json.dumps(value,indent=2));return value
def require(rec,status,expected_code=None):
 assert rec['status']==status,(rec['tag'],rec['status'],rec['responseBodyUtf8'])
 if expected_code:assert code(rec)==expected_code,(rec['tag'],code(rec),expected_code)
 if status!=401 and rec['requestHeaders'] and any(k=='X-Correlation-Id' for k,v in rec['requestHeaders']):
  valid=[v for k,v in rec['requestHeaders'] if k=='X-Correlation-Id']
  if len(valid)==1 and valid[0]!='not-a-uuid':assert rec['responseHeaders'].get('X-Correlation-Id')==valid[0],rec['tag']
def no_write(tag,make_call,status,expected_code):
 before=state(tag+'-before');rec=make_call();require(rec,status,expected_code);after=state(tag+'-after');assert before==after,(tag,'write detected');matrix.append({'id':tag,'status':status,'code':expected_code,'collections':COLS,'queryExitBefore':0,'queryExitAfter':0,'allCountsAndDocumentsEqual':True,'requestByteLength':rec['requestByteLength']});(P/'matrix.json').write_text(json.dumps(matrix,indent=2));return rec
def create_plan(year):
 value={'name':'FVER-'+str(year),'horizonStart':f'{year}-01-01','horizonEnd':f'{year}-12-31','demandPlanId':'dp-fver','demandPlanVersion':'1'}
 rec=call('setup-create-'+str(year),'POST','/api/supply-chain/sandop-plans','create',value,'setup-create-'+str(year));require(rec,201);return body(rec)['sandopPlanId']
def capture(plan,tag):
 value={'demandPlanId':'dp-fver','demandPlanVersion':'1','sourceCapturedAt':'2026-09-15T09:45:00Z','sourceChecksum':'sha256:fver','supplyInputRefs':[]}
 rec=call('setup-capture-'+tag,'POST','/api/supply-chain/sandop-plans/'+plan+'/snapshots','snapshot.capture',value,'setup-capture-'+tag);require(rec,201);return body(rec)['snapshotId'],value
def set_status(plan,status,tag):
 js='const d=db.getSiblingDB("DitenSupplyChain_Mod0190_Test");const r=d.sandop_plans.updateOne('+json.dumps({'_id':plan,'TenantId':scope['tenant'],'LegalEntityId':scope['legalEntity']})+','+json.dumps({'$set':{'Status':status}})+');print(JSON.stringify({matched:r.matchedCount,modified:r.modifiedCount}));'
 x=mongo_eval(js,'fixture-'+tag);assert x=={'matched':1,'modified':1},x
ROOT='/api/supply-chain/sandop-plans'
for index,status in enumerate(['Approved','Rejected','Archived']):
 plan=create_plan(2030+index);_,cap=capture(plan,'f01-'+status);set_status(plan,status,'f01-'+status)
 no_write('F01-'+status,lambda p=plan,v=cap,s=status:call('F01-'+s,'POST',ROOT+'/'+p+'/snapshots','snapshot.capture',v,'F01-'+s),409,'SANDOP_PLAN_STATE_CONFLICT')
for index,status in enumerate(['Draft','Approved','Rejected','Archived']):
 plan=create_plan(2040+index);snapshot,_=capture(plan,'f02-'+status);set_status(plan,status,'f02-'+status)
 sign={'snapshotId':snapshot,'role':'Finance','decision':'Approved'}
 no_write('F02-'+status,lambda p=plan,v=sign,s=status:call('F02-'+s,'POST',ROOT+'/'+p+'/sign-offs','sign-off.record',v,'F02-'+s),409,'SANDOP_SIGN_OFF_STATE_CONFLICT')
plan_a=create_plan(2050);plan_b=create_plan(2051);capture(plan_a,'f03-a');snapshot_b,_=capture(plan_b,'f03-b')
wrong={'snapshotId':snapshot_b,'role':'Finance','decision':'Approved'}
no_write('F03-wrong-plan-snapshot',lambda:call('F03-wrong-plan-snapshot','POST',ROOT+'/'+plan_a+'/sign-offs','sign-off.record',wrong,'F03-wrong-plan'),422,'INVALID_SNAPSHOT_REFERENCE')
request={'name':'FVER-correlation-negative','horizonStart':'2060-01-01','horizonEnd':'2060-12-31','demandPlanId':'dp-fver','demandPlanVersion':'1'}
for variant in ['missing','malformed','duplicate']:
 rec=no_write('F04-'+variant,lambda v=variant:call('F04-'+v,'POST',ROOT,'create',request,'F04-'+v,correlations=v),400,'INVALID_CORRELATION_ID')
 header=rec['responseHeaders'].get('X-Correlation-Id');value=body(rec)['error']['correlationId'];assert header==value,(variant,header,value);uuid.UUID(value);supplied=[v for k,v in rec['requestHeaders'] if k=='X-Correlation-Id'];assert value not in supplied,(variant,value,supplied)
 matrix[-1]['fallbackUuid']=value;matrix[-1]['fallbackHeaderBodyMatch']=True;(P/'matrix.json').write_text(json.dumps(matrix,indent=2))
parser=no_write('F04-parser-level-401',lambda:call('F04-parser-level-401','GET',ROOT+'/'+plan_a,'read',auth=False),401,None)
assert parser['responseHeaders'].get('WWW-Authenticate','').startswith('Bearer'),parser
matrix[-1]['classification']='parser-level challenge; application-generated 401 not reached';(P/'matrix.json').write_text(json.dumps(matrix,indent=2))
print('PROBE_PASS',len(matrix),'negative scenarios',len(records),'total HTTP requests')
