from stateful_model import Store
import json,copy
from pathlib import Path
R='ABCDEFAB-1234-4234-8234-ABCDEFABCDEF';W='abcdefac-1234-4234-8234-abcdefabcdef'
B={'shipmentId':R,'claimedAmount':'12.30','currency':'USD'}
checks=[];traces=[]
def ck(n,v):
 checks.append({'name':n,'pass':bool(v)});assert v,n
def create(s,**kw):
 d=dict(tenant='t',le='le',operation='create',target=None,key='create',root=R,body=B,grants={'create'});d.update(kw);return s.command(**d)
def trans(s,id,**kw):
 d=dict(tenant='t',le='le',operation='transition',target=id,key='transition',root=R,body={'targetStatus':'Investigating','occurredAt':'2026-09-20T12:00:00Z'},grants={'investigate'});d.update(kw);return s.command(**d)
s=Store();a=create(s);id=a['claimId'];b=trans(s,id);before=s.state()
ck('transition changed valid payload',trans(s,id,body={'targetStatus':'Investigating','occurredAt':'2026-09-20T12:00:01Z'})=={'status':409,'code':'IDEMPOTENCY_KEY_REUSED'})
ck('transition wrongroot changedpayload precedence',trans(s,id,root=W,body={'targetStatus':'Investigating','occurredAt':'2026-09-20T12:00:01Z'})=={'status':409,'code':'CLAIM_CORRELATION_MISMATCH'})
ck('transition UUID value replay',trans(s,id,root=R.lower())=={**b,'idempotentReplay':True})
ck('create original result after state advance',create(s)=={**a,'idempotentReplay':True})
ck('all replay and reject paths no writes',s.state()==before)
for op in ['create','transition']:
 for i,stage in enumerate(['aggregate','receipt','audit','outbox']):
  s=Store();id=create(s)['claimId'];before=s.state()
  call=(lambda **kw:create(s,key='next',**kw)) if op=='create' else (lambda **kw:trans(s,id,**kw))
  result=call(fail=stage);at=copy.deepcopy(s.attempts[-1]);traces.append({'operation':op,'failpoint':stage,'trace':at})
  ck(op+' '+stage+' rollback full existing state',result['status']==503 and s.state()==before and not at['committed'])
  ck(op+' '+stage+' exact executed prefix',[x['stage'] for x in at['stages']]==['aggregate','receipt','audit','outbox'][:i+1])
  expected=[(2 if op=='create' else 1),2 if i>=1 else 1,2 if i>=2 else 1,2 if i>=3 else 1]
  ck(op+' '+stage+' observed write counts',at['stages'][-1]['counts']==expected)
  ck(op+' '+stage+' retry creates result',call()['status']==(201 if op=='create' else 200))
 for loss in ['unknown-commit','postcommit-response-loss']:
  s=Store();id=create(s)['claimId'];call=(lambda **kw:create(s,key='next',**kw)) if op=='create' else (lambda **kw:trans(s,id,**kw))
  r=call(loss=loss);before=s.state();receipt=list(s.receipts.values())[-1]['result'];ck(op+' '+loss+' committed',r['status']==503 and s.attempts[-1]['committed'] and list(map(len,before))==([2,2,2,2] if op=='create' else [1,2,2,2]))
  ck(op+' '+loss+' samekey recovery',call()=={**receipt,'idempotentReplay':True} and s.state()==before)
Path('independent-results.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'stageTraces':traces},indent=2)+'\n');print('PASS',len(checks))
