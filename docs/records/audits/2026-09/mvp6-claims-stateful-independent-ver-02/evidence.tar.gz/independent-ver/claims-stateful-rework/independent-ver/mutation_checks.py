from pathlib import Path
import tempfile,shutil,subprocess,json
p=Path(__file__).parent;s=(p/'stateful_model.py').read_text();results=[]
mutations={
'accept-changed-payload':("if receipt['fingerprint']!=fp:","if False:"),
'root-precedence-lost':("if receipt['root']!=root:","if False:"),
'collapsed-failpoints':("if fail==name:raise Fault(name)","if fail is not None:raise Fault(name)"),
'rollback-disabled':("self.aggregates,self.receipts,self.audit,self.outbox=before;attempt['rollback']=True","attempt['rollback']=False"),
'unknown-means-zero':("if loss in ['unknown-commit','postcommit-response-loss']:return", "if loss in ['unknown-commit','postcommit-response-loss']:\n   self.aggregates,self.receipts,self.audit,self.outbox=before\n   return"),
'auth-bypass':("if required not in grants:","if False:"),
'root-lexical':("root=str(uuid.UUID(root));scope=", "scope=")}
for name,(old,new) in mutations.items():
 assert s.count(old)==1,name
 d=Path(tempfile.mkdtemp(prefix='mut-'+name+'-',dir=p));shutil.copytree(p/'original',d/'original');shutil.copy2(p/'test_stateful.py',d/'test_stateful.py');(d/'stateful_model.py').write_text(s.replace(old,new));run=subprocess.run(['python3',str(d/'test_stateful.py')],capture_output=True,text=True);(d/'stdout.txt').write_text(run.stdout);(d/'stderr.txt').write_text(run.stderr);results.append({'mutation':name,'exit':run.returncode,'caught':run.returncode!=0,'reason':run.stderr.splitlines()[-1] if run.stderr else ''})
assert all(x['caught'] and 'AssertionError' in x['reason'] for x in results)
(p/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n');print('mutations',len(results),'caught')
