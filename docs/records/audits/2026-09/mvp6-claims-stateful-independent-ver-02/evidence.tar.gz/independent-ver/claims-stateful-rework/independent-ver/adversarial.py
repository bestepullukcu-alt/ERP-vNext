from stateful_model import *
root='12345678-1234-4234-8234-123456789abc'; other='12345678-1234-4234-8234-123456789def'
b={'shipmentId':root,'claimedAmount':'1','currency':'USD'}
def c(s,**x):
 a=dict(tenant='t',le='l',operation='create',target=None,key='k',root=root,body=b,grants={'create'});a.update(x);return s.command(**a)
checks=[]
def ck(name,v):
 assert v,name
 checks.append(name)
for fail in ['aggregate','receipt','audit','outbox']:
 s=Store();aid=c(s)['claimId'];before=s.state()
 args=dict(operation='transition',target=aid,body={'targetStatus':'Investigating','occurredAt':'2026-09-20T00:00:00Z'},grants={'investigate'})
 ck('transition rollback '+fail,c(s,fail=fail,**args)['status']==503 and s.state()==before)
 ck('transition retry '+fail,c(s,**args)['status']==200)
s=Store();aid=c(s)['claimId'];args=dict(operation='transition',target=aid,body={'targetStatus':'Investigating','occurredAt':'2026-09-20T00:00:00Z'},grants={'investigate'})
orig=c(s,**args);state=s.state()
changed={**args,'body':{**args['body'],'note':'valid changed note'}}
ck('transition changed note',c(s,**changed)['code']=='IDEMPOTENCY_KEY_REUSED')
ck('transition wrong root priority',c(s,root=other,**changed)['code']=='CLAIM_CORRELATION_MISMATCH')
ck('transition replay uppercase target/root',c(s,**{**args,'target':aid.upper()},root=root.upper())=={**orig,'idempotentReplay':True})
ck('no state change rejected/replay',s.state()==state)
for loss in ['unknown-commit','postcommit-response-loss']:
 s=Store();aid=c(s)['claimId'];args['target']=aid;lost=c(s,loss=loss,**args);state=s.state()
 ck(loss+' transition committed',lost['status']==503 and s.aggregates[('t','l',aid)]['status']=='Investigating' and list(map(len,state))==[1,2,2,2])
 ck(loss+' transition recovery',c(s,**args)['idempotentReplay'] and s.state()==state)
Path('adversarial-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2))
print('PASS',len(checks))
