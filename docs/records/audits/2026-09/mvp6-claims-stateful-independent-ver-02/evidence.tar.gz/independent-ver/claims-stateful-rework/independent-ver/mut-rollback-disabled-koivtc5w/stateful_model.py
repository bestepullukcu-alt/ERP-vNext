"""Approved Claims candidate semantics; in-memory model, not persistence proof."""
import copy,json,uuid,hashlib
from pathlib import Path
POLICY=json.loads((Path(__file__).parent/'original/claims-r2/policy-oracle.json').read_text())
class Fault(Exception):pass
def fingerprint(body,operation):
 d=copy.deepcopy(body)
 for k in (['carrierId'] if operation=='create' else ['approvedAmount','resolutionCode','note']):d.setdefault(k,None)
 if operation=='create':d.setdefault('evidenceReferenceIds',[])
 for k in ['shipmentId','carrierId']:
  if d.get(k) is not None:d[k]=str(uuid.UUID(d[k]))
 # Amount and occurredAt remain decoded original text, never numeric/instant normalized.
 return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
class Store:
 def __init__(self):self.aggregates={};self.receipts={};self.audit=[];self.outbox=[];self.attempts=[]
 def state(self):return copy.deepcopy((self.aggregates,self.receipts,self.audit,self.outbox))
 def command(self,tenant,le,operation,target,key,root,body,actor='a',grants=(),fail=None,loss=None):
  if fail not in [None,'aggregate','receipt','audit','outbox']:raise ValueError('unknown failpoint')
  required='create' if operation=='create' else POLICY['permissions'][body['targetStatus']]
  if required not in grants:return {'status':403,'code':'FORBIDDEN'}
  root=str(uuid.UUID(root));scope=(tenant,le,operation,'create' if operation=='create' else str(uuid.UUID(target)),key);fp=fingerprint(body,operation)
  if scope in self.receipts:
   receipt=self.receipts[scope]
   if receipt['root']!=root:return {'status':409,'code':'CLAIM_CORRELATION_MISMATCH'}
   if receipt['fingerprint']!=fp:return {'status':409,'code':'IDEMPOTENCY_KEY_REUSED'}
   result=copy.deepcopy(receipt['result']);result['idempotentReplay']=True;return result
  before=self.state();stages=[];attempt={'scope':scope,'stages':stages,'committed':False};self.attempts.append(attempt)
  aid=str(uuid.uuid4()) if operation=='create' else str(uuid.UUID(target));ak=(tenant,le,aid)
  if operation!='create':
   if ak not in self.aggregates:return {'status':404,'code':'CLAIM_NOT_FOUND'}
   if self.aggregates[ak]['root']!=root:return {'status':409,'code':'CLAIM_CORRELATION_MISMATCH'}
   if [self.aggregates[ak]['status'],body['targetStatus']] not in POLICY['edges']:return {'status':422,'code':'INVALID_CLAIM_TRANSITION'}
  result={'status':201 if operation=='create' else 200,'claimId':aid,'claimStatus':'Open' if operation=='create' else body['targetStatus'],'idempotentReplay':False}
  def boundary(name):
   stages.append({'stage':name,'counts':[len(self.aggregates),len(self.receipts),len(self.audit),len(self.outbox)]})
   if fail==name:raise Fault(name)
  try:
   if operation=='create':self.aggregates[ak]={'root':root,'body':copy.deepcopy(body),'status':'Open','actor':actor}
   else:self.aggregates[ak]['status']=body['targetStatus']
   boundary('aggregate')
   self.receipts[scope]={'root':root,'fingerprint':fp,'result':copy.deepcopy(result),'actor':actor};boundary('receipt')
   self.audit.append({'claimId':aid,'actor':actor,'body':copy.deepcopy(body),'root':root});boundary('audit')
   self.outbox.append({'claimId':aid,'status':'Pending','root':root});boundary('outbox')
  except Fault:
   attempt['rollback']=False
   return {'status':503,'code':'CLAIM_STORAGE_UNAVAILABLE'}
  attempt['committed']=True
  if loss in ['unknown-commit','postcommit-response-loss']:return {'status':503,'code':'CLAIM_STORAGE_UNAVAILABLE','outcome':'unknown to caller'}
  return result
