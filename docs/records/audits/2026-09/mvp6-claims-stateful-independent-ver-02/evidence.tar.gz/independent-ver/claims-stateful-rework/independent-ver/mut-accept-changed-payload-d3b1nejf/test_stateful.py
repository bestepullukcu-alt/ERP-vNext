from stateful_model import *
import ast,sys
P=Path(__file__).parent;checks=[]
def ck(n,v):
 checks.append({'name':n,'pass':bool(v)});assert v,n
root='aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa';other='bbbbbbbb-1111-4111-8111-aaaaaaaaaaaa';body={'shipmentId':root,'claimedAmount':'1','currency':'USD'}
def cmd(s,**kwargs):
 args=dict(tenant='t',le='le',operation='create',target=None,key='k',root=root,body=body,grants={'create'});args.update(kwargs);return s.command(**args)
s=Store();first=cmd(s);before=s.state();changed={**body,'claimedAmount':'999'}
ck('changed valid payload conflict',cmd(s,body=changed)=={'status':409,'code':'IDEMPOTENCY_KEY_REUSED'} and s.state()==before)
ck('root before changed payload',cmd(s,root=other,body=changed)=={'status':409,'code':'CLAIM_CORRELATION_MISMATCH'})
replay=cmd(s,actor='other',root=root.upper());ck('original result replay',replay=={**first,'idempotentReplay':True} and s.state()==before)
ck('current auth before replay',cmd(s,grants=set())['status']==403)
ck('lexical amount conflict',cmd(s,body={**body,'claimedAmount':'1.00'})['code']=='IDEMPOTENCY_KEY_REUSED')
ck('nullable and evidence defaults',cmd(s,body={**body,'carrierId':None,'evidenceReferenceIds':[]})['idempotentReplay'])
for field,val in [('tenant','t2'),('le','le2'),('key','k2')]:ck('receipt scope '+field,cmd(s,**{field:val})['status']==201)
aid=first['claimId'];tr={'targetStatus':'Investigating','occurredAt':'2026-09-20T00:00:00Z'}
r=cmd(s,operation='transition',target=aid,key='k',body=tr,grants={'investigate'});ck('operation scope and transition',r['status']==200)
ck('transition changed lexical time',cmd(s,operation='transition',target=aid,key='k',body={**tr,'occurredAt':'2026-09-20T03:00:00+03:00'},grants={'investigate'})['code']=='IDEMPOTENCY_KEY_REUSED')
ck('transition identical replay',cmd(s,operation='transition',target=aid,key='k',body=tr,grants={'investigate'})=={**r,'idempotentReplay':True})
second=cmd(s,key='second')['claimId'];ck('target distinct scope',cmd(s,operation='transition',target=second,key='k',body=tr,grants={'investigate'})['status']==200)
for i,fail in enumerate(['aggregate','receipt','audit','outbox']):
 st=Store();cmd(st,key='existing');before=st.state();result=cmd(st,key='fault',fail=fail);attempt=st.attempts[-1]
 ck('rollback '+fail,result['status']==503 and st.state()==before and not attempt['committed'])
 ck('reached exact prefix '+fail,[x['stage'] for x in attempt['stages']]==['aggregate','receipt','audit','outbox'][:i+1])
 ck('actual writes before fault '+fail,attempt['stages'][-1]['counts']==[2 if j<=i else 1 for j in range(4)])
 ck('retry after rollback '+fail,cmd(st,key='fault')['status']==201)
for loss in ['unknown-commit','postcommit-response-loss']:
 st=Store();r=cmd(st,loss=loss);state=st.state();ck(loss+' committed state',r['status']==503 and list(map(len,state))==[1,1,1,1] and st.attempts[-1]['committed'])
 ck(loss+' samekey recovery',cmd(st)['idempotentReplay'] and st.state()==state)
# RED: execute ONLY archived Store class AST; do not run archived harness/commands.
old=Path(P/'original/claims-r2/verify-r2.py').read_text();tree=ast.parse(old);node=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Store');ns={'copy':copy};exec(compile(ast.Module(body=[node],type_ignores=[]),'historical Store','exec'),ns)
legacy=ns['Store'](POLICY);legacy.create('t','k','1');observed=legacy.create('t','k','999');ck('RED legacy changedpayload oracle fails',observed!=409)
# Old failpoints have same unconditional branch, no observed stage prefix instrumentation.
fn=node.body[1];faults=[n for n in ast.walk(fn) if isinstance(n,ast.If) and ast.unparse(n.test)=='fail is not None'];ck('RED legacy unconditional failpoint branch',len(faults)==1)
(P/'stateful-results.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'red':{'legacyChangedPayloadObserved':observed,'expected':409,'legacyFaultStageEvidence':'absent; same fail is not None branch'},'evidence':'E1/E2 model only'},indent=2)+'\n');print('PASS',len(checks))
