# Claims R2 stateful model rework01 — NEW E1/E2 evidence
Old candidate/archive, recovered model, YAML/patch/annex unchanged. original/claims-r2 is a verified immutable copy.
New stateful_model.py/test_stateful.py supersede ONLY the deficient Store evidence in original verify-r2.py: do not call
its old STATE-precommit checks distinct-stage proof or its old STATE-replay integrated payload proof.
Run python3 test_stateful.py then python3 mutation_checks.py in a disposable extraction. No credentials/DB/network used.
Valid command/pre-resolved reference boundary is explicit; no new business validation/defaults introduced. Other business
policies remain in inherited candidate and classification; this narrow model does not claim full transition amount handling.
RED old Store returns201 for changed amount999; AST shows fail is not None single branch/no reached-stage instrumentation.
GREEN35checks: integrated receipt/root/fingerprint/current-grant, scope, original result, separate writes, rollback, unknown.
7negative mutants killed by assertion failures, including collapsed failpoints and disabled rollback. stage-evidence records
actual prefixes/counts. Unknown/postcommit503 follows a committed model state; same-key retry recovers original result.
No historical or fresh model result is Mongo transaction/concurrency/HTTP/JWT/uptake evidence. Pending only, no workers.
Separate verifier report is archived with this handoff. Publication/consumer consent/guard/runtime/rollout remain excluded.
