using MongoDB.Bson;
using MongoDB.Driver;
using Diten.SupplyChainService.Domain.Features.CapacityPlans;
using Diten.SupplyChainService.Infrastructure.Features.CapacityPlans;
using Diten.SupplyChainService.Persistence.Features.CapacityPlans;
using Xunit;
namespace Diten.SupplyChainService.Tests.CapacityPlans;
[Collection("CapacityMongo")]
public sealed class CapacityAtomicityTests
{
    [Fact]
    public async Task Fixture_mutations_and_fenced_terminal_are_durable_and_single_effect()
    {
        var client=new MongoClient("mongodb://127.0.0.1:57192/?replicaSet=rsmod192&serverSelectionTimeoutMS=5000");
        var db=client.GetDatabase("DitenSupplyChain_Mod0192_Test");
        foreach(var name in new[]{"capacity_plans","capacity_scenarios","capacity_evaluations","capacity_receipts","capacity_active_slots","capacity_audit","capacity_outbox"})
            await db.DropCollectionAsync(name);
        var schema=new CapacitySchema(db);await schema.StartAsync(CancellationToken.None);
        var demand=new DemandFixtureReader();var constraints=new ConstraintFixtureReader();
        var repo=new CapacityRepository(db,demand,constraints);
        var leases=new CapacityLeaseStore(db);
        var scope=new CapacityScope(DemandFixtureReader.Tenant,DemandFixtureReader.LegalEntity,Guid.NewGuid());
        var correlation=Guid.NewGuid();
        var plan=new CapacityPlan {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            Name="FY2027 Capacity Baseline",HorizonStart=new DateOnly(2027,1,1),HorizonEnd=new DateOnly(2027,12,31),
            DemandPlanId="dp-2027",DemandPlanVersion="3",SourceCapturedAt=DateTimeOffset.UtcNow,
            SourceChecksum="sha256:ee56d4f9a3c8",CreatedAt=DateTimeOffset.UtcNow,Version=1,CreatedBy=scope.ActorId};
        var created=await repo.CreatePlanAsync(scope,"plan-key","fp-plan",correlation,plan,CancellationToken.None);
        Assert.Equal(201,created.StatusCode);
        Assert.Equal(plan.Id,created.Value!.Id);
        var replay=await repo.CreatePlanAsync(scope,"plan-key","fp-plan",Guid.NewGuid(),new CapacityPlan(),CancellationToken.None);
        Assert.True(replay.Replay);
        Assert.Equal(plan.Id,replay.Value!.Id);
        var changed=await repo.CreatePlanAsync(scope,"plan-key","different",Guid.NewGuid(),new CapacityPlan(),CancellationToken.None);
        Assert.Equal("IDEMPOTENCY_KEY_REUSED",changed.ErrorCode);
        var scenario=new CapacityScenario {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            CapacityPlanId=plan.Id,Name="Add weekend shift",CreatedAt=DateTimeOffset.UtcNow,Version=1,CreatedBy=scope.ActorId,
            ConstraintRefs=[new("line-4-hours","SUPPLY-CONSTRAINTS","8")],
            Adjustments=[new("line-4","2027-W03","80.000","HOUR")]};
        var scenarioResult=await repo.CreateScenarioAsync(scope,plan.Id,"scenario-key","fp-scenario",correlation,scenario,CancellationToken.None);
        Assert.Equal(201,scenarioResult.StatusCode);
        var evaluation=new CapacityEvaluation {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            CapacityPlanId=plan.Id,ScenarioId=scenario.Id,EvaluationMode="Finite",ResourceRefs=["line-4"],
            SubmittedAt=DateTimeOffset.UtcNow,CreatedAt=DateTimeOffset.UtcNow,Version=1,CorrelationId=correlation};
        var accepted=await repo.EvaluateAsync(scope,plan.Id,scenario.Id,"eval-key","fp-eval",correlation,evaluation,CancellationToken.None);
        Assert.Equal(202,accepted.StatusCode);
        var second=await repo.EvaluateAsync(scope,plan.Id,scenario.Id,"other-key","other-fp",correlation,evaluation,CancellationToken.None);
        Assert.Equal("EVALUATION_ALREADY_ACTIVE",second.ErrorCode);
        var lease=await leases.ClaimAsync(scope,CancellationToken.None);
        Assert.NotNull(lease);Assert.Equal(1,lease.Attempt);Assert.Equal("Running",lease.Status);
        var bottleneck=new CapacityBottleneck("line-4","2027-W03","520.000","480.000","40.000","HOUR");
        Assert.True(await leases.TerminalAsync(scope,evaluation.Id,lease.Version,lease.Fence,"Completed",[bottleneck],false,CancellationToken.None));
        Assert.False(await leases.TerminalAsync(scope,evaluation.Id,lease.Version,lease.Fence,"Completed",[bottleneck],false,CancellationToken.None));
        var terminal=await repo.GetEvaluationAsync(scope,plan.Id,evaluation.Id,CancellationToken.None);
        Assert.Equal("Completed",terminal!.Status);Assert.Equal("40.000",terminal.Bottlenecks.Single().Shortfall);
        Assert.Equal(0,await db.GetCollection<BsonDocument>("capacity_active_slots").CountDocumentsAsync(FilterDefinition<BsonDocument>.Empty));
        Assert.Equal(1,await db.GetCollection<BsonDocument>("capacity_outbox").CountDocumentsAsync(new BsonDocument("EventType","capacity.evaluation.completed.v1")));
        Assert.Equal(1,await db.GetCollection<BsonDocument>("capacity_audit").CountDocumentsAsync(new BsonDocument("Operation","terminalCapacityEvaluation")));
        // A new key is eligible only after the first terminal transaction released its slot.
        var retryEvaluation=new CapacityEvaluation {Id=Guid.NewGuid(),TenantId=scope.TenantId,LegalEntityId=scope.LegalEntityId,
            CapacityPlanId=plan.Id,ScenarioId=scenario.Id,EvaluationMode="Infinite",ResourceRefs=["line-4"],
            SubmittedAt=DateTimeOffset.UtcNow,CreatedAt=DateTimeOffset.UtcNow,Version=1,CorrelationId=correlation};
        Assert.Equal(202,(await repo.EvaluateAsync(scope,plan.Id,scenario.Id,"eval-key-2","fp-eval-2",correlation,retryEvaluation,CancellationToken.None)).StatusCode);
        var competing=new CapacityLeaseStore(db);
        var claims=await Task.WhenAll(leases.ClaimAsync(scope,CancellationToken.None),competing.ClaimAsync(scope,CancellationToken.None));
        Assert.Single(claims, x=>x is not null);
        var active=claims.Single(x=>x is not null)!;
        Assert.Equal(1,active.Attempt);
        Assert.Null(await leases.RenewAsync(scope,new CapacityEvaluation {Id=active.Id,TenantId=active.TenantId,LegalEntityId=active.LegalEntityId,Version=active.Version-1,Fence=active.Fence},CancellationToken.None));
        for(var attempt=2;attempt<=3;attempt++)
        {
            await db.GetCollection<CapacityEvaluation>("capacity_evaluations").UpdateOneAsync(
                Builders<CapacityEvaluation>.Filter.Eq(x=>x.Id,retryEvaluation.Id),
                Builders<CapacityEvaluation>.Update.Set(x=>x.LeaseUntil,DateTime.UtcNow.AddMinutes(-1)));
            active=(await leases.ClaimAsync(scope,CancellationToken.None))!;
            Assert.NotNull(active);Assert.Equal(attempt,active.Attempt);
        }
        await db.GetCollection<CapacityEvaluation>("capacity_evaluations").UpdateOneAsync(
            Builders<CapacityEvaluation>.Filter.Eq(x=>x.Id,retryEvaluation.Id),
            Builders<CapacityEvaluation>.Update.Set(x=>x.LeaseUntil,DateTime.UtcNow.AddMinutes(-1)));
        Assert.Null(await leases.ClaimAsync(scope,CancellationToken.None));
        var exhausted=await repo.GetEvaluationAsync(scope,plan.Id,retryEvaluation.Id,CancellationToken.None);
        Assert.Equal("Failed",exhausted!.Status);Assert.Equal(3,exhausted.Attempt);
        Assert.Equal(0,await db.GetCollection<BsonDocument>("capacity_active_slots").CountDocumentsAsync(FilterDefinition<BsonDocument>.Empty));
        Assert.Equal(2,await db.GetCollection<BsonDocument>("capacity_outbox").CountDocumentsAsync(new BsonDocument("EventType","capacity.evaluation.completed.v1")));
        Assert.Null(await repo.GetPlanAsync(new CapacityScope(Guid.NewGuid(),scope.LegalEntityId,scope.ActorId),plan.Id,CancellationToken.None));
    }
}
