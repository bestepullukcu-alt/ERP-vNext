using Diten.Platform.Application.Features.Tasks;
using System.Text;
using Diten.BuildingBlocks.BackgroundJobs;
using Diten.BuildingBlocks.Security.Secrets;
using Diten.Platform.Application.Contracts;
using Diten.Platform.Application.Contracts.Audit;
using Diten.Platform.Application.Features.Lookups.Services;
using Diten.Platform.Application.Features.EntitlementAttestations;
using Diten.Platform.Application.Features.Notifications.Services;
using Diten.Platform.Application.Features.WorkingCalendar.Services;
using Diten.Platform.Application.Features.WorkingCalendarImport;
using Diten.Platform.Application.Features.TenantOrganization.Services;
using Diten.Platform.Application.Contracts.Eventing;
using Diten.Platform.Application.Common;
using Diten.Platform.Application.Services;
using Diten.Platform.Application.Services.Eventing;
using Diten.Platform.Domain.Repositories;
using Diten.Platform.Infrastructure.Eventing;
using Diten.Platform.Infrastructure.Authorization;
using Diten.Platform.Infrastructure.BackgroundJobs;
using Diten.Platform.Infrastructure.Persistence;
using Diten.Platform.Infrastructure.Persistence.Configurations;
using Diten.Platform.Infrastructure.Persistence.Repositories;
using Diten.Platform.Infrastructure.Persistence.Repositories.BusinessReferenceData;
using Diten.Platform.Infrastructure.Persistence.Settings;
using Diten.Platform.Infrastructure.Services;
using Diten.Platform.Infrastructure.Services.Audit;
using Diten.Platform.Infrastructure.Services.WorkAggregation;
using Diten.Platform.Infrastructure.Services.Mdm;
using Diten.Platform.Infrastructure.Services.WorkingCalendarImport;
using Diten.Platform.Infrastructure.Services.Notifications;
using Diten.Platform.Infrastructure.Settings;
using Diten.Platform.Common.Authorization;
using Diten.Platform.Common.Tenancy;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using MassTransit;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;
using MongoDB.Driver;
using Microsoft.Extensions.Options;
using Hangfire;
using Hangfire.Mongo;
using Hangfire.Mongo.Migration.Strategies;
using Hangfire.Mongo.Migration.Strategies.Backup;
using EventOutboxStore = Diten.BuildingBlocks.Eventing.IEventOutboxStore;
using EventOutboxWriter = Diten.BuildingBlocks.Eventing.IEventOutboxWriter;
using TrustedTransportMetadataProvider = Diten.BuildingBlocks.Eventing.ITrustedTransportMetadataProvider;
using EmptyTrustedTransportMetadataProvider = Diten.BuildingBlocks.Eventing.EmptyTrustedTransportMetadataProvider;

namespace Diten.Platform.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration, IHostEnvironment environment)
    {
        services.AddSecretsProvider(configuration, environment, options => options.ServiceName = "Platform");
        services.ValidateRequiredSecrets(configuration, environment, "Platform", BuildSecretRequirements(configuration));

        var jwtSecret = configuration["JwtSettings:Secret"]
            ?? throw new InvalidOperationException("Configuration error: 'JwtSettings:Secret' is missing in appsettings.json.");
        var jwtIssuer = configuration["JwtSettings:Issuer"]
            ?? throw new InvalidOperationException("Configuration error: 'JwtSettings:Issuer' is missing in appsettings.json.");
        var jwtAudience = configuration["JwtSettings:Audience"]
            ?? throw new InvalidOperationException("Configuration error: 'JwtSettings:Audience' is missing in appsettings.json.");
        var jwtRotationResolver = new JwtSecretRotationResolver(configuration);

        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.MapInboundClaims = false;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwtIssuer,
                    ValidAudience = jwtAudience,
                    IssuerSigningKeys = jwtRotationResolver.GetValidationKeys(),
                    ClockSkew = JwtValidationDefaults.ClockSkew
                };
            });

        services.AddAuthorization(options =>
        {
            options.AddPolicy("PlatformActor", policy =>
            {
                policy.RequireAuthenticatedUser();
                policy.RequireAssertion(context =>
                {
                    var actorType = context.User.Claims
                        .FirstOrDefault(claim => string.Equals(claim.Type, "actor_type", StringComparison.OrdinalIgnoreCase))
                        ?.Value;

                    return string.Equals(actorType, "platform_admin", StringComparison.OrdinalIgnoreCase)
                           || string.Equals(actorType, "partner_admin", StringComparison.OrdinalIgnoreCase);
                });
            });

            // Phase 5 baseline policy: audit endpoints accept ONLY platform_admin.
            // Partner admin audit scope support (per-tenant filter, partner-scoped redaction)
            // is follow-up; see MOD-0021 Phase 5A review H1/H2.
            options.AddPolicy("PlatformAdminOnly", policy =>
            {
                policy.RequireAuthenticatedUser();
                policy.RequireAssertion(context =>
                {
                    var actorType = context.User.Claims
                        .FirstOrDefault(claim => string.Equals(claim.Type, "actor_type", StringComparison.OrdinalIgnoreCase))
                        ?.Value;

                    return string.Equals(actorType, "platform_admin", StringComparison.OrdinalIgnoreCase);
                });
            });
        });
        services.AddSingleton<IAuthorizationPolicyProvider, EntitlementAuthorizationPolicyProvider>();
        services.AddScoped<IAuthorizationHandler, TenantModuleAuthorizationHandler>();
        services.AddScoped<IAuthorizationHandler, TenantFeatureAuthorizationHandler>();
        services.AddScoped<IEntitlementAuditSink, PlatformEntitlementAuditSink>();
        services.AddHttpContextAccessor();
        services.AddMemoryCache();
        services.Configure<EntitlementCacheOptions>(configuration.GetSection(EntitlementCacheOptions.SectionName));
        services.Configure<TenantManagementOptions>(configuration.GetSection(TenantManagementOptions.SectionName));
        services.Configure<AuditRetentionSeedOptions>(configuration.GetSection(AuditRetentionSeedOptions.SectionName));
        services.Configure<BusinessReferenceDataCatalogLoadOptions>(configuration.GetSection(BusinessReferenceDataCatalogLoadOptions.SectionName));
        services.Configure<BusinessReferenceDataProviderOptions>(configuration.GetSection(BusinessReferenceDataProviderOptions.SectionName));
        services.AddSingleton<IValidateOptions<BusinessReferenceDataProviderOptions>, BusinessReferenceDataProviderOptionsValidator>();
        services.Configure<SmtpOptions>(configuration.GetSection(SmtpOptions.SectionName));
        services.Configure<AuthServiceOptions>(configuration.GetSection(AuthServiceOptions.SectionName));
        // MOD-0024 §12 K2 — which workflow template task approval starts. A tenant that designs its own flow in
        // the Workflow Designer overrides Tasks:Approval:TemplateCode; the built-in default is only a fallback.
        services.Configure<Diten.Platform.Application.Features.Tasks.Services.TaskApprovalOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.Tasks.Services.TaskApprovalOptions.SectionName));
        // Faz 3b — which workflow template task REVIEW starts. Same override story as approval above, under its
        // own section so a tenant can point review and approval at different flows.
        services.Configure<Diten.Platform.Application.Features.Tasks.Services.TaskReviewOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.Tasks.Services.TaskReviewOptions.SectionName));
        // BL-023 Part B — the upward work-request template code, on the same terms as the two above.
        services.Configure<Diten.Platform.Application.Features.Tasks.Services.TaskUpwardRequestOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.Tasks.Services.TaskUpwardRequestOptions.SectionName));
        // WC-2 — how far ahead of a deadline the warning window opens. A POLICY a tenant may tune, which is why
        // it is here and not declared in the executable contract (the contract declares the state VOCABULARY).
        services.Configure<Diten.Platform.Application.Features.WorkAggregation.Services.WorkItemSlaOptions>(
            configuration.GetSection(
                Diten.Platform.Application.Features.WorkAggregation.Services.WorkItemSlaOptions.SectionName));
        // WC-D3 (DCP-004 §2 D3) — the per-provider timeout the aggregation handler enforces. Bound here on the
        // same terms as the SLA window above: an operator's judgement about how long a reader waits for ONE
        // source, which differs between an in-process Mongo read and the first network-backed provider.
        services.Configure<Diten.Platform.Application.Features.WorkAggregation.Services.WorkAggregationResilienceOptions>(
            configuration.GetSection(
                Diten.Platform.Application.Features.WorkAggregation.Services.WorkAggregationResilienceOptions.SectionName));
        services.Configure<MdmServiceOptions>(configuration.GetSection(MdmServiceOptions.SectionName));
        services.Configure<MdmServiceIdentityOptions>(configuration.GetSection(MdmServiceIdentityOptions.SectionName));
        services.Configure<FakeMessagingProviderOptions>(configuration.GetSection(FakeMessagingProviderOptions.SectionName));
        services.AddOptions<SmtpProviderOptions>()
            .Bind(configuration.GetSection(SmtpProviderOptions.SectionName))
            .ValidateOnStart();
        services.AddSingleton<IValidateOptions<SmtpProviderOptions>, SmtpProviderOptionsValidator>();
        services.Configure<EventBusOptions>(configuration.GetSection(EventBusOptions.SectionName));
        services.Configure<RabbitMqEventingOptions>(configuration.GetSection(RabbitMqEventingOptions.SectionName));
        services.Configure<BackgroundJobSchedulerOptions>(configuration.GetSection(BackgroundJobSchedulerOptions.SectionName));
        services.AddOptions<WorkingCalendarImportOptions>()
            .Bind(configuration.GetSection(WorkingCalendarImportOptions.SectionName))
            .ValidateOnStart();
        services.AddSingleton<IValidateOptions<WorkingCalendarImportOptions>, WorkingCalendarImportOptionsValidator>();
        // MOD-0029-FU01 — controlled-document feature flags + Phase 1 content-storage options.
        services.Configure<Diten.Platform.Application.Features.DocumentManagementControlledDocuments.ControlledDocumentsFeatureFlagOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementControlledDocuments.ControlledDocumentsFeatureFlagOptions.SectionName));
        // MOD-0262-FU01 — content storage options relocated to the DocumentRepository contract namespace (AD-8 / OD-A).
        services.Configure<Diten.Platform.Application.Contracts.DocumentRepository.ContentStorageOptions>(
            configuration.GetSection(Diten.Platform.Application.Contracts.DocumentRepository.ContentStorageOptions.SectionName));
        // MOD-0029-FU04 — access matrix rollout/enforcement mode (defaults to Compatibility when unset).
        services.Configure<Diten.Platform.Application.Features.DocumentManagementAccessMatrix.Services.AccessMatrixOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementAccessMatrix.Services.AccessMatrixOptions.SectionName));
        // MOD-0029-FU05 — access-profile template role mapping.
        services.Configure<Diten.Platform.Application.Features.DocumentManagementAccessProfileTemplates.AccessProfileTemplateOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementAccessProfileTemplates.AccessProfileTemplateOptions.SectionName));
        // MOD-0029-FU07 — identifier coding rules (org/domain prefix, padding). Defaults match SOP examples when unset.
        services.Configure<Diten.Platform.Application.Features.DocumentManagementIdentifiers.DocumentCodingOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementIdentifiers.DocumentCodingOptions.SectionName));
        // MOD-0029-FU08 — lifecycle policy toggles (release-gate requirement defaults off until FU10).
        services.Configure<Diten.Platform.Application.Features.DocumentManagementLifecycle.DocumentLifecycleOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementLifecycle.DocumentLifecycleOptions.SectionName));
        // MOD-0029-FU09 — approval policy toggles (approval-required gate defaults off for backward compatibility).
        services.Configure<Diten.Platform.Application.Features.DocumentManagementApproval.DocumentApprovalOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementApproval.DocumentApprovalOptions.SectionName));
        // MOD-0029-FU10 — release gate policy toggles (training-for-non-critical defaults off).
        services.Configure<Diten.Platform.Application.Features.DocumentManagementReleaseGates.DocumentReleaseGateOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementReleaseGates.DocumentReleaseGateOptions.SectionName));
        // MOD-0029-FU12 — periodic review policy (60-day window / 60-day single extension; no auto lifecycle change).
        services.Configure<Diten.Platform.Application.Features.DocumentManagementPeriodicReview.DocumentPeriodicReviewOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementPeriodicReview.DocumentPeriodicReviewOptions.SectionName));
        // MOD-0029-FU13 — withdrawal policy (temporary instruction 30-day SOP ceiling).
        services.Configure<Diten.Platform.Application.Features.DocumentManagementSuspension.DocumentWithdrawalOptions>(
            configuration.GetSection(Diten.Platform.Application.Features.DocumentManagementSuspension.DocumentWithdrawalOptions.SectionName));

        services.AddScoped<ITenantContext, TenantContext>();
        services.AddScoped<IInternalScopeResolutionContext, InternalScopeResolutionContext>();
        services.AddSingleton<IMdmServiceIdentityTokenProvider, MdmServiceIdentityTokenProvider>();
        services.AddScoped<ICurrentUserContext, CurrentUserContext>();
        services.AddTenantAuthorizationContext();
        services.AddScoped<ITenantDefaultsProvider, TenantDefaultsProvider>();
        services.AddSingleton<EntitlementCacheService>();
        services.AddScoped<IEntitlementChecker, EntitlementChecker>();
        services.AddOptions<PlatformEntitlementAttestationOptions>()
            .Bind(configuration.GetSection("PlatformEntitlementAttestation"));
        services.AddSingleton<VersionAwareEntitlementDecisionCache>();
        services.AddScoped<IAuthoritativeEntitlementDecisionSource, MongoAuthoritativeEntitlementDecisionSource>();
        services.AddScoped<IPlatformEntitlementDecisionProvider, PlatformEntitlementDecisionProvider>();
        services.AddScoped<IAdminUserInvitationService, AdminUserInvitationService>();
        services.AddScoped<ITenantActivationNotifier, AuthServiceTenantActivationNotifier>();
        services.AddScoped<ICatalogPermissionSyncService, CatalogPermissionSyncService>();
        services.AddScoped<IAuthPermissionModulesClient, AuthPermissionModulesClient>();
        // MOD-0024 §K6.4 — display-name resolution for task assignees/requesters (best-effort S2S).
        services.AddScoped<IUserDisplayNameResolver, AuthUserDisplayNameClient>();
        services.AddScoped<IPlatformLookupCache, PlatformLookupMemoryCache>();
        services.AddScoped<IPlatformAdministratorProvisioningService, PlatformAdministratorProvisioningService>();
        services.AddScoped<IPlatformAdministratorInvitationEmailService, PlatformAdministratorInvitationEmailService>();
        /*
         * ⚠ These reference-validator clients carry NO tenant DelegatingHandler, and that is DELIBERATE.
         * A handler cannot see the request: IHttpClientFactory caches a client's handler chain in its OWN scope,
         * so a handler injecting the request-scoped ITenantContext is never resolved and adds no X-Tenant-Id —
         * silently, and green in unit tests, which register the context as a singleton and so prove wiring rather
         * than lifetime. Measured 2026-08-28 by a live read; the shared handler was deleted in BL-316.
         * Each validator writes X-Tenant-Id itself, from the request's own scope, via TenantOnTheWire — which is
         * also the one place that decides WHICH tenant may travel. Do not re-introduce a handler here.
         */
        services.AddHttpClient<ILegalEntityReferenceValidator, MdmLegalEntityReferenceValidator>();
        services.AddHttpClient<IWorkingCalendarLegalEntityValidator, WorkingCalendarLegalEntityValidator>(client =>
        {
            // The validator owns one linked 3-second budget across both attempts.
            client.Timeout = Timeout.InfiniteTimeSpan;
        });
        services.AddHttpClient<NagerDateHolidayProvider>((sp, client) =>
        {
            var options = sp.GetRequiredService<IOptions<WorkingCalendarImportOptions>>().Value;
            client.BaseAddress = new Uri(options.BaseUrl.TrimEnd('/') + "/", UriKind.Absolute);
            client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);
        }).ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler { AllowAutoRedirect = false });
        services.AddScoped<OfflineHolidayProvider>();
        services.AddScoped<IHolidayProvider>(sp =>
        {
            var options = sp.GetRequiredService<IOptions<WorkingCalendarImportOptions>>().Value;
            return string.Equals(options.Provider, "nager-date", StringComparison.OrdinalIgnoreCase)
                ? sp.GetRequiredService<NagerDateHolidayProvider>()
                : sp.GetRequiredService<OfflineHolidayProvider>();
        });
        services.AddHttpClient<IUserReferenceValidator, Diten.Platform.Infrastructure.Services.Auth.AuthServiceUserReferenceValidator>();
        services.AddHttpClient<
            Diten.Platform.Application.Features.DocumentManagementApproval.Services.IApprovalRoleDirectory,
            Diten.Platform.Infrastructure.Services.Auth.AuthServiceApprovalRoleDirectory>();

        /*
         * WC-D1 (DCP-004 §2 D1) — THE GENERAL BRIDGE to modules that live in their own service.
         *
         * ONE provider class and ONE dispatcher class, multiplied by the rows in
         * 'WorkAggregation:RemoteProviders'. Adding a module is adding a row; it is deliberately NOT adding a
         * class, because N teams' bridge classes would mean N error-handling policies and N timeouts, and the
         * first slow module would slow the whole board with nobody able to say which one.
         *
         * The ADDRESS is the operator's, written in configuration beside MdmService:BaseUrl. It is not read from
         * the self-registration manifest: a manifest is client-supplied, and an address inside it is the party
         * being called telling Platform where to send a caller's JWT.
         */
        services.AddRemoteWorkItemProviders(configuration);

        BsonSerializer.RegisterSerializer(new GuidSerializer(GuidRepresentation.Standard));
        BsonSerializer.RegisterSerializer(new DecimalSerializer(BsonType.Decimal128));

        var connectionString = configuration["MongoDbSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Configuration error: 'MongoDbSettings:ConnectionString' is missing in appsettings.json.");
        var databaseName = configuration["MongoDbSettings:DatabaseName"]
            ?? throw new InvalidOperationException("Configuration error: 'MongoDbSettings:DatabaseName' is missing in appsettings.json.");

        var mongoSettings = new MongoDbSettings
        {
            ConnectionString = connectionString,
            DatabaseName = databaseName,
            AllowStartupWithoutDatabase = configuration.GetValue<bool>("MongoDbSettings:AllowStartupWithoutDatabase")
        };

        services.AddSingleton(mongoSettings);
        var mongoClientSettings = MongoClientSettings.FromConnectionString(mongoSettings.ConnectionString);
        mongoClientSettings.GuidRepresentation = GuidRepresentation.Standard;
        var mongoClient = new MongoClient(mongoClientSettings);
        var database = mongoClient.GetDatabase(mongoSettings.DatabaseName);

        services.AddSingleton<IMongoClient>(mongoClient);
        services.AddSingleton<IPlatformDbContext>(new PlatformDbContext(mongoClient, database));
        services.AddSingleton<IPlatformTransactionFaultProbe, NoOpPlatformTransactionFaultProbe>();
        services.AddScoped<IPlatformTransactionExecutor, PlatformTransactionExecutor>();
        services.AddScoped<IEntitlementStateVersionRepository, EntitlementStateVersionRepository>();
        services.AddScoped<IGlobalApplicabilityStateRepository, GlobalApplicabilityStateRepository>();
        services.AddScoped<IMongoDatabase>(_ => database);
        services.AddScoped<ISavedViewRepository, SavedViewRepository>();
        services.AddScoped<ITenantRegistryRepository, TenantRegistryRepository>();
        services.AddScoped<ITenantDomainRepository, TenantDomainRepository>();
        services.AddScoped<ITenantLoginSettingsRepository, TenantLoginSettingsRepository>();
        services.AddScoped<IModuleCatalogRepository, ModuleCatalogRepository>();
        services.AddScoped<ITransactionalModuleCatalogRepository>(sp => (ModuleCatalogRepository)sp.GetRequiredService<IModuleCatalogRepository>());
        services.AddScoped<IModuleDomainRepository, ModuleDomainRepository>();
        services.AddScoped<IModuleServiceRepository, ModuleServiceRepository>();
        services.AddScoped<IModulePageDescriptorRepository, ModulePageDescriptorRepository>();
        services.AddScoped<IModulePageActionDescriptorRepository, ModulePageActionDescriptorRepository>();
        services.AddScoped<ITenantNavPreferenceRepository, TenantNavPreferenceRepository>();
        services.AddScoped<ITenantNavDomainPreferenceRepository, TenantNavDomainPreferenceRepository>();
        services.AddScoped<IPlatformAdministratorRepository, PlatformAdministratorRepository>();
        services.AddScoped<ISubscriptionPlanRepository, SubscriptionPlanRepository>();
        services.AddScoped<ITransactionalSubscriptionPlanRepository>(sp => (SubscriptionPlanRepository)sp.GetRequiredService<ISubscriptionPlanRepository>());
        services.AddScoped<ITenantSubscriptionRepository, TenantSubscriptionRepository>();
        services.AddScoped<ITenantModuleEntitlementRepository, TenantModuleEntitlementRepository>();
        services.AddScoped<IQuotaUsageRepository, QuotaUsageRepository>();
        services.AddScoped<IQuotaEventRepository, QuotaEventRepository>();
        services.AddScoped<IInterfaceRegistryRepository, InterfaceRegistryRepository>();
        services.AddScoped<IFeatureDefinitionRepository, FeatureDefinitionRepository>();
        services.AddScoped<IFeatureCategoryRepository, FeatureCategoryRepository>();
        services.AddScoped<IPlanFeatureMappingRepository, PlanFeatureMappingRepository>();
        services.AddScoped<IBusinessReferenceDataStewardshipRepository, BusinessReferenceDataStewardshipRepository>();
        services.AddScoped<IAuditEventRepository, AuditEventRepository>();
        services.AddScoped<IAuditRetentionPolicyRepository, AuditRetentionPolicyRepository>();
        services.AddScoped<ITenantAuditPreferenceRepository, TenantAuditPreferenceRepository>();
        services.AddScoped<ITenantMessagingSettingsRepository, TenantMessagingSettingsRepository>();
        services.AddScoped<INotificationTemplateRepository, NotificationTemplateRepository>();
        services.AddScoped<INotificationDispatchRepository, NotificationDispatchRepository>();
        services.AddScoped<INotificationEventDefinitionRepository, NotificationEventDefinitionRepository>();
        services.AddScoped<IUserNotificationRepository, UserNotificationRepository>();
        // ONE instance answers both contracts: the unit repository and, for MOD-0288-FU02, the reporting
        // graph. Registering the concrete type first is what keeps them the same object per request — two
        // registrations of the same class would give the graph guard a different tenant-scoped instance.
        services.AddScoped<OrganizationUnitRepository>();
        services.AddScoped<IOrganizationUnitRepository>(sp => sp.GetRequiredService<OrganizationUnitRepository>());
        services.AddScoped<IOrganizationReportingGraphRepository>(sp => sp.GetRequiredService<OrganizationUnitRepository>());
        // MOD-0288-FU02 — tenant-defined Organization Unit field definitions and values.
        services.AddScoped<IOrganizationFieldDefinitionRepository, OrganizationFieldDefinitionRepository>();
        services.AddScoped<IOrganizationFieldValueRepository, OrganizationFieldValueRepository>();
        services.AddScoped<IPositionRepository, PositionRepository>();
        services.AddScoped<IPositionAssignmentRepository, PositionAssignmentRepository>();
        services.AddScoped<IPersonReferenceRepository, PersonReferenceRepository>();

        // Working Calendar & Public Holidays — first production consumer of HybridRepository (country rows with
        // TenantId=null + per-tenant override rows in one collection).
        services.AddScoped<IWorkingCalendarRepository, WorkingCalendarRepository>();
        services.AddScoped<IWorkingCalendarImportBatchRepository, WorkingCalendarImportBatchRepository>();

        // Workflow Repositories
        services.AddScoped<IWorkflowTemplateRepository, WorkflowTemplateRepository>();
        services.AddScoped<IWorkflowTemplateVersionRepository, WorkflowTemplateVersionRepository>();
        services.AddScoped<IWorkflowInstanceRepository, WorkflowInstanceRepository>();
        services.AddScoped<IApprovalTaskRepository, ApprovalTaskRepository>();
        services.AddScoped<IRuntimeAssignmentSnapshotRepository, RuntimeAssignmentSnapshotRepository>();
        services.AddScoped<IWorkflowTransitionLogRepository, WorkflowTransitionLogRepository>();
        services.AddScoped<ISlaEscalationRuleRepository, SlaEscalationRuleRepository>();

        // MOD-0024 Task Engine Repositories (Phase 1 uses the first five; the rest exist so Phases 2–5 are additive)
        // The transition log is registered BEFORE the task repository that writes to it — not that the order
        // matters to the container, but the dependency direction is worth reading in one glance: every task write
        // goes through TaskItemRepository, and TaskItemRepository is what records the history (WC-1).
        services.AddScoped<ITaskTransitionRepository, TaskTransitionRepository>();
        services.AddScoped<ITaskItemRepository, TaskItemRepository>();
        // Faz 5a — the work report's own read. Separate from ITaskItemRepository on purpose: it returns
        // AGGREGATES rather than tasks, and mixing the two would invite a caller to reach for GetAllForTenantAsync.
        services.AddScoped<IWorkReportRepository, WorkReportRepository>();
        services.AddScoped<ITaskAssignmentRepository, TaskAssignmentRepository>();
        services.AddScoped<ITaskDependencyRepository, TaskDependencyRepository>();
        // MOD-0357 S1 — the one bridge collection's storage. See IRecordLinkRepository/IRecordLinkService.
        services.AddScoped<IRecordLinkRepository, RecordLinkRepository>();
        // MOD-0357 S2 — the meeting aggregate's own storage.
        services.AddScoped<IMeetingRepository, MeetingRepository>();
        services.AddScoped<IMeetingAttendeeRepository, MeetingAttendeeRepository>();
        services.AddScoped<IAgendaItemRepository, AgendaItemRepository>();
        services.AddScoped<IMeetingTypeRepository, MeetingTypeRepository>();
        services.AddScoped<ITaskWatcherRepository, TaskWatcherRepository>();
        services.AddScoped<ITaskCommentRepository, TaskCommentRepository>();
        services.AddScoped<ITaskPersonalOverlayRepository, TaskPersonalOverlayRepository>();
        services.AddScoped<ITaskTypeRepository, TaskTypeRepository>();
        services.AddScoped<IDocumentReferenceListRepository, DocumentReferenceListRepository>();
        services.AddScoped<ITaskFieldDefinitionRepository, TaskFieldDefinitionRepository>();
        services.AddScoped<IChecklistTemplateRepository, ChecklistTemplateRepository>();
        services.AddScoped<IChecklistRunRepository, ChecklistRunRepository>();
        // MOD-0024 Slice ATT-1 — task attachment metadata.
        services.AddScoped<ITaskAttachmentRepository, TaskAttachmentRepository>();
        services.AddScoped<ITaskTemplateRepository, TaskTemplateRepository>();
        services.AddScoped<ITaskRecurrenceRuleRepository, TaskRecurrenceRuleRepository>();

        /*
         * WC-4 — task notification recipients, resolved from AuthService.
         *
         * THIS LINE is the seam: swap the implementation and every task notification is addressed differently.
         * Before it existed, MOD-0024 put the recipient's user GUID into the email field, so no task
         * notification had ever been deliverable.
         */
        services.AddScoped<Diten.Platform.Application.Contracts.ITaskNotificationRecipientResolver,
            Services.AuthTaskNotificationRecipientClient>();

        // Document Management Repositories
        services.AddScoped<IBaselineReleaseRepository, BaselineReleaseRepository>();
        services.AddScoped<ICollectionDefinitionRepository, CollectionDefinitionRepository>();
        services.AddScoped<IBaselineSnapshotManifestRepository, BaselineSnapshotManifestRepository>();
        services.AddScoped<ICollectionInstanceRepository, CollectionInstanceRepository>();
        services.AddScoped<IInstantiationOperationRepository, InstantiationOperationRepository>();
        services.AddScoped<ICorporateCollectionProvisioningOperationRepository, CorporateCollectionProvisioningOperationRepository>();
        services.AddScoped<IInstantiationOutcomeRepository, InstantiationOutcomeRepository>();

        // MOD-0029-FU01 — controlled documents / templates / versions / shares repositories + seams.
        services.AddScoped<IControlledDocumentRepository, ControlledDocumentRepository>();
        services.AddScoped<IControlledDocumentVersionRepository, ControlledDocumentVersionRepository>();
        services.AddScoped<ITemplateDocumentRepository, TemplateDocumentRepository>();
        services.AddScoped<ITemplateVersionRepository, TemplateVersionRepository>();
        services.AddScoped<ITemplateMasterRepository, TemplateMasterRepository>();
        services.AddScoped<ITemplateMasterVersionRepository, TemplateMasterVersionRepository>();
        // MOD-0029-FU03 — tenant-scoped template variant governance + drift repository.
        services.AddScoped<ITemplateVariantRepository, TemplateVariantRepository>();
        // MOD-0028-FU09 — provisioning evidence + read-back deviation repositories (sidecar).
        services.AddScoped<IProvisioningEvidenceRepository, ProvisioningEvidenceRepository>();
        services.AddScoped<IDocumentCollectionDeviationRepository, DocumentCollectionDeviationRepository>();
        // MOD-0029-FU06 — Document Master Register (LOG-0001) repository (sidecar governance projection).
        services.AddScoped<IDocumentMasterRegisterRepository, DocumentMasterRegisterRepository>();
        // WP-DM-DCP005-REGISTER-IMPORT-UI-01 — the register's CSV upload history.
        services.AddScoped<IDocumentRegisterImportBatchRepository, DocumentRegisterImportBatchRepository>();
        // MOD-0029-FU36 — durable controlled-document registration orchestration.
        services.AddScoped<IControlledDocumentRegistrationRepository, ControlledDocumentRegistrationRepository>();
        // MOD-0029-FU07 — document identifier (Permanent UID / Document Code) allocation ledger + sequence counter.
        services.AddScoped<IDocumentIdentifierAllocationRepository, DocumentIdentifierAllocationRepository>();
        services.AddScoped<IDocumentIdentifierSequenceCounterRepository, DocumentIdentifierSequenceCounterRepository>();
        // MOD-0029-FU08 — controlled document lifecycle transition record repository.
        services.AddScoped<IDocumentLifecycleTransitionRecordRepository, DocumentLifecycleTransitionRecordRepository>();
        // MOD-0029-FU09 — approval requirement + immutable evidence repositories.
        services.AddScoped<IDocumentApprovalRequirementRepository, DocumentApprovalRequirementRepository>();
        services.AddScoped<IDocumentApprovalEvidenceRepository, DocumentApprovalEvidenceRepository>();
        // MOD-0029 (Faz 2a) — document-centric variant link repository.
        services.AddScoped<IDocumentVariantRepository, DocumentVariantRepository>();
        // MOD-0029-FU10 — release gate evaluation / result / manual evidence repositories.
        services.AddScoped<IDocumentReleaseGateEvaluationRepository, DocumentReleaseGateEvaluationRepository>();
        services.AddScoped<IDocumentReleaseGateResultRepository, DocumentReleaseGateResultRepository>();
        services.AddScoped<IDocumentReleaseGateEvidenceRepository, DocumentReleaseGateEvidenceRepository>();
        // MOD-0029-FU11 — training matrix requirement + assignment repositories.
        services.AddScoped<IDocumentTrainingMatrixRequirementRepository, DocumentTrainingMatrixRequirementRepository>();
        services.AddScoped<IDocumentTrainingAssignmentRepository, DocumentTrainingAssignmentRepository>();
        // MOD-0029-FU12 — periodic review / extension / escalation repositories.
        services.AddScoped<IDocumentPeriodicReviewRepository, DocumentPeriodicReviewRepository>();
        services.AddScoped<IDocumentPeriodicReviewExtensionRepository, DocumentPeriodicReviewExtensionRepository>();
        services.AddScoped<IDocumentPeriodicReviewEscalationRepository, DocumentPeriodicReviewEscalationRepository>();
        // MOD-0029-FU13 — suspension / retirement / temporary-instruction repositories.
        services.AddScoped<IDocumentSuspensionCaseRepository, DocumentSuspensionCaseRepository>();
        services.AddScoped<IDocumentRetirementCaseRepository, DocumentRetirementCaseRepository>();
        services.AddScoped<ITemporaryInstructionControlRepository, TemporaryInstructionControlRepository>();
        // MOD-0029-FU16 — repository assessment + finding repositories.
        services.AddScoped<IDocumentRepositoryAssessmentRepository, DocumentRepositoryAssessmentRepository>();
        services.AddScoped<IDocumentRepositoryAssessmentFindingRepository, DocumentRepositoryAssessmentFindingRepository>();
        // MOD-0029-FU17 — controlled copy / withdrawal plan / obsolete finding repositories.
        services.AddScoped<IDocumentControlledCopyRepository, DocumentControlledCopyRepository>();
        services.AddScoped<IDocumentCopyWithdrawalPlanRepository, DocumentCopyWithdrawalPlanRepository>();
        services.AddScoped<IDocumentObsoleteCopyFindingRepository, DocumentObsoleteCopyFindingRepository>();
        // MOD-0029-FU14 — external document register / monitoring check / impact assessment / internal link repositories.
        services.AddScoped<IExternalDocumentRegisterRepository, ExternalDocumentRegisterRepository>();
        services.AddScoped<IExternalDocumentMonitoringCheckRepository, ExternalDocumentMonitoringCheckRepository>();
        services.AddScoped<IExternalDocumentImpactAssessmentRepository, ExternalDocumentImpactAssessmentRepository>();
        services.AddScoped<IExternalDocumentInternalLinkRepository, ExternalDocumentInternalLinkRepository>();
        // MOD-0029-FU15 — retention policy / subject / legal hold / hold membership / disposition repositories.
        services.AddScoped<IDocumentRetentionPolicyRepository, DocumentRetentionPolicyRepository>();
        services.AddScoped<IDocumentRetentionSubjectRepository, DocumentRetentionSubjectRepository>();
        services.AddScoped<IDocumentLegalHoldRepository, DocumentLegalHoldRepository>();
        services.AddScoped<IDocumentLegalHoldSubjectRepository, DocumentLegalHoldSubjectRepository>();
        services.AddScoped<IDocumentDispositionRequestRepository, DocumentDispositionRequestRepository>();
        // MOD-0029-FU18 — variant localization profile / review evidence / parent change assessment repositories.
        services.AddScoped<ITemplateVariantLocalizationProfileRepository, TemplateVariantLocalizationProfileRepository>();
        services.AddScoped<ITemplateVariantReviewEvidenceRepository, TemplateVariantReviewEvidenceRepository>();
        services.AddScoped<ITemplateVariantParentChangeAssessmentRepository, TemplateVariantParentChangeAssessmentRepository>();
        // MOD-0029-FU20 — repository downtime event / temporary controlled issue / downtime escalation repositories.
        services.AddScoped<IDocumentRepositoryDowntimeEventRepository, DocumentRepositoryDowntimeEventRepository>();
        services.AddScoped<IDocumentTemporaryControlledIssueRepository, DocumentTemporaryControlledIssueRepository>();
        services.AddScoped<IDocumentDowntimeEscalationRepository, DocumentDowntimeEscalationRepository>();
        // MOD-0029-FU21 — GDocP correction trail record / policy / review repositories (append-only; no delete).
        services.AddScoped<IDocumentGDocPCorrectionRecordRepository, DocumentGDocPCorrectionRecordRepository>();
        services.AddScoped<IDocumentGDocPCorrectionPolicyRepository, DocumentGDocPCorrectionPolicyRepository>();
        services.AddScoped<IDocumentGDocPCorrectionReviewRepository, DocumentGDocPCorrectionReviewRepository>();
        // MOD-0029-FU22 — quality event / deviation / CAPA / source link repositories (document-control scoped).
        services.AddScoped<IDocumentQualityEventRepository, DocumentQualityEventRepository>();
        services.AddScoped<IDocumentDeviationRepository, DocumentDeviationRepository>();
        services.AddScoped<IDocumentCAPAActionRepository, DocumentCAPAActionRepository>();
        services.AddScoped<IDocumentQualityEventSourceLinkRepository, DocumentQualityEventSourceLinkRepository>();
        // MOD-0029-FU23 — signature policy / request / record / fingerprint repositories (append-only; no delete).
        services.AddScoped<IDocumentSignaturePolicyRepository, DocumentSignaturePolicyRepository>();
        services.AddScoped<IDocumentSignatureRequestRepository, DocumentSignatureRequestRepository>();
        services.AddScoped<IDocumentSignatureRecordRepository, DocumentSignatureRecordRepository>();
        services.AddScoped<IDocumentSignedObjectFingerprintRepository, DocumentSignedObjectFingerprintRepository>();
        // MOD-0029-FU31A — governance policy pack application history (append-only; no delete, no update).
        services.AddScoped<IDocumentGovernancePolicyPackApplicationRepository, DocumentGovernancePolicyPackApplicationRepository>();
        // MOD-0029-FU32 — governance sweep run history (append-only; no delete).
        services.AddScoped<IDocumentGovernanceSweepRunRepository, DocumentGovernanceSweepRunRepository>();
        // MOD-0029-FU04 — generalized document access matrix policy repository.
        services.AddScoped<IDocumentAccessPolicyRepository, DocumentAccessPolicyRepository>();
        services.AddScoped<IFolderDocumentAccessPolicyRepository, FolderDocumentAccessPolicyRepository>();
        services.AddScoped<IDocumentShareRecordRepository, DocumentShareRecordRepository>();
        services.AddScoped<IFolderShareOperationRepository, FolderShareOperationRepository>();
        services.AddScoped<IFolderShareOutcomeRepository, FolderShareOutcomeRepository>();
        services.AddScoped<IDocumentFavoriteRepository, DocumentFavoriteRepository>();
        services.AddScoped<Diten.Platform.Application.Features.DocumentManagementControlledDocuments.Services.ICollectionInstanceReferenceReader,
            Diten.Platform.Infrastructure.Services.DocumentManagement.CollectionInstanceReferenceReader>();
        services.AddScoped<Diten.Platform.Application.Features.DocumentManagementControlledDocuments.Services.IDocumentAccessPrincipalAccessor,
            Diten.Platform.Infrastructure.Services.DocumentManagement.DocumentAccessPrincipalAccessor>();
        // MOD-0262-FU01 — the binary store seam is now owned by MOD-0262 (Internal Document Repository Service).
        services.AddScoped<Diten.Platform.Application.Contracts.DocumentRepository.IContentStorageGateway,
            Diten.Platform.Infrastructure.Services.DocumentManagement.LocalFileSystemContentStorageGateway>();
        services.AddScoped<Diten.Platform.Domain.Repositories.IRepositoryObjectRepository,
            Diten.Platform.Infrastructure.Persistence.Repositories.RepositoryObjectRepository>();
        services.AddScoped<Diten.Platform.Application.Features.DocumentRepository.Services.DocumentRepositoryService>();

        services.AddScoped<IMessagingProvider, FakeMessagingProvider>();
        services.AddScoped<IMessagingProvider, SmtpMessagingProvider>();
        services.AddSingleton<ISmtpClientFactory, MailKitSmtpClientFactory>();
        services.AddScoped<SecretReferenceResolver>();
        services.AddScoped<IMessagingProviderResolver, MessagingProviderResolver>();
        services.AddScoped<AuditOutboxRepository>();
        services.AddScoped<IAuditOutboxWriter>(provider => provider.GetRequiredService<AuditOutboxRepository>());
        services.AddScoped<ITransactionalAuditOutboxWriter>(provider => provider.GetRequiredService<AuditOutboxRepository>());
        services.AddScoped<IAuditOutboxProcessingRepository>(provider => provider.GetRequiredService<AuditOutboxRepository>());
        services.AddSingleton<AuditOutboxWorkerOptions>();
        services.AddScoped<AuditOutboxPayloadMapper>();
        services.AddScoped<AuditOutboxProcessor>();
        services.AddHostedService<AuditOutboxWorker>();

        LegacySavedViewMigration.MigrateAsync(database).GetAwaiter().GetResult();
        // MC-2 — drop duplicate live module-service rows before the unique partial index is (re)created.
        ModuleServiceDeduplicationMigration.MigrateAsync(database).GetAwaiter().GetResult();

        // FIX-DOMAIN-DEDUP — collapse cross-format duplicate domain rows + backfill CodeKey BEFORE the unique
        // partial index (ux_platform_module_domains_code_key) is (re)created, else the index build would fail.
        ModuleDomainDeduplicationMigration.MigrateAsync(database).GetAwaiter().GetResult();

        // NOTE (2026-08-28 main-sync): the pre-refactor MongoDbIndexConfigurations.ReconcileDevelopmentIndexesAsync
        // dev-only drop was removed here — main's refactor folded drop-before-rebuild into PlatformSchemaMigrations
        // (run first by EnsureIndexesAsync). The one index it dropped, "ux_dm_collection_instances_corporate_owner_
        // baseline_node_active", is not a name main's manifest recreates, so it can never raise IndexOptionsConflict;
        // any lingering copy in an old dev DB is a harmless orphan.
        MongoDbIndexConfigurations.EnsureIndexesAsync(database).GetAwaiter().GetResult();
        var auditRetentionSeedOptions = configuration
            .GetSection(AuditRetentionSeedOptions.SectionName)
            .Get<AuditRetentionSeedOptions>()
            ?? throw new InvalidOperationException($"Configuration error: '{AuditRetentionSeedOptions.SectionName}' is missing in appsettings.json.");
        AuditRetentionPolicySeed.EnsureSeededAsync(database, auditRetentionSeedOptions).GetAwaiter().GetResult();
        PlatformAdministratorSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        TenantSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        NotificationTemplateSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        // WC-4 — the platform-default messaging settings row. Without it QueueEmailNotificationHandler refuses at its
        // FIRST line and no producer's notification ever reaches a template, a locale or a provider. Derived from the
        // Smtp section so that block finally configures what it appears to configure. Idempotent; never overrides a
        // row an operator created.
        NotificationMessagingSettingsSeed.EnsureSeededAsync(
                database,
                configuration.GetSection(SmtpOptions.SectionName).Get<SmtpOptions>() ?? new SmtpOptions())
            .GetAwaiter().GetResult();
        // BL-042 — stamp AcceptedByUserId on tasks accepted under the OLD inferred rule. Without this every
        // already-accepted task reverts to pendingAcceptance on deploy and the tenant's My Work empties into the
        // Inbox. Idempotent: only unstamped rows are touched.
        TaskAcceptanceBackfillMigration.MigrateAsync(database).GetAwaiter().GetResult();
        // MOD-0027-FU03A (Bridge) — PlatformSeed/SystemSeed notification events; runs after templates exist. No-op
        // until FU04A adds seed content.
        NotificationEventSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        ModuleCatalogSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        ModuleDomainSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        ModuleServiceSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        // FIX-DOMAIN-SERVICE-CANONICAL — must run AFTER the domain/service lookups are seeded: pins catalog
        // Domain/Service to canonical Codes and fixes the 'Servicec' DisplayName typo. Marker-gated + idempotent.
        ModuleCatalogTaxonomyCanonicalizationMigration.MigrateAsync(database).GetAwaiter().GetResult();
        // FIX-DOMAIN-NORMALIZATION — runs AFTER the marker-gated canonicalization above and is itself NOT
        // marker-gated: re-runnable and idempotent, so catalog rows that drifted after that one-shot ran
        // (two spellings of one domain → the sidebar heading rendered twice) are healed on every startup.
        ModuleCatalogDomainCanonicalizationMigration.MigrateAsync(database).GetAwaiter().GetResult();
        // FIX-TASKS-MODULE-NAME — the tasks module was renamed "Görevler" → "Görev Tanımları"; catalog
        // DisplayName is SOFT (operator-owned) so a manifest re-push would NOT carry it. Rewrites only a
        // row still holding the exact old seed, so it is idempotent and never clobbers an operator rename.
        TaskModuleDisplayNameRenameMigration.MigrateAsync(database).GetAwaiter().GetResult();
        // WP-DM-1b — tenant-AGNOSTIC Document Master Register auto-seed. Config-driven (DocumentRegisterSeed:*):
        // EnsureSeededAsync self-gates on Development + Enabled + a configured target tenant + a real CSV path +
        // a one-time marker; absent/blank/prod ⇒ skip (no hardcoded tenant). Reuses the DM-1a mapping + parser.
        services.Configure<DocumentRegisterSeedOptions>(
            configuration.GetSection(DocumentRegisterSeedOptions.SectionName));
        var documentRegisterSeedOptions = configuration
            .GetSection(DocumentRegisterSeedOptions.SectionName)
            .Get<DocumentRegisterSeedOptions>() ?? new DocumentRegisterSeedOptions();
        DocumentRegisterSeed.EnsureSeededAsync(database, documentRegisterSeedOptions, environment).GetAwaiter().GetResult();
        // DEV-ONLY SEEDS — these two write MOCK organization data: five invented positions
        // (CEO/CTO/HR_MGR/DEV_LEAD/DEV_ENG) and an assignment binding a named developer's personal
        // mailbox to the CEO position of one hardcoded tenant. PositionAssignmentSeed already
        // declared itself "DEV-ONLY" in its header, but nothing enforced it: both ran in EVERY
        // environment, production included. The gate below is what makes the header true.
        //
        // ...and the environment alone is no longer enough. Development is also where the owner walks the
        // organisation chain by hand on an emptied tenant, and where the dev server is restarted without asking,
        // by standing instruction. Both seeds fill only an EMPTY tenant, so every restart after a reset put a
        // phantom "HEADQUARTERS" and five mock positions (CEO, CTO, HR_MGR, DEV_LEAD, DEV_ENG) back into the
        // tenant being walked — measured 2026-09-10: all CreatedBy="system", one set per seeded tenant. "Restart
        // freely" and "restarting pollutes" cannot both be rules, so the seeds are OPT-IN now and default OFF.
        // Nothing in the test suites reads this data; the two tests that name these seeds do so in comments.
        var seedDevOrganizationPositions =
            environment.IsDevelopment() && configuration.GetValue<bool>(PositionSeed.OptInConfigurationKey);
        if (seedDevOrganizationPositions)
        {
            PositionSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            PositionAssignmentSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
        }

        services.AddScoped<IOutboxEventRepository, OutboxEventRepository>();
        services.AddScoped<EventOutboxWriter>(sp => sp.GetRequiredService<IOutboxEventRepository>());
        services.AddScoped<EventOutboxStore>(sp => sp.GetRequiredService<IOutboxEventRepository>());
        services.AddSingleton<TrustedTransportMetadataProvider, EmptyTrustedTransportMetadataProvider>();
        services.AddScoped<ITransactionalOutboxEventWriter>(sp =>
            (ITransactionalOutboxEventWriter)sp.GetRequiredService<IOutboxEventRepository>());
        services.AddScoped<ITransactionalIntegrationEventWriter, TransactionalIntegrationEventWriter>();
        services.AddScoped<IOutboxObservabilityReader>(sp => (IOutboxObservabilityReader)sp.GetRequiredService<IOutboxEventRepository>());
        services.AddScoped<IConsumedEventRepository, ConsumedEventRepository>();
        services.AddScoped<IJobExecutionLogRepository, JobExecutionLogRepository>();
        services.AddScoped<OutboxPublisherProcessor>();
        services.AddScoped<HangfireBackgroundJobExecutor>();

        ConfigureHangfire(services, configuration, mongoSettings);

        var eventingOptions = configuration.GetSection(RabbitMqEventingOptions.SectionName).Get<RabbitMqEventingOptions>()
                              ?? new RabbitMqEventingOptions();
        if (eventingOptions.UseRabbitMq)
        {
            services.AddMassTransit(x =>
            {
                AddPlatformEventConsumers(x);
                x.UsingRabbitMq((context, cfg) =>
                {
                    cfg.Host(eventingOptions.Host, eventingOptions.Port, eventingOptions.VirtualHost, h =>
                    {
                        h.Username(eventingOptions.Username);
                        h.Password(eventingOptions.Password);
                        if (eventingOptions.UseTls)
                        {
                            h.UseSsl(s => s.Protocol = System.Security.Authentication.SslProtocols.Tls12);
                        }
                    });

                    cfg.UseMessageRetry(r => r.Exponential(
                        eventingOptions.RetryCount,
                        TimeSpan.FromSeconds(eventingOptions.InitialRetryDelaySeconds),
                        TimeSpan.FromSeconds(eventingOptions.MaxRetryDelaySeconds),
                        TimeSpan.FromSeconds(eventingOptions.InitialRetryDelaySeconds)));
                    cfg.ConfigureEndpoints(context);
                });
            });
            services.AddScoped<IEventTransportPublisher, MassTransitRabbitMqEventPublisher>();
        }
        else
        {
            services.AddSingleton<InMemoryEventBus>();
            services.AddSingleton<IEventTransportPublisher>(sp => sp.GetRequiredService<InMemoryEventBus>());
        }

        services.AddHostedService<OutboxPublisherWorker>();
        services.AddHostedService<SubscriptionPlanStartupInitializer>();

        RunMongoStartupInitialization(
            database,
            mongoSettings,
            configuration.GetSection(SmtpOptions.SectionName).Get<SmtpOptions>() ?? new SmtpOptions(),
            environment.IsDevelopment(),
            seedDevOrganizationPositions);

        return services;
    }

    public static IServiceCollection AddTenantAuthorizationContext(this IServiceCollection services)
    {
        services.AddScoped<ITenantAuthorizationContext, JwtTenantAuthorizationContext>();
        return services;
    }

    internal static void AddPlatformEventConsumers(IBusRegistrationConfigurator configurator)
    {
        // Default competing-consumer topology: each of these runs once cluster-wide (no duplicate side-effects).
        configurator.AddConsumer<TenantActivatedV1Consumer>();
        configurator.AddConsumer<TenantLifecycleAuditConsumer>();
        configurator.AddConsumer<TenantLifecycleNotificationConsumer>();

        // AG-STEP-010 / MOD-0018-FU13 Group A — per-instance fan-out (OD-FU13-02, A-Option 1).
        // The entitlement cache lives in a per-instance IMemoryCache, so EVERY instance must receive each
        // invalidation event and evict its own copy. Bind ONLY this consumer to a per-instance, temporary
        // (non-durable + auto-delete) receive endpoint via a process-lifetime InstanceId. ConfigureEndpoints(context)
        // honours this per-consumer endpoint definition (one endpoint per consumer — no duplicate binding). The other
        // three consumers keep the shared competing-consumer queue above.
        configurator.AddConsumer<EntitlementCacheInvalidationConsumer>()
            .Endpoint(endpoint =>
            {
                endpoint.InstanceId = PlatformInstanceIdentity.InstanceId;
                endpoint.Temporary = true;
            });
    }

    private static void RunMongoStartupInitialization(
        IMongoDatabase database,
        MongoDbSettings mongoSettings,
        SmtpOptions smtpOptions,
        bool isDevelopment,
        bool seedDevOrganizationPositions)
    {
        try
        {
            LegacySavedViewMigration.MigrateAsync(database).GetAwaiter().GetResult();
            // MC-2 — drop duplicate live module-service rows before the unique partial index is (re)created.
            ModuleServiceDeduplicationMigration.MigrateAsync(database).GetAwaiter().GetResult();
            // FIX-DOMAIN-DEDUP — collapse cross-format duplicate domain rows + backfill CodeKey BEFORE the unique
            // partial index (ux_platform_module_domains_code_key) is (re)created, else the index build would fail.
            ModuleDomainDeduplicationMigration.MigrateAsync(database).GetAwaiter().GetResult();
            MongoDbIndexConfigurations.EnsureIndexesAsync(database).GetAwaiter().GetResult();
            PlatformAdministratorSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            TenantSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            NotificationTemplateSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            // WC-4 — the platform-default messaging settings row. Without it QueueEmailNotificationHandler refuses at its
            // FIRST line and no producer's notification ever reaches a template, a locale or a provider. Derived from the
            // Smtp section so that block finally configures what it appears to configure. Idempotent; never overrides a
            // row an operator created.
            NotificationMessagingSettingsSeed.EnsureSeededAsync(database, smtpOptions).GetAwaiter().GetResult();
            // BL-042 — stamp AcceptedByUserId on tasks accepted under the OLD inferred rule. Without this every
            // already-accepted task reverts to pendingAcceptance on deploy and the tenant's My Work empties into the
            // Inbox. Idempotent: only unstamped rows are touched.
            TaskAcceptanceBackfillMigration.MigrateAsync(database).GetAwaiter().GetResult();
            // MOD-0027-FU03A (Bridge) — PlatformSeed/SystemSeed notification events; runs after templates exist. No-op
            // until FU04A adds seed content.
            NotificationEventSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            ModuleCatalogSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            ModuleDomainSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            ModuleServiceSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            // FIX-DOMAIN-SERVICE-CANONICAL — after the lookups are seeded: canonicalize catalog Domain/Service and
            // fix the 'Servicec' DisplayName typo. Marker-gated + idempotent.
            ModuleCatalogTaxonomyCanonicalizationMigration.MigrateAsync(database).GetAwaiter().GetResult();
            // FIX-DOMAIN-NORMALIZATION — runs AFTER the marker-gated canonicalization above and is itself NOT
            // marker-gated: re-runnable and idempotent, so catalog rows that drifted after that one-shot ran
            // (two spellings of one domain → the sidebar heading rendered twice) are healed on every startup.
            ModuleCatalogDomainCanonicalizationMigration.MigrateAsync(database).GetAwaiter().GetResult();
            // FIX-TASKS-MODULE-NAME — the tasks module was renamed "Görevler" → "Görev Tanımları"; catalog
            // DisplayName is SOFT (operator-owned) so a manifest re-push would NOT carry it. Rewrites only a
            // row still holding the exact old seed, so it is idempotent and never clobbers an operator rename.
            TaskModuleDisplayNameRenameMigration.MigrateAsync(database).GetAwaiter().GetResult();
            // DEV-ONLY, OPT-IN SEEDS — see the gate in AddInfrastructure; same reason, same rule, same flag.
            if (seedDevOrganizationPositions)
            {
                PositionSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
                PositionAssignmentSeed.EnsureSeededAsync(database).GetAwaiter().GetResult();
            }
        }
        catch (Exception ex) when (mongoSettings.AllowStartupWithoutDatabase)
        {
            Console.Error.WriteLine(
                $"Platform MongoDB startup initialization failed ({ex.GetType().Name}). Startup continues because MongoDbSettings:AllowStartupWithoutDatabase=true; readiness will report MongoDB status.");
        }
    }

    private static void ConfigureHangfire(IServiceCollection services, IConfiguration configuration, MongoDbSettings mongoSettings)
    {
        var schedulerOptions = configuration.GetSection(BackgroundJobSchedulerOptions.SectionName)
            .Get<BackgroundJobSchedulerOptions>() ?? new BackgroundJobSchedulerOptions();

        if (!schedulerOptions.Enabled && !schedulerOptions.DashboardEnabled)
        {
            return;
        }

        var storageDatabaseName = string.IsNullOrWhiteSpace(schedulerOptions.StorageDatabaseName)
            ? mongoSettings.DatabaseName
            : schedulerOptions.StorageDatabaseName;

        services.AddHangfire(config =>
        {
            config
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseMongoStorage(
                    mongoSettings.ConnectionString,
                    storageDatabaseName,
                    new MongoStorageOptions
                    {
                        CheckConnection = true,
                        CheckQueuedJobsStrategy = CheckQueuedJobsStrategy.TailNotificationsCollection,
                        MigrationOptions = new MongoMigrationOptions
                        {
                            MigrationStrategy = new MigrateMongoMigrationStrategy(),
                            BackupStrategy = new CollectionMongoBackupStrategy()
                        }
                    });
        });
        services.AddSingleton<IBackgroundJobScheduler, HangfireBackgroundJobScheduler>();

        if (schedulerOptions.Enabled)
        {
            services.AddHangfireServer(options =>
            {
                options.ServerName = $"{Environment.MachineName}.Diten.Platform";
                options.Queues = new[] { "platform", "default" };
            });
            services.AddHostedService<HangfireRecurringJobRegistrationHostedService>();
        }
    }

    private static IReadOnlyList<RequiredSecretDefinition> BuildSecretRequirements(IConfiguration configuration)
    {
        var smtpEnabled = configuration.GetValue<bool>("Smtp:Enabled");

        return
        [
            new("JwtSettings:Secret", "Platform", SecretRequirementKind.JwtCurrent),
            new("JwtSettings:PreviousSecrets", "Platform", SecretRequirementKind.JwtPreviousCollection, Required: false),
            new("MongoDbSettings:ConnectionString", "Platform", SecretRequirementKind.ConnectionString),
            new("AuthService:InternalApiKey", "Platform", SecretRequirementKind.InternalApiKey),
            new("ModuleRegistrationCredentials:Mdm:ActiveSecret", "Platform", SecretRequirementKind.InternalApiKey),
            new("ModuleRegistrationCredentials:Mdm:PreviousSecret", "Platform", SecretRequirementKind.InternalApiKey, Required: false),
            new("Smtp:Password", "Platform", MinimumLength: 8, Required: smtpEnabled, IsEnabled: () => smtpEnabled)
        ];
    }
}
