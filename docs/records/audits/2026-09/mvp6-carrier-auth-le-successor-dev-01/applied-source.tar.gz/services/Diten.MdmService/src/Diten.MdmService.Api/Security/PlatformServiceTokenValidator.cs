using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Diten.MdmService.Api.Security;

public interface IPlatformServiceTokenValidator
{
    bool IsAuthorized(string token, Guid tenantId, Guid actorId, Guid legalEntityId);
}

public sealed class PlatformServiceTokenValidator : IPlatformServiceTokenValidator
{
    private readonly PlatformServiceIdentityOptions _options;

    public PlatformServiceTokenValidator(IOptions<PlatformServiceIdentityOptions> options)
    {
        _options = options.Value;
    }

    public bool IsAuthorized(string token, Guid tenantId, Guid actorId, Guid legalEntityId)
    {
        if (!_options.Enabled
            || tenantId == Guid.Empty
            || actorId == Guid.Empty
            || legalEntityId == Guid.Empty
            || string.IsNullOrWhiteSpace(token)
            || string.IsNullOrWhiteSpace(_options.Issuer)
            || string.IsNullOrWhiteSpace(_options.Audience)
            || string.IsNullOrWhiteSpace(_options.CallerId)
            || string.IsNullOrWhiteSpace(_options.KeyId)
            || string.IsNullOrWhiteSpace(_options.Secret)
            || Encoding.UTF8.GetByteCount(_options.Secret) < 32
            || _options.MaximumTokenLifetimeSeconds is < 5 or > 60
            || _options.ClockSkewSeconds is < 0 or > 10)
        {
            return false;
        }

        try
        {
            var handler = new JwtSecurityTokenHandler { MapInboundClaims = false };
            var principal = handler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = _options.Issuer,
                ValidateAudience = true,
                ValidAudience = _options.Audience,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromSeconds(_options.ClockSkewSeconds),
                RequireExpirationTime = true,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.Secret))
            }, out var validatedToken);

            if (validatedToken is not JwtSecurityToken jwt
                || !string.Equals(jwt.Header.Alg, SecurityAlgorithms.HmacSha256, StringComparison.Ordinal)
                || !string.Equals(jwt.Header.Kid, _options.KeyId, StringComparison.Ordinal)
                || !HasExactClaim(principal, JwtRegisteredClaimNames.Sub, _options.CallerId)
                || !HasExactClaim(principal, "scope", PlatformServiceIdentityOptions.RequiredScope)
                || !HasExactClaim(principal, "tenant_id", tenantId.ToString("D"))
                || !HasExactClaim(principal, "actor_id", actorId.ToString("D"))
                || !HasExactClaim(principal, "legal_entity_id", legalEntityId.ToString("D"))
                || string.IsNullOrWhiteSpace(principal.FindFirst(JwtRegisteredClaimNames.Jti)?.Value)
                || !long.TryParse(principal.FindFirst(JwtRegisteredClaimNames.Iat)?.Value, out var issuedAt)
                || !long.TryParse(principal.FindFirst(JwtRegisteredClaimNames.Exp)?.Value, out var expiresAt)
                || expiresAt <= issuedAt
                || expiresAt - issuedAt > _options.MaximumTokenLifetimeSeconds)
            {
                return false;
            }

            return true;
        }
        catch (Exception ex) when (ex is SecurityTokenException or ArgumentException)
        {
            return false;
        }
    }

    private static bool HasExactClaim(ClaimsPrincipal principal, string type, string expected) =>
        string.Equals(principal.FindFirst(type)?.Value, expected, StringComparison.Ordinal);
}
