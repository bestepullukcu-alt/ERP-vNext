using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Diten.MdmService.Api.Security;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Xunit;

namespace Diten.MdmService.Application.Tests;

public sealed class PlatformServiceTokenValidatorTests
{
    private static readonly Guid TenantId = Guid.Parse("11111111-1111-1111-1111-111111111111");
    private static readonly Guid ActorId = Guid.Parse("22222222-2222-2222-2222-222222222222");
    private static readonly Guid LegalEntityId = Guid.Parse("33333333-3333-3333-3333-333333333333");
    private const string Secret = "01234567890123456789012345678901";

    [Fact]
    public void Exact_platform_identity_and_scope_are_accepted()
    {
        var validator = CreateValidator();
        var token = CreateToken();

        Assert.True(validator.IsAuthorized(token, TenantId, ActorId, LegalEntityId));
    }

    [Fact]
    public void Wrong_signing_key_is_rejected()
    {
        var validator = CreateValidator();

        Assert.False(validator.IsAuthorized(
            CreateToken(secret: "abcdefghijklmnopqrstuvwxyz123456"),
            TenantId,
            ActorId,
            LegalEntityId));
    }

    [Theory]
    [InlineData("wrong-caller", "mdm.legal-entities.reference.validate")]
    [InlineData("Diten.Platform", "mdm.everything.read")]
    public void Wrong_caller_or_scope_is_rejected(string caller, string scope)
    {
        var validator = CreateValidator();

        Assert.False(validator.IsAuthorized(
            CreateToken(caller: caller, scope: scope),
            TenantId,
            ActorId,
            LegalEntityId));
    }

    [Fact]
    public void Tenant_actor_and_legal_entity_must_all_match()
    {
        var validator = CreateValidator();
        var token = CreateToken();

        Assert.False(validator.IsAuthorized(token, Guid.NewGuid(), ActorId, LegalEntityId));
        Assert.False(validator.IsAuthorized(token, TenantId, Guid.NewGuid(), LegalEntityId));
        Assert.False(validator.IsAuthorized(token, TenantId, ActorId, Guid.NewGuid()));
    }

    [Fact]
    public void Disabled_identity_rejects_otherwise_valid_token()
    {
        var options = ValidOptions();
        options.Enabled = false;
        var validator = new PlatformServiceTokenValidator(Options.Create(options));

        Assert.False(validator.IsAuthorized(CreateToken(), TenantId, ActorId, LegalEntityId));
    }

    [Fact]
    public void Excessive_token_lifetime_is_rejected()
    {
        var validator = CreateValidator();

        Assert.False(validator.IsAuthorized(
            CreateToken(lifetimeSeconds: 120),
            TenantId,
            ActorId,
            LegalEntityId));
    }

    private static PlatformServiceTokenValidator CreateValidator() =>
        new(Options.Create(ValidOptions()));

    private static PlatformServiceIdentityOptions ValidOptions() => new()
    {
        Enabled = true,
        Issuer = "diten-platform-service",
        Audience = "diten-mdm-reference-validation",
        CallerId = "Diten.Platform",
        KeyId = "platform-mdm-2026-09",
        Secret = Secret,
        MaximumTokenLifetimeSeconds = 60,
        ClockSkewSeconds = 0
    };

    private static string CreateToken(
        string caller = "Diten.Platform",
        string scope = "mdm.legal-entities.reference.validate",
        string secret = Secret,
        int lifetimeSeconds = 30)
    {
        var now = DateTimeOffset.UtcNow;
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, caller),
            new Claim("scope", scope),
            new Claim("tenant_id", TenantId.ToString("D")),
            new Claim("actor_id", ActorId.ToString("D")),
            new Claim("legal_entity_id", LegalEntityId.ToString("D")),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("D")),
            new Claim(JwtRegisteredClaimNames.Iat, now.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64)
        };
        var token = new JwtSecurityToken(
            issuer: "diten-platform-service",
            audience: "diten-mdm-reference-validation",
            claims: claims,
            notBefore: now.UtcDateTime,
            expires: now.AddSeconds(lifetimeSeconds).UtcDateTime,
            signingCredentials: new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
                SecurityAlgorithms.HmacSha256));
        token.Header["kid"] = "platform-mdm-2026-09";
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
