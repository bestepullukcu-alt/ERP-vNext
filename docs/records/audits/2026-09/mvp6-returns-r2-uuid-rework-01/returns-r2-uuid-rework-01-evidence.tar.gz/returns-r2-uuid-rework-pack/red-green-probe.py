import importlib.util, json
p='/private/tmp/mvp6-returns-r2-uuid-rework-01/rework/returns-r2/returns_model.py'; spec=importlib.util.spec_from_file_location('m',p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
lo='abcdefab-1234-4abc-8def-abcdefabcdef'; up=lo.upper(); scope=('t','le'); source={'root':lo,'status':'Delivered','lines':{'1':{'quantity':'5.000','uomId':'EA'}}}; body={'shipmentId':lo,'lines':[{'shipmentLineNumber':'1','quantity':'1.000','uomId':'EA'}]}
s=m.Store(); a=s.mutate(scope,'k',body,lo,source=source,grants={'create'}); b=s.mutate(scope,'k',body,up,source=source,grants={'create'})
t={'targetStatus':'Authorized'}; s2=m.Store(); c=s2.mutate(scope,'r',body,lo,source=source,grants={'create'}); d=s2.mutate(scope,'tr',t,up,target='r',grants={'transition','authorize'})
print(json.dumps({'create':a,'replayUpper':b,'transitionCreate':c,'transitionUpper':d}))
assert b==(409,'CORRELATION_ROOT_MISMATCH') and d==(409,'CORRELATION_ROOT_MISMATCH')
