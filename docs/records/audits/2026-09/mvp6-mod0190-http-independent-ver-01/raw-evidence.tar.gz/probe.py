import base64,hashlib,hmac,json,time,uuid,urllib.request,urllib.error,subprocess,sys,pathlib
P=pathlib.Path('/private/tmp/mvp6-mod0190-http-independent-ver-01')
raw=dict(line[7:].strip().split('=',1) for line in (P/'private.env').read_text().splitlines() if line.startswith('export '))
scope=json.loads((P/'scope.json').read_text()); secret=raw['JwtSettings__Secret']
CASES=P/'http.json'; records=json.loads(CASES.read_text()) if CASES.exists() else []
def b64(v): return base64.urlsafe_b64encode(json.dumps(v,separators=(',',':')).encode()).rstrip(b'=').decode()
def token(permission,tenant=None,le=None):
 n=int(time.time());c={'iss':raw['JwtSettings__Issuer'],'aud':raw['JwtSettings__Audience'],'sub':scope['actor'],'tenant_id':tenant or scope['tenant'],'legal_entity_id':le or scope['legalEntity'],'iat':n,'nbf':n-1,'exp':n+900}
 if permission:c['permission']='supplychain.sandop-plans.'+permission
 value=b64({'alg':'HS256','typ':'JWT'})+'.'+b64(c)
 return value+'.'+base64.urlsafe_b64encode(hmac.new(secret.encode(),value.encode(),hashlib.sha256).digest()).rstrip(b'=').decode()
def call(tag,method,path,permission=None,body=None,key=None,tenant=None,le=None,auth=True):
 corr=str(uuid.uuid4());tenant=tenant or scope['tenant'];le=le or scope['legalEntity'];headers={'X-Correlation-Id':corr,'X-Tenant-Id':tenant,'X-Legal-Entity-Id':le,'Content-Type':'application/json'}
 if key is not None: headers['Idempotency-Key']=key
 if auth:headers['Authorization']='Bearer '+token(permission,tenant,le)
 data=json.dumps(body,separators=(',',':')).encode() if body is not None else None
 req=urllib.request.Request('http://127.0.0.1:57981'+path,data=data,method=method,headers=headers)
 try:r=urllib.request.urlopen(req,timeout=15)
 except urllib.error.HTTPError as e:r=e
 out=r.read();rec={'tag':tag,'method':method,'path':path,'requestHeaders':{k:v for k,v in headers.items() if k!='Authorization'},'requestBodyUtf8':data.decode() if data is not None else None,'requestByteLength':len(data or b''),'status':r.status,'responseHeaders':dict(r.headers),'responseBodyUtf8':out.decode(errors='replace'),'responseByteLength':len(out)}
 records.append(rec);CASES.write_text(json.dumps(records,indent=2));return rec
def body(x):return json.loads(x['responseBodyUtf8'])
def check(x,status,code=None):
 assert x['status']==status,(x['tag'],x['status'],x['responseBodyUtf8'])
 if code:assert body(x)['error']['code']==code,(x['tag'],body(x))
 if x['status']!=401:assert x['responseHeaders'].get('X-Correlation-Id')==x['requestHeaders']['X-Correlation-Id'],x['tag']
def state(tag):
 q={'TenantId':scope['tenant'],'LegalEntityId':scope['legalEntity']};script='const q='+json.dumps(q)+';const d=db.getSiblingDB("DitenSupplyChain_Mod0190_Test");const names='+json.dumps(['sandop_plans','sandop_snapshots','sandop_sign_offs','sandop_receipts','sandop_audit','sandop_outbox'])+';print(JSON.stringify(Object.fromEntries(names.map(n=>[n,{count:d.getCollection(n).countDocuments(q),docs:d.getCollection(n).find(q).toArray()}]))));'
 r=subprocess.run(['mongosh','--quiet','--port','57881','--eval',script],capture_output=True,text=True);assert r.returncode==0,(r.returncode,r.stderr);data=json.loads(r.stdout.strip().splitlines()[-1]);(P/('state-'+tag+'.json')).write_text(json.dumps(data,indent=2));return data
def counts(s):return {k:v['count'] for k,v in s.items()}
root='/api/supply-chain/sandop-plans'
if sys.argv[1]=='first':
 s0=state('before')
 create={'name':'VER-FY2027','horizonStart':'2027-01-01','horizonEnd':'2027-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3'}
 x=call('create','POST',root,'create',create,'ver-create');check(x,201);pid=body(x)['sandopPlanId'];(P/'plan-id.txt').write_text(pid)
 y=call('create-replay','POST',root,'create',create,'ver-create');check(y,201);assert y['responseBodyUtf8']==x['responseBodyUtf8'];assert y['requestHeaders']['X-Correlation-Id']!=x['requestHeaders']['X-Correlation-Id']
 check(call('changed-payload','POST',root,'create',{**create,'name':'changed'},'ver-create'),409,'IDEMPOTENCY_KEY_REUSED')
 p=root+'/'+pid;check(call('get','GET',p,'read'),200)
 check(call('no-permission','GET',p,None),403,'FORBIDDEN')
 check(call('foreign-tenant','GET',p,'read',tenant=str(uuid.uuid4())),404,'UNKNOWN_SANDOP_PLAN')
 check(call('foreign-le','GET',p,'read',le=str(uuid.uuid4())),404,'UNKNOWN_SANDOP_PLAN')
 check(call('no-auth','GET',p,auth=False),401)
 capture={'demandPlanId':'dp-2027','demandPlanVersion':'3','sourceCapturedAt':'2026-09-15T09:45:00Z','sourceChecksum':'sha256:abc','supplyInputRefs':[]}
 z=call('capture','POST',p+'/snapshots','snapshot.capture',capture,'ver-capture');check(z,201);sid=body(z)['snapshotId']
 y=call('capture-replay','POST',p+'/snapshots','snapshot.capture',capture,'ver-capture');check(y,201);assert y['responseBodyUtf8']==z['responseBodyUtf8']
 check(call('list-snapshots','GET',p+'/snapshots','read'),200)
 sign={'snapshotId':sid,'role':'Finance','decision':'Approved'}
 a=call('signoff','POST',p+'/sign-offs','sign-off.record',sign,'ver-sign');check(a,201)
 y=call('signoff-replay','POST',p+'/sign-offs','sign-off.record',sign,'ver-sign');check(y,201);assert y['responseBodyUtf8']==a['responseBodyUtf8']
 check(call('list-signoffs','GET',p+'/sign-offs','read'),200)
 s1=state('after-core');c=counts(s1);assert c=={'sandop_plans':1,'sandop_snapshots':1,'sandop_sign_offs':1,'sandop_receipts':3,'sandop_audit':3,'sandop_outbox':3},c
 assert all(d['Status']=='Pending' for d in s1['sandop_outbox']['docs'])
 assert s1['sandop_receipts']['docs'][0]['OriginalCorrelationId']==x['requestHeaders']['X-Correlation-Id']
 print('FIRST_PASS',len(records),c)
elif sys.argv[1]=='restart':
 pid=(P/'plan-id.txt').read_text();s0=state('before-restart');p=root+'/'+pid
 check(call('restart-get','GET',p,'read'),200)
 create={'name':'VER-FY2027','horizonStart':'2027-01-01','horizonEnd':'2027-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3'}
 y=call('restart-replay','POST',root,'create',create,'ver-create');check(y,201)
 x=next(r for r in records if r['tag']=='create');assert y['responseBodyUtf8']==x['responseBodyUtf8']
 check(call('restart-list-snapshots','GET',p+'/snapshots','read'),200)
 check(call('restart-list-signoffs','GET',p+'/sign-offs','read'),200)
 s1=state('after-restart');assert counts(s0)==counts(s1);assert all(d['Status']=='Pending' for d in s1['sandop_outbox']['docs']);print('RESTART_PASS',counts(s1))
elif sys.argv[1]=='fault':
 def fp(data=None):
  cmd={'configureFailPoint':'failCommand','mode':{'times':1},'data':data} if data else {'configureFailPoint':'failCommand','mode':'off'}
  script='print(JSON.stringify(db.getSiblingDB("admin").runCommand('+json.dumps(cmd)+')));'
  r=subprocess.run(['mongosh','--quiet','--port','57881','--eval',script],capture_output=True,text=True);assert r.returncode==0,(r.returncode,r.stderr);obj=json.loads(r.stdout.strip().splitlines()[-1]);assert obj['ok']==1,obj;return obj
 create={'name':'VER-fault','horizonStart':'2028-01-01','horizonEnd':'2028-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3'}
 before=state('before-fault');on=fp({'failCommands':['insert'],'namespace':'DitenSupplyChain_Mod0190_Test.sandop_receipts','errorCode':2})
 try:x=call('receipt-failure','POST',root,'create',create,'ver-fault')
 finally:off=fp()
 (P/'failpoint-on.json').write_text(json.dumps(on,indent=2));(P/'failpoint-off.json').write_text(json.dumps(off,indent=2));assert off['count']>on['count'];check(x,503,'DEPENDENCY_UNAVAILABLE')
 after=state('after-fault');assert counts(before)==counts(after),(counts(before),counts(after))
 y=call('receipt-retry','POST',root,'create',create,'ver-fault');check(y,201)
 recovery=state('after-fault-retry');delta={k:counts(recovery)[k]-counts(after)[k] for k in after};assert delta=={'sandop_plans':1,'sandop_snapshots':0,'sandop_sign_offs':0,'sandop_receipts':1,'sandop_audit':1,'sandop_outbox':1},delta
 print('FAULT_PASS',on['count'],off['count'],delta)
elif sys.argv[1]=='concurrent':
 from concurrent.futures import ThreadPoolExecutor
 create={'name':'VER-concurrent','horizonStart':'2029-01-01','horizonEnd':'2029-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3'}
 before=state('before-concurrent')
 with ThreadPoolExecutor(max_workers=2) as pool: xs=list(pool.map(lambda n:call('concurrent-'+str(n),'POST',root,'create',create,'ver-concurrent'),[1,2]))
 assert sorted(x['status'] for x in xs)==[201,201],[(x['status'],x['responseBodyUtf8']) for x in xs]
 assert xs[0]['responseBodyUtf8']==xs[1]['responseBodyUtf8']
 after=state('after-concurrent');delta={k:counts(after)[k]-counts(before)[k] for k in after};assert delta=={'sandop_plans':1,'sandop_snapshots':0,'sandop_sign_offs':0,'sandop_receipts':1,'sandop_audit':1,'sandop_outbox':1},delta
 print('CONCURRENT_PASS',delta)
