from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import re
import time

ROOT = Path('/private/tmp/mvp6-carrier-auth-le-implement-01-runtime')
MODE = ROOT / 'mdm-mode.txt'
LOG = ROOT / 'evidence' / 'mdm-safe.log'

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        mode = MODE.read_text().strip() if MODE.exists() else 'active'
        match = re.fullmatch(r'/api/legal-entities/([0-9a-fA-F-]{36})/lookup-validation', self.path)
        with LOG.open('a') as f:
            f.write(json.dumps({
                'mode': mode,
                'path': self.path,
                'tenant': self.headers.get('X-Tenant-Id'),
                'authorizationPresent': bool(self.headers.get('Authorization')),
            }) + '\n')
        if not match:
            self.send_response(404); self.end_headers(); return
        if mode == 'timeout':
            time.sleep(7)
        if mode == 'failure':
            self.send_response(503); self.end_headers(); return
        entity_id = match.group(1).lower()
        active = mode == 'active'
        body = {
            'data': {
                'legalEntityId': entity_id,
                'code': 'LE-TEST',
                'name': 'Isolated Test Legal Entity',
                'lifecycleState': 'ACTIVE' if active else 'SUSPENDED',
                'referenceable': active,
            },
            'statusCode': 200,
            'isSuccessful': True,
            'errors': [],
        }
        payload = json.dumps(body).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, fmt, *args):
        return

ThreadingHTTPServer(('127.0.0.1', 18059), Handler).serve_forever()
