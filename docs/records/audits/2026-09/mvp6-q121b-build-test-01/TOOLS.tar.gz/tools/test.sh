#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q121B_LANE=1
W=~/mvp6-env/q121b; mkdir -p $W/tmp; export TMPDIR=$W/tmp/
U="mongodb://127.0.0.1:57212/?replicaSet=rsq121b"
export CLAIMS_TEST_MONGO=$U MOD0183_TEST_MONGO=$U MOD0184_TEST_MONGO=$U MOD0185_TEST_MONGO=$U MVP6_MOD0190_MONGO_URI=$U RETURNS_MONGO_URI=$U
L=$W/logs/test; mkdir -p $L; S=$L/TEST-SUMMARY.tsv; printf "tree\tsuite\texit\tsummary\n" > $S
t() { tree=$1; n=$2; proj=$3; shift 3; cd $W/$tree
  dotnet test $proj --no-build --disable-build-servers --results-directory $L --logger "trx;LogFileName=$tree--$n.trx" "$@" > $L/$tree--$n.log 2>&1; rc=$?
  printf "%s\t%s\t%s\t%s\n" $tree $n $rc "$(grep -E '(Passed|Failed)!' $L/$tree--$n.log | tail -1 | sed 's/^ *//')" >> $S; }
PT=services/Diten.Platform/tests/Diten.Platform.Application.Tests/Diten.Platform.Application.Tests.csproj
AR=tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj
t build-before platform-application $PT
t build-after  platform-application $PT
t build-before architecture $AR
t build-after  architecture $AR
t build-after supplychain-single services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj
t build-after gateway gateway/Diten.ApiGateway.Tests/Diten.ApiGateway.Tests.csproj
t build-after web frontend/Diten.Web.Tests/Diten.Web.Tests.csproj
t build-after secrets services/Diten.Building.Blocks/Diten.BuildingBlocks.Security.Secrets.Tests/Diten.BuildingBlocks.Security.Secrets.Tests.csproj
echo TEST-DONE
