#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q121B_LANE=1
W=~/mvp6-env/q121b; L=$W/logs/build; mkdir -p $L; S=$L/BUILD-SUMMARY.tsv; printf "tree\ttarget\texit\twarnings\terrors\n" > $S
b() { tree=$1; t=$2; n=$tree--${${t:t}:r}; cd $W/$tree
  dotnet build $t -c Debug --disable-build-servers -p:UseSharedCompilation=false > $L/$n.log 2>&1; rc=$?
  w=$(grep -E '^ *[0-9]+ Warning\(s\)' $L/$n.log | tail -1 | awk '{print $1}'); e=$(grep -E '^ *[0-9]+ Error\(s\)' $L/$n.log | tail -1 | awk '{print $1}')
  printf "%s\t%s\t%s\t%s\t%s\n" $tree $t $rc "$w" "$e" >> $S; }
PT=services/Diten.Platform/tests/Diten.Platform.Application.Tests/Diten.Platform.Application.Tests.csproj
AR=tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj
for tr in build-before build-after; do b $tr $PT; b $tr $AR; done
for t in services/Diten.SupplyChainService/Diten.SupplyChainService.sln \
  services/Diten.Building.Blocks/Diten.BuildingBlocks.Security.Secrets.Tests/Diten.BuildingBlocks.Security.Secrets.Tests.csproj \
  frontend/Diten.Web.Tests/Diten.Web.Tests.csproj gateway/Diten.ApiGateway.Tests/Diten.ApiGateway.Tests.csproj; do b build-after $t; done
echo BUILD-DONE
