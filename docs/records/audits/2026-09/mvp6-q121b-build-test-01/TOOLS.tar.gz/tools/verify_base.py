import hashlib,os,sys,csv
root,man=sys.argv[1],sys.argv[2]
rows=list(csv.reader(open(man),delimiter='\t'))[1:]
bad=[];wr=0
for p,h,b in rows:
    f=os.path.join(root,p)
    try:
        d=open(f,'rb').read()
        if hashlib.sha256(d).hexdigest()!=h or len(d)!=int(b): bad.append(p)
        if os.stat(f).st_mode & 0o222: wr+=1
    except Exception as e: bad.append(p)
n=sum(len(fs) for _,_,fs in os.walk(root))
print(f"BASE-MANIFEST rows {len(rows)} mismatch {len(bad)} files on disk {n} writable {wr} {bad[:5]}")
