#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1 Q121B_LANE=1
W=~/mvp6-env/q121b; export TMPDIR=$W/tmp/
U="mongodb://127.0.0.1:57192/?replicaSet=rsmod192"
export CLAIMS_TEST_MONGO=$U MOD0183_TEST_MONGO=$U MOD0184_TEST_MONGO=$U MOD0185_TEST_MONGO=$U MVP6_MOD0190_MONGO_URI=$U RETURNS_MONGO_URI=$U
L=$W/logs/test; S=$L/TEST-SUMMARY.tsv; cd $W/build-after
dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj --no-build --disable-build-servers --results-directory $L --logger "trx;LogFileName=build-after--supplychain-single-57192.trx" > $L/build-after--supplychain-single-57192.log 2>&1; rc=$?
printf "%s\t%s\t%s\t%s\n" build-after supplychain-single-57192 $rc "$(grep -E '(Passed|Failed)!' $L/build-after--supplychain-single-57192.log | tail -1 | sed 's/^ *//')" >> $S
echo RERUN-DONE
