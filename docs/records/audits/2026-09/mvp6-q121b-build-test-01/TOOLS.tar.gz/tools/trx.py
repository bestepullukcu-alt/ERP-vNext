import sys,xml.etree.ElementTree as ET,collections
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def load(p):
    r=ET.parse(p).getroot(); d={}
    for u in r.iterfind('.//t:UnitTestResult',ns):
        d[u.get('testName')]=(u.get('outcome'),(u.findtext('.//t:Message',default='',namespaces=ns) or '').strip().splitlines()[:1])
    return d
b,a=load(sys.argv[1]),load(sys.argv[2])
print('tests before',len(b),'after',len(a),'same names',set(a)==set(b))
fb={k for k,v in b.items() if v[0]!='Passed'}; fa={k for k,v in a.items() if v[0]!='Passed'}
print('failed before',len(fb),'after',len(fa),'identical set',fb==fa)
print('only-before',sorted(fb-fa)); print('only-after',sorted(fa-fb))
for k in sorted(set(a)|set(b)):
    if any(s in k for s in ['Inserts_only_missing_portfolio_delivery_policy','StandaloneMongo_ReturnsTyped503','StandaloneMongo_ProductionSubscriptionWriter']):
        print('TOUCHED',k,'before',b.get(k,('-',))[0],'after',a.get(k,('-',))[0])
cls=collections.Counter(k.rsplit('.',2)[-2] if k.count('.')>=2 else k for k in fa)
print('FAILING BY CLASS'); [print(f'  {n}\t{c}') for c,n in sorted(((v,k) for k,v in cls.items()),reverse=True)]
msgs=collections.Counter((a[k][1][0][:140] if a[k][1] else '') for k in fa)
print('FIRST-LINE MESSAGES'); [print(f'  {n}\t{m}') for m,n in msgs.most_common(12)]
