import base64
import hashlib
import hmac
import json
import os
import subprocess
import time
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:18759"
DB = "DitenMdm_CarrierNumericDateExec"
TENANT = "00000000-0000-0000-0000-000000000001"
ACTOR = "249679de-35b9-47ff-a2bc-4ff1aa116998"
LEGAL_ENTITY = "10000000-0000-0000-0000-000000000001"
AUD = "diten-mdm-reference-validation"
PATH = f"/api/internal/tenants/{TENANT}/legal-entities/{LEGAL_ENTITY}/reference-validation"
SECRET = open(os.environ["NUMERICDATE_SECRET_FILE"], encoding="utf-8").read().strip()


def b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def sign(payload, raw_payload=None):
    header = {"alg": "HS256", "typ": "JWT", "kid": "platform-mdm-numericdate"}
    header_part = b64(json.dumps(header, separators=(",", ":")).encode())
    body = raw_payload if raw_payload is not None else json.dumps(payload, separators=(",", ":"))
    signing = f"{header_part}.{b64(body.encode())}"
    signature = hmac.new(SECRET.encode(), signing.encode(), hashlib.sha256).digest()
    return f"{signing}.{b64(signature)}"


def payload(now):
    return {
        "iss": "diten-platform-service",
        "aud": AUD,
        "sub": "Diten.Platform",
        "scope": "mdm.legal-entities.reference.validate",
        "tenant_id": TENANT,
        "actor_id": ACTOR,
        "legal_entity_id": LEGAL_ENTITY,
        "jti": f"ver02-{now}-{time.time_ns()}",
        "iat": now,
        "nbf": now,
        "exp": now + 30,
    }


def mongo(js):
    return subprocess.run(
        ["mongosh", "--quiet", "--port", "37884", "--eval", js],
        check=True, capture_output=True, text=True,
    ).stdout.strip()


def reset_profile():
    mongo(f'const d=db.getSiblingDB("{DB}"); d.setProfilingLevel(0); try{{d.system.profile.drop()}}catch(e){{}}; d.setProfilingLevel(2);')


def read_count():
    raw = mongo(
        f'const d=db.getSiblingDB("{DB}"); print(d.system.profile.countDocuments('
        f'{{ns:"{DB}.mdm_legal_entities",$or:[{{op:"query"}},{{"command.find":"mdm_legal_entities"}}]}}));'
    )
    return int(raw.splitlines()[-1])


def call(case_id, token_factory, expected, expected_reads=0):
    reset_profile()
    token = token_factory()
    req = urllib.request.Request(
        BASE + PATH,
        headers={
            "Authorization": "Bearer " + token,
            "X-Tenant-Id": TENANT,
            "X-Actor-Id": ACTOR,
            "X-Correlation-Id": "carrier-numericdate-" + case_id,
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            body = response.read()
            status = response.status
    except urllib.error.HTTPError as error:
        body = error.read()
        status = error.code
    time.sleep(0.15)
    reads = read_count()
    return {
        "caseId": case_id,
        "expectedStatus": expected,
        "actualStatus": status,
        "expectedRepositoryReads": expected_reads,
        "repositoryReads": reads,
        "passed": status == expected and reads == expected_reads,
        "requestBodyBytes": 0,
        "responseBytes": len(body),
        "responseSha256": hashlib.sha256(body).hexdigest(),
    }


cases = []


def run(case_id, mutate=None, expected=401, reads=0, raw=None, invalid_token=None):
    def make_token():
        now = int(time.time())
        p = payload(now)
        if mutate:
            mutate(p, now)
        return invalid_token if invalid_token is not None else sign(p, raw(p) if raw else None)
    cases.append(call(case_id, make_token, expected, reads))


run("valid", expected=200, reads=1)

for claim in ["sub", "scope", "tenant_id", "actor_id", "legal_entity_id", "jti", "iat", "nbf", "exp"]:
    run(f"identical-duplicate-{claim}", lambda p, n, c=claim: p.__setitem__(c, [p[c], p[c]]))

for claim in ["sub", "scope", "tenant_id", "actor_id", "legal_entity_id", "jti", "iat", "nbf", "exp"]:
    def conflicting(p, n, c=claim):
        other = n - 1 if c in {"iat", "nbf", "exp"} else "conflicting-value"
        p[c] = [p[c], other]
    run(f"conflicting-duplicate-{claim}", conflicting)

run("duplicate-expected-audience", lambda p, n: p.__setitem__("aud", [AUD, AUD]))
run("expected-plus-other-audience", lambda p, n: p.__setitem__("aud", [AUD, "other-audience"]))
run("wrong-only-audience", lambda p, n: p.__setitem__("aud", "other-audience"))

for claim in ["sub", "scope", "tenant_id", "actor_id", "legal_entity_id", "jti", "iat", "nbf", "exp"]:
    run(f"missing-{claim}", lambda p, n, c=claim: p.pop(c))

for claim in ["iat", "nbf", "exp"]:
    run(f"malformed-{claim}", lambda p, n, c=claim: p.__setitem__(c, "not-a-number"))

run("duplicate-sub-expected-first", lambda p, n: p.__setitem__("sub", ["Diten.Platform", "other"]))
run("duplicate-sub-expected-last", lambda p, n: p.__setitem__("sub", ["other", "Diten.Platform"]))
run("invalid-signed-identity", invalid_token="not-a-jwt")

run("future-inside-skew", lambda p, n: p.update(iat=n + 3, nbf=n + 3, exp=n + 33), expected=200, reads=1)
run("future-outside-skew", lambda p, n: p.update(iat=n + 8, nbf=n + 8, exp=n + 38))
run("iat-nbf-mismatch", lambda p, n: p.update(iat=n, nbf=n + 1, exp=n + 30))
run("expired-inside-skew", lambda p, n: p.update(iat=n - 20, nbf=n - 20, exp=n - 2), expected=200, reads=1)
run("expired-outside-skew", lambda p, n: p.update(iat=n - 20, nbf=n - 20, exp=n - 8))
run("lifetime-exact-60", lambda p, n: p.update(iat=n, nbf=n, exp=n + 60), expected=200, reads=1)
run("lifetime-61", lambda p, n: p.update(iat=n, nbf=n, exp=n + 61))
run("exp-equals-iat", lambda p, n: p.update(iat=n, nbf=n, exp=n))
run("exp-before-iat", lambda p, n: p.update(iat=n, nbf=n, exp=n - 1))

for claim in ["iat", "nbf", "exp"]:
    def as_digit_string(p, n, c=claim):
        p[c] = str(p[c])
    run(f"numericdate-string-{claim}", as_digit_string)

result = {
    "summary": {"passed": sum(1 for c in cases if c["passed"]), "total": len(cases)},
    "cases": cases,
}
print(json.dumps(result, indent=2))
raise SystemExit(0 if all(c["passed"] for c in cases) else 1)
