# Discarded verification attempts

No failed attempt was counted as evidence of PASS.

1. The first static reverse/apply harness used `path` as a zsh loop variable. In zsh this
   aliases the executable search path, so `sha256sum` and `awk` became unavailable after
   the reverse application. The snapshot state was known (exact reverse application had
   succeeded); the corrected harness first verified all three preimages, then reapplied the
   patch and verified all targets and all 43 successor rows. The partial log is retained as
   `evidence/static-verification-discarded.log`.
2. Sandboxed NuGet restore stalled at `Determining projects to restore`. It was cancelled
   and replaced with an authorized native restore. The partial log is retained as
   `evidence/sandbox-restore-discarded.log`.
3. A diagnostic `--no-restore` build before restore failed with NETSDK1004 because the
   clean snapshot correctly had no `project.assets.json`. It was not counted.
4. A sandboxed build produced no output because of the environment's MSBuild process/
   named-pipe restriction and was cancelled. The counted build used native SDK 8.0.417,
   `-m:1 /nr:false -t:Rebuild`, and completed with zero warnings and errors.
5. The first two sandboxed Mongo starts failed before accepting connections: first on the
   Unix socket, then on the TCP bind. Both failures and shutdown traces remain in the single
   append-only `evidence/mongod.log`. The counted server was the authorized native process
   with `--nounixsocket`, replica set `rsmod192`, and `enableTestCommands=1`.
6. The first source-manifest comparison harness accidentally processed the second file's
   header as a data row. The discarded output is retained as
   `evidence/source-manifest-verification-discarded.log`; the corrected comparison reports
   43 verified links and zero mismatch.
