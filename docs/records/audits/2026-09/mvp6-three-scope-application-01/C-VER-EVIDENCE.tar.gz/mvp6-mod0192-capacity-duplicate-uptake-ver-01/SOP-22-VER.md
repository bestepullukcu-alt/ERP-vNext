# MVP6-MOD0192-CAPACITY-DUPLICATE-UPTAKE-VER-01 — SOP §22 independent VER

Date: 2026-09-23  
Role: independent verifier; did not prepare or apply the uptake candidate  
Writer checkout: `/private/tmp/mvp6-mod0192-capacity-uptake-01`  
Disposable verification snapshot: `/private/tmp/mvp6-capacity-uptake-ver.bFMe7S`  
Detached base HEAD: `4a8d4d4b339528a88e6220fb8402e5a2c771136c`

## Verdict

Agent Verdict: **writer PASS received**.  
Verification Verdict: **PASS for the exact, bounded post-publication Capacity uptake**.  
Control Tower Status: **NOT ASSESSED / no CT acceptance claimed**.

The authorized three-file patch is present byte-for-byte after the exact v3 publication.
Its only production delta is the single `CAPACITY_SCENARIO_NAME_CONFLICT` message mapping
in `CapacityContractError.cs`; the other two changed files are Capacity-owned tests.
Repository, executor, schema, `Program.cs`, and the X01/X07 production/test baseline are
unchanged. A fresh .NET 8 rebuild, the three successor tests, and the complete 34-case
CapacityPlans regression passed in an independent disposable snapshot.

## Authority and publication binding

| Item | Independently observed SHA-256 / result |
|---|---|
| Authorized uptake patch | `f4fc82b44eb237d1dbc8bdd9c0d9633c948ca4e33cd2dcff91cd65f653780c8f` |
| Published canonical v3 YAML | `5213b5353267ad4c25d150975d6f38422bced72f678c02271b0cccf6e768adab` |
| Published canonical v3 annex | `f9d9d5553d70e1c54af3e03924600f4c8f426de50355ae861a4d3d5cef21ee64` |
| Preserved v2 annex | `eb1df1383e637c744179abe4c8faa3b3b7ebe4cccd19738aadf41896a9311bda` |
| Original 43-source manifest | `36114191e1576b8b5654b9910f3347432d5d3bf36aac87339a4280cc85a852f8` |
| Original 43-source archive | `753843251ea261473e308e5fb100de834b1e5ab88fa7576ff50ad22bf332274e` |
| Successor source manifest | `1fbfa066796eac0ea7cdee1656edf755248f36dcd29495e0c49d60d56567cc94` |

The persistent publication handoff reports production-mode DocsPathGuard 39/39 PASS.
The canonical v3 hashes above were re-read from the common checkout before verification.

## Exact source verification

The successor manifest has 43 data rows: exactly 3 `UPTAKE` and 40 `UNCHANGED`.
Every successor `uptake_preimage_sha256` was compared with the original 43-source
manifest: 43/43 links matched. All 43 current source files matched the successor hashes.

The patch was reverse-checked and reverse-applied only in the disposable snapshot. This
reproduced all three preimages. Reapplying the exact patch reproduced all three targets:

| Path | Preimage SHA-256 | Target SHA-256 |
|---|---|---|
| `services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/Features/CapacityPlans/CapacityContractError.cs` | `a618a18674859d8e23b032576e022c0544dc0f5e219aa978dd48fe0715b5b591` | `c55ad1616576bf73c062e16a8e745bd15e652c9ff4cf1ef575fc59b123c9cd7e` |
| `services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/CapacityPlans/CapacityContractTests.cs` | `0b65cab32a2196fcc422dc76958a5f755ce6709f9266384a6a5ecfd154d01ffd` | `4d57bf51d9d299b02037db0494e3f339e3c1558c2edd59b7a0f04cd578fa52cf` |
| `services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/CapacityPlans/CapacityConcurrencyTests.cs` | `b5eedf0033f10dc9989d79552c2fb4bc0f11a3014e2550537ddbfd301868aedf` | `45329002c8e54ae225081152104116e204e878e1df77267ba6be9c1e1422d514` |

Patch shape is 3 files, 99 insertions, 2 deletions. Production is 1 insertion only: the
exact successor message. The remaining delta is test-only.

No-change checks:

- `CapacityRepository.cs`: `6bf026d3bfaeddf37ff4e461efedfa977a07765a413d5f363fcbdc80edfe0364`.
- `CapacityEvaluationExecutor.cs`: `c5bcc0490669b3c692980b106a6b036d606966a1b5dabd6c96635e425421d095`.
- `CapacitySchema.cs`: `ac704148cff99a8015ba3e8337ad7c05daf319d4f39eb18e571b09a7c0fc0ed7`.
- `CapacityAtomicityTests.cs` (X01/X07 surface): `91999330faf2a50f5ff2cda3595506ecded50d5b87ffb7bf393dd655f71e51db`.
- `Program.cs`: worktree and detached HEAD both `74d2d2007cb89976c41e5460ca841f442e24b9d4e6290daf5b59f7929e069736`; no status entry.

## Integration-baseline separation

The canonical integration selection remains the separate 422-row manifest with SHA-256
`cdc6228aa3d215f34f2f2f9d5b784cf57ac20b6eb8f2c2f26bdcace9dcd4d76c`.
Its authority record explicitly excludes this successor patch. The isolated integration
checkout still contains the Capacity error mapper preimage
`a618a18674859d8e23b032576e022c0544dc0f5e219aa978dd48fe0715b5b591`, while the writer
checkout contains the successor target. The 43-row successor manifest was therefore not
silently added to B's baseline.

## Independent execution

| Check | Result |
|---|---|
| SDK | Native .NET SDK `8.0.417` |
| SupplyChain API `Rebuild` | PASS; 0 warnings, 0 errors |
| Exact successor tests | PASS; 3/3 |
| CapacityPlans regression | PASS; 34/34, 0 skipped, 2m27s test duration |
| Mongo | `127.0.0.1:57192`, replica set `rsmod192`, `enableTestCommands=true` |
| DB-010 | One fixed database `DitenSupplyChain_Mod0192_Test`; isolation remains tenant-scoped |
| Process cleanup | Mongo PID `10651` shut down; port 57192 has no listener |

The targeted set independently exercised the exact message mapping, the forced two-request
exact-name race and loser write-set boundary, and replay/lifecycle/fixture/scope/collation/
unrelated-duplicate policy. The 34-case regression included the unchanged X01/X07 fault and
unknown-commit coverage and the separate-process restart test.

Binary binding:

- API DLL: `de4a17cc1bbfe99b9aec50cf957561cfa867449ec1def31a34fd3a3c81240eb4`.
- Test DLL: `e903a1a0f60b99c9b9cb5c3a80555b0769a8f0de7c13e5af90cbef0c9e48570c`.
- Targeted TRX: `17b17f44b3d41c793e00149b18e849f5acec8a9545a134edeced69ebbeaedcf9`.
- Regression TRX: `1a5106cbf6cdbd826b73b03669d77ecfab29ff3933d15f14a69978ab9ce293db`.

## Structured report

Changed files: this VER added only this new immutable audit directory to the writer checkout.
No writer source was modified.  
Golden/Contract flow: exact v3 publication hashes and exact message mapping verified.  
Sub-flows: race convergence, replay precedence, scope, collation, lifecycle, fixture precedence,
unrelated duplicate, transient/unknown-commit and restart coverage passed.  
Failure paths: X01/X07 and negative duplicate paths passed in the 34-case regression.  
Tests: 3/3 targeted and 34/34 CapacityPlans PASS.  
Persistence evidence: real isolated Mongo replica set; race and write-set assertions passed.  
Security/RBAC/Tenant evidence: no new permission surface; existing tenant/LE/plan isolation tests passed.  
Audit/Evidence: raw TRX, logs, hashes, Mongo log and discarded attempts retained.  
Observability: no production observability delta.  
Migration/Rollback: no migration; exact patch reverse-check passed.  
Decisions: bounded uptake PASS only.  
Blockers: none for this bounded VER.  
Known gaps: no rollout, live producer, gateway/UI, shared permission, full-module or E5/G5 claim.  
Out-of-scope changes: none.

## Evidence inventory

- `evidence/` contains the source/preimage/scope checks, build/test logs, both TRX files,
  source-to-binary bindings, Mongo readiness/log/shutdown, cleanup proof, and discarded attempts.
- `EVIDENCE-SHA256SUMS` seals every file under `evidence/`.
- `VER-RAW.tar.gz` SHA-256:
  `74339f044445f4550d8c01d3afa007588bf8a28adf2b1d933af886514562dd14`.

## Boundaries

This is independent verification of authorization C only. It grants no Control Tower
acceptance, gateway/UI/shared-permission/live-producer change, rollout, E5/G5,
full-module acceptance, commit, push, stash, or integration-baseline mutation.
