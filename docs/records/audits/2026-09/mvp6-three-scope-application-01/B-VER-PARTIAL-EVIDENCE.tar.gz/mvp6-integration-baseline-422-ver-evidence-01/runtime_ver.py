#!/usr/bin/env python3
import base64, hashlib, hmac, json, os, pathlib, subprocess, time, urllib.error, urllib.request, uuid

SNAP = pathlib.Path('/private/tmp/mvp6-integration-baseline-422-ver-snapshot-01')
EVID = pathlib.Path('/private/tmp/mvp6-integration-baseline-422-ver-evidence-01/raw')
DLL = SNAP / 'services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll'
DOTNET = '/Users/natig/.dotnet/dotnet'
BASE = 'http://127.0.0.1:56942'
MONGO = 'mongodb://127.0.0.1:57931/?replicaSet=rsver422&serverSelectionTimeoutMS=5000'
DB = 'DitenSupplyChain_Ver422_Runtime'
SECRET = 'independent-ver-only-secret-422-abcdefghijklmnopqrstuvwxyz'
ISSUER = 'mvp6-ver'
AUDIENCE = 'mvp6-ver-api'
TENANT = '19200000-0000-4000-8000-000000000001'
LE = '19200000-0000-4000-8000-000000000002'
ACTOR = '19200000-0000-4000-8000-000000000003'
PERMS = ['supplychain.capacity-plans.read','supplychain.capacity-plans.create','supplychain.capacity-plans.scenario.create','supplychain.capacity-plans.evaluate','supplychain.sandop-plans.read','supplychain.sandop-plans.create','supplychain.sandop-plans.snapshot.capture','supplychain.sandop-plans.sign-off.record']

def b64(v): return base64.urlsafe_b64encode(v).rstrip(b'=')
def token(tenant=TENANT, perms=PERMS):
    header=b64(json.dumps({'alg':'HS256','typ':'JWT'},separators=(',',':')).encode())
    payload=b64(json.dumps({'sub':ACTOR,'tenant_id':tenant,'legal_entity_id':LE,'permission':perms,'iss':ISSUER,'aud':AUDIENCE,'exp':int(time.time())+3600},separators=(',',':')).encode())
    sig=b64(hmac.new(SECRET.encode(),header+b'.'+payload,hashlib.sha256).digest())
    return b'.'.join((header,payload,sig)).decode()

def request(method,path,tok=None,body=None,key=None,sandop=False):
    headers={'X-Correlation-Id':str(uuid.uuid4())}
    if tok: headers['Authorization']='Bearer '+tok
    if body is not None: headers['Content-Type']='application/json'
    if key: headers['Idempotency-Key']=key
    if sandop:
        headers['X-Tenant-Id']=TENANT; headers['X-Legal-Entity-Id']=LE
    req=urllib.request.Request(BASE+path,data=None if body is None else json.dumps(body,separators=(',',':')).encode(),headers=headers,method=method)
    try:
        with urllib.request.urlopen(req,timeout=15) as r: return r.status,json.loads(r.read() or b'null'),dict(r.headers)
    except urllib.error.HTTPError as e:
        raw=e.read(); return e.code,(json.loads(raw) if raw else None),dict(e.headers)

def start(logname):
    env=os.environ.copy(); env.update({
      'ASPNETCORE_ENVIRONMENT':'Testing','ASPNETCORE_URLS':BASE,
      'Mongo__ConnectionString':MONGO,'Mongo__DatabaseName':DB,
      'JwtSettings__Secret':SECRET,'JwtSettings__Issuer':ISSUER,'JwtSettings__Audience':AUDIENCE,
      'Sandop__DemandFixtures__0__TenantId':TENANT,'Sandop__DemandFixtures__0__LegalEntityId':LE,
      'Sandop__DemandFixtures__0__PlanId':'dp-2027','Sandop__DemandFixtures__0__Version':'3',
      'Sandop__DemandFixtures__0__Checksum':'sha256:abc','Sandop__DemandFixtures__0__Published':'true'})
    log=open(EVID/logname,'wb')
    proc=subprocess.Popen([DOTNET,str(DLL)],cwd=SNAP,env=env,stdout=log,stderr=subprocess.STDOUT)
    for _ in range(100):
        try:
            with urllib.request.urlopen(BASE+'/health',timeout=.5) as r:
                if r.status==200: return proc,log
        except Exception: time.sleep(.1)
    raise RuntimeError('API did not become ready')

def stop(proc,log):
    proc.terminate()
    try: proc.wait(timeout=10)
    except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=5)
    log.close()

subprocess.run(['mongosh','--quiet','--port','57931','--eval',f'db.getSiblingDB("{DB}").dropDatabase()'],check=True,capture_output=True,text=True)
result={'runtime':{'sdk':'8.0.417','aspnet':'8.0.23','apiDllSha256':hashlib.sha256(DLL.read_bytes()).hexdigest(),'dllMtime':DLL.stat().st_mtime}}
good=token(); denied=token(perms=[]); foreign=token(tenant='19200000-0000-4000-8000-000000000099')
proc,log=start('api-first.log'); result['runtime']['firstPid']=proc.pid; result['runtime']['firstStartedAfterDll']=time.time()>DLL.stat().st_mtime
try:
    result['unauthenticated']=request('GET','/api/supply-chain/capacity-plans/11111111-1111-4111-8111-111111111111')[0]
    result['permissionDenied']=request('GET','/api/supply-chain/capacity-plans/11111111-1111-4111-8111-111111111111',denied)[0]
    plan={'name':'FY2027 Capacity Baseline','horizonStart':'2027-01-01','horizonEnd':'2027-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3','sourceCapturedAt':'2026-09-15T09:45:00Z','sourceChecksum':'sha256:ee56d4f9a3c8'}
    s,b,_=request('POST','/api/supply-chain/capacity-plans',good,plan,'cap-plan-key'); result['capacityCreate']={'status':s,'body':b}; planid=b['capacityPlanId']
    result['capacityReplayStatus']=request('POST','/api/supply-chain/capacity-plans',good,plan,'cap-plan-key')[0]
    result['capacityForeignStatus']=request('GET',f'/api/supply-chain/capacity-plans/{planid}',foreign)[0]
    scenario={'name':'Add weekend shift','constraintRefs':[{'constraintId':'line-4-hours','source':'SUPPLY-CONSTRAINTS','sourceVersion':'8'}],'adjustments':[{'resourceRef':'line-4','period':'2027-W03','availableCapacityDelta':'80.000','uomId':'HOUR'}]}
    s,b,_=request('POST',f'/api/supply-chain/capacity-plans/{planid}/scenarios',good,scenario,'cap-scenario-key'); result['capacityScenario']={'status':s,'body':b}; scenarioid=b['scenarioId']
    evaluation={'evaluationMode':'Finite','resourceRefs':['line-4']}
    s,b,_=request('POST',f'/api/supply-chain/capacity-plans/{planid}/scenarios/{scenarioid}/evaluations',good,evaluation,'cap-eval-key'); result['capacityEvaluate']={'status':s,'body':b}; evalid=b['evaluationId']
    terminal=None
    for _ in range(50):
        s,b,_=request('GET',f'/api/supply-chain/capacity-plans/{planid}/evaluations/{evalid}',good)
        if s==200 and b.get('status') in ('Completed','Failed'): terminal=b; break
        time.sleep(.2)
    result['capacityTerminal']=terminal
    spl={'name':'FY2027 S&OP','horizonStart':'2027-01-01','horizonEnd':'2027-12-31','demandPlanId':'dp-2027','demandPlanVersion':'3'}
    s,b,_=request('POST','/api/supply-chain/sandop-plans',good,spl,'sandop-plan-key',True); result['sandopCreate']={'status':s,'body':b}; spid=b['sandopPlanId']
    result['sandopReplayStatus']=request('POST','/api/supply-chain/sandop-plans',good,spl,'sandop-plan-key',True)[0]
    result['sandopForeignStatus']=request('GET',f'/api/supply-chain/sandop-plans/{spid}',foreign,sandop=True)[0]
    snap={'demandPlanId':'dp-2027','demandPlanVersion':'3','sourceCapturedAt':'2026-09-15T09:45:00Z','sourceChecksum':'sha256:abc','supplyInputRefs':[]}
    s,b,_=request('POST',f'/api/supply-chain/sandop-plans/{spid}/snapshots',good,snap,'sandop-snap-key',True); result['sandopSnapshot']={'status':s,'body':b}; snapid=b['snapshotId']
    sign={'snapshotId':snapid,'role':'Executive','decision':'Approved','comment':'independent-ver'}
    s,b,_=request('POST',f'/api/supply-chain/sandop-plans/{spid}/sign-offs',good,sign,'sandop-sign-key',True); result['sandopSignoff']={'status':s,'body':b}
finally: stop(proc,log)

proc,log=start('api-restart.log'); result['runtime']['restartPid']=proc.pid; result['runtime']['restartStartedAfterDll']=time.time()>DLL.stat().st_mtime
try:
    result['capacityAfterRestart']=request('GET',f'/api/supply-chain/capacity-plans/{planid}/evaluations/{evalid}',good)[:2]
    result['capacityReplayAfterRestart']=request('POST','/api/supply-chain/capacity-plans',good,plan,'cap-plan-key')[:2]
    result['sandopAfterRestart']=request('GET',f'/api/supply-chain/sandop-plans/{spid}',good,sandop=True)[:2]
    result['sandopReplayAfterRestart']=request('POST','/api/supply-chain/sandop-plans',good,spl,'sandop-plan-key',True)[:2]
    result['sandopSnapshotsAfterRestart']=request('GET',f'/api/supply-chain/sandop-plans/{spid}/snapshots',good,sandop=True)[:2]
    result['sandopSignoffsAfterRestart']=request('GET',f'/api/supply-chain/sandop-plans/{spid}/sign-offs',good,sandop=True)[:2]
finally: stop(proc,log)

js=f'''const d=db.getSiblingDB("{DB}"); print(JSON.stringify({{terminalAudit:d.capacity_audit.countDocuments({{Operation:"terminalCapacityEvaluation"}}),pendingTerminalEvent:d.capacity_outbox.countDocuments({{EventType:"capacity.evaluation.completed.v1",Status:"Pending"}}),activeSlots:d.capacity_active_slots.countDocuments({{}}),sandopSnapshots:d.sandop_snapshots.countDocuments({{}}),sandopSignoffs:d.sandop_sign_offs.countDocuments({{}})}}))'''
dbout=subprocess.run(['mongosh','--quiet','--port','57931','--eval',js],check=True,capture_output=True,text=True).stdout.strip().splitlines()[-1]
result['db']=json.loads(dbout)
(EVID/'HTTP-DB-INDEPENDENT-VER.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
