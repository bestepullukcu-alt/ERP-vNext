# Independent VER reproduction commands

The controlling commands used native `/Users/natig/.dotnet/dotnet` 8.0.417 from the disposable snapshot.

```bash
/Users/natig/.dotnet/dotnet restore services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj --disable-parallel -v minimal
/Users/natig/.dotnet/dotnet build services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-restore -m:1 /nr:false

# Required retry environment for a future verifier (not rerun in this capped lane):
mongod --dbpath <lane-dir> --port 57192 --replSet rsmod192 --bind_ip 127.0.0.1 --setParameter enableTestCommands=1
/Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~CapacityPlans'

MVP6_MOD0190_MONGO_URI='mongodb://127.0.0.1:57931/?replicaSet=rsver422&serverSelectionTimeoutMS=5000' /Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~SandopPlans'

MOD0183_TEST_MONGO='<lane-owned-replica-set>' MOD0184_TEST_MONGO='<lane-owned-replica-set>' MOD0185_TEST_MONGO='<lane-owned-replica-set>' RETURNS_MONGO_URI='<lane-owned-replica-set>' CLAIMS_TEST_MONGO='<lane-owned-replica-set>' /Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~ShipmentRootHttpTests|FullyQualifiedName~CarrierContractTests|FullyQualifiedName~LoadReferenceTests|FullyQualifiedName~ReturnReferenceTests|FullyQualifiedName~ClaimIsolationTests|FullyQualifiedName~ClaimReferenceTests'

PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/mvp6-integration-baseline-422-ver-evidence-01/runtime_ver.py
```
