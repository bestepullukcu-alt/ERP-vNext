# MVP6-INTEGRATION-BASELINE-422-INDEPENDENT-VER-01 — SOP §22 VER

**Verification verdict: BLOCKED / fail-closed.** The exact 422-path source composition, fresh build, S&OP regression, selected cross-module seams, and composed Capacity/S&OP HTTP restart-persistence flow independently passed. The required CapacityPlans suite did not reach product behavior in the controlling verifier rerun: the source hard-codes `replicaSet=rsmod192`, while the verifier's port-57192 Mongo process was initiated as `rsver57192`; 30 tests failed server selection and 6 non-Mongo tests passed. Per the one-rerun cap, no further Capacity rerun was attempted. This lane therefore does not issue independent PASS or CT acceptance.

## Identity and boundary

- Verifier lane: independent VER; the integration writer did not perform this verification.
- Writer checkout, read-only: `/private/tmp/mvp6-integration-baseline-422-01`.
- Disposable hash-identical snapshot: `/private/tmp/mvp6-integration-baseline-422-ver-snapshot-01` (removed after evidence capture).
- Base HEAD: `4a8d4d4b339528a88e6220fb8402e5a2c771136c`.
- Runtime: native .NET SDK `8.0.417`; ASP.NET Core `8.0.23`.
- Excluded and untouched: gateway, UI, shared permission registry, live producer/publisher/Event Bus, rollout, E5/G5, pack/status, canonical/guard, duplicate-name successor, commit, push and stash.

## Exact source and custody checks

- MOD-0190 source archive/manifest: `8fa00d40814a81472ec4221ad909321d058dea18a11f64dd2ac16ea800ecb745` / `ae7ef59e0158113c22389ccd3eec84207418f3a859c40480e70b42ee888a9bef`; 379 rows.
- Capacity archive/manifest: `753843251ea261473e308e5fb100de834b1e5ab88fa7576ff50ad22bf332274e` / `36114191e1576b8b5654b9910f3347432d5d3bf36aac87339a4280cc85a852f8`; 43 rows.
- Intersection: zero paths.
- Independently extracted Program chain: preimage `a2a216be15d07fa656f5fd7da43711aa989c4a8d52cd51c58e8ded48d5d735e5` + patch `78cc0fa61dd37019f525c621c572d1dc2ef518eb0b4faf520a280f01909db82e` → target `50c48a2b895804162f36740703bca20d3f0c3f96f2511133e843d75fcf7830f0`.
- Independently extracted Capacity test chain: preimage `91999330faf2a50f5ff2cda3595506ecded50d5b87ffb7bf393dd655f71e51db` + patch `b6744cddfd498536abeb4b350d8b8b2bd1c30c0824875757522026ed5f01df81` → target `2c133ac1b6b431db074b0054b0337bbc3957fce5869c7aca9291454a53681c43`.
- Accepted S&OP test target: `eba2da6f47a4935b61857a95534b3d1697635910190e3838494d96d956af7f43`.
- Independently derived selection: 422 rows, 74,155 bytes, SHA-256 `cdc6228aa3d215f34f2f2f9d5b784cf57ac20b6eb8f2c2f26bdcace9dcd4d76c`.
- Writer and snapshot rehash: zero mismatches across all 422 selected paths. Snapshot rehash remained zero after build/tests.
- Duplicate successor absent: `CapacityContractError.cs` stayed at `a618a18674859d8e23b032576e022c0544dc0f5e219aa978dd48fe0715b5b591`, not successor target `c55ad1616576bf73c062e16a8e745bd15e652c9ff4cf1ef575fc59b123c9cd7e`.
- Claims normal binding present: `IClaimCommitProbe` resolves to `NoOpClaimCommitProbe`; no `ClaimsEvidence`/evidence-probe product registration was found.

## Fresh build and bounded regression

| Gate | Controlling result |
|---|---|
| Fresh restore | PASS from an empty `bin/obj` snapshot. |
| Native .NET 8 build | PASS; 0 warnings, 0 errors. |
| CapacityPlans | **BLOCKED: 6/36 passed, 30/36 failed before product behavior** because the verifier Mongo replica-set name did not match the source-pinned `rsmod192`. Both raw TRX files are retained; no third invocation occurred. |
| SandopPlans | PASS on the single allowed rerun: 19/19. The initial 16/19 run lacked Mongo `enableTestCommands`; both TRX files are retained. |
| Selected cross-module seams | PASS first run: 128/128. |

Fresh binaries:

- API DLL SHA-256: `3f1bb9b3691a212dda0c9116170d291d7e504463f7d1f11211922304df6190de`.
- Test DLL SHA-256: `56d8fd7585b8e4bb23014bdafd06253c668cfb5aed8d52fb35860ba28f0dfdeb`.

## Composed HTTP/JWT/restart/persistence evidence

The independently started API used the freshly built DLL and a lane-owned replica set/database. Both process starts occurred after the DLL timestamp.

- Capacity: unauthenticated `401`; permission denial `403`; foreign-tenant read `404`; plan/scenario/evaluation creation `201/201/202`; same-key replay retained the original plan; terminal read was `Completed`; restart returned the same evaluation and original plan receipt.
- Capacity persistence after restart: exactly one `terminalCapacityEvaluation` audit, one Pending `capacity.evaluation.completed.v1` outbox event, zero active slots.
- S&OP: create/snapshot/sign-off `201/201/201`; same-key replay retained the original plan; restart returned `InReview`, the original Draft create receipt, one snapshot and one sign-off.
- S&OP foreign-token check returned `403` because the request headers retained the original tenant and were rejected at the signed-context/header equality gate. This is a denial, but it does not independently reproduce the writer's foreign-scope `404`; the expected matching-foreign-header 404 check remains open.
- No gateway or publisher was involved; Capacity used the exact bounded DEMAND/constraint fixture and S&OP used a Testing-only DEMAND fixture.

Raw evidence: `raw/HTTP-DB-INDEPENDENT-VER.json`, API logs, Mongo logs, build/restore logs, and five TRX files in this package.

## SOP §22 fields

- **Agent verdict:** writer claimed PASS / writer-complete.
- **Verification verdict:** BLOCKED / fail-closed; no independent PASS.
- **CT status:** unchanged; independent VER and CT acceptance remain open.
- **Changed files:** no writer/common source files. This standalone `/private/tmp` evidence package only.
- **Golden/contract flow:** exact source chain plus composed Capacity and S&OP HTTP flows above.
- **Failure paths:** JWT 401, permission 403, Capacity tenant 404, selected seam tests, plus the explicit harness-red Capacity suite.
- **Persistence:** restart persistence and exact Mongo counts captured.
- **Security:** direct-service signed JWTs only; the test secret is confined to the disposable verifier harness and is not a production secret.
- **Migration/rollback:** none.
- **Out-of-scope changes:** none.

## Required next gate

Run one new independent verifier lane with a lane-owned Mongo process at `127.0.0.1:57192`, replica-set name exactly `rsmod192`, and `enableTestCommands=1` before the first Capacity invocation. Require CapacityPlans `36/36`, and perform the S&OP matching-foreign-header visibility check expecting `404`. Do not change source to satisfy either check. CT may then assess acceptance; this report grants none.
