# Independent VER handoff

Use an immutable copy of `/private/tmp/mvp6-integration-baseline-422-01`. Do not verify in the mutable writer checkout and do not treat this writer verdict as independent verification.

1. Require base HEAD `4a8d4d4b339528a88e6220fb8402e5a2c771136c` and [SELECTED-422-MANIFEST.tsv](SELECTED-422-MANIFEST.tsv) SHA-256 `cdc6228aa3d215f34f2f2f9d5b784cf57ac20b6eb8f2c2f26bdcace9dcd4d76c`.
2. Rehash all 422 selected paths. Require Program target `50c48a2b…`, Capacity hosted-test target `2c133ac1…`, and S&OP test target `eba2da6f…`.
3. Require duplicate-name successor absence: `CapacityContractError.cs` must remain `a618a186…`, not `c55ad161…`.
4. Rebuild with native `/Users/natig/.dotnet/dotnet` 8.0.417. Reproduce CapacityPlans 36/36, SandopPlans 19/19 and the 128 selected seam tests from `COMMANDS.md` using fresh lane-owned replica sets.
5. Independently reproduce both HTTP golden chains and process-restart replay. Verify Capacity has exactly one matching terminal audit, one Pending terminal event and zero active slots. Verify S&OP has one snapshot and one sign-off after restart.
6. Confirm Claims normal mode uses `NoOpClaimCommitProbe`, and no ClaimsEvidence product registration, publisher, gateway, UI or shared-permission delta exists.
7. Keep repository tests, composed HTTP, independent VER and excluded E5/G5/rollout verdicts separate.

The writer is complete. Independent VER remains authorized but unexecuted by this lane.

