# Bounded reproduction commands

All commands run from `/private/tmp/mvp6-integration-baseline-422-01`.

```bash
/Users/natig/.dotnet/dotnet build services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-restore -m:1 /nr:false

/Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~CapacityPlans'

MVP6_MOD0190_MONGO_URI='<lane-owned-replica-set>' /Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~SandopPlans'

MOD0183_TEST_MONGO='<lane-owned-replica-set>' MOD0184_TEST_MONGO='<lane-owned-replica-set>' MOD0185_TEST_MONGO='<lane-owned-replica-set>' RETURNS_MONGO_URI='<lane-owned-replica-set>' CLAIMS_TEST_MONGO='<lane-owned-replica-set>' /Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~ShipmentRootHttpTests|FullyQualifiedName~CarrierContractTests|FullyQualifiedName~LoadReferenceTests|FullyQualifiedName~ReturnReferenceTests|FullyQualifiedName~ClaimIsolationTests|FullyQualifiedName~ClaimReferenceTests'
```

The API runs used the same freshly built DLL, a lane-owned replica set, direct-service test JWTs, test-only S&OP DEMAND and Capacity DEMAND/constraint fixtures, and no gateway or publisher.

