# MVP6-INTEGRATION-BASELINE-APPLY-01 — SOP §22

**Writer verdict: PASS for the authorized bounded integration regression; writer-complete. Independent VER remains OPEN.**

## Identity and authority

- Agent Lane: `INT — MVP6 Logistics — selected 422 baseline`.
- Registered checkout: `/private/tmp/mvp6-integration-baseline-422-01`, detached at base HEAD `4a8d4d4b339528a88e6220fb8402e5a2c771136c`.
- Initial porcelain: clean. The shared checkout was not overwritten.
- Authority: the owner's 2026-09-23 decision B authorized the exact transfer, Program and test-only patch chain in `mvp6-integration-baseline-selection-01/INTEGRATION-DISPATCH-v1.0-HELD.md`, including all pinned preimages, targets and scope exclusions. It authorized bounded integration regression and independent VER handoff, but not independent VER by this writer.
- Excluded: gateway, UI, shared permissions, live producer, rollout, E5/G5, pack/status, canonical/guard, duplicate-name successor, commit, push and stash.

## Exact transfer and source manifest

1. Verified the MOD-0190 archive `8fa00d40814a81472ec4221ad909321d058dea18a11f64dd2ac16ea800ecb745` and manifest `ae7ef59e0158113c22389ccd3eec84207418f3a859c40480e70b42ee888a9bef`; all 379 rows matched after extraction.
2. Verified the Capacity archive `753843251ea261473e308e5fb100de834b1e5ab88fa7576ff50ad22bf332274e` and manifest `36114191e1576b8b5654b9910f3347432d5d3bf36aac87339a4280cc85a852f8`; all 43 rows matched and the manifest intersection was zero.
3. Verified `Program.cs` preimage `a2a216be15d07fa656f5fd7da43711aa989c4a8d52cd51c58e8ded48d5d735e5`, applied only patch `78cc0fa61dd37019f525c621c572d1dc2ef518eb0b4faf520a280f01909db82e`, and obtained target `50c48a2b895804162f36740703bca20d3f0c3f96f2511133e843d75fcf7830f0`.
4. Verified `CapacityAtomicityTests.cs` preimage `91999330faf2a50f5ff2cda3595506ecded50d5b87ffb7bf393dd655f71e51db`, applied only patch `b6744cddfd498536abeb4b350d8b8b2bd1c30c0824875757522026ed5f01df81`, and obtained target `2c133ac1b6b431db074b0054b0337bbc3957fce5869c7aca9291454a53681c43`.
5. `SandopAtomicityTests.cs` remained at accepted target `eba2da6f47a4935b61857a95534b3d1697635910190e3838494d96d956af7f43`.
6. [SELECTED-422-MANIFEST.tsv](SELECTED-422-MANIFEST.tsv) has one header plus 422 byte-sorted rows, 74,155 bytes, SHA-256 `cdc6228aa3d215f34f2f2f9d5b784cf57ac20b6eb8f2c2f26bdcace9dcd4d76c`. All 422 paths rehashed successfully both before and after tests.

The selected source creates 267 working-tree deltas relative to base HEAD: five tracked modifications and 262 additions. The other 155 selected paths were already byte-identical at base. The audit handoff files in this directory are evidence outputs and are outside the 422-source manifest.

## Exclusion assertions

- The duplicate-name successor patch remained unapplied. Its SHA-256 is `f4fc82b44eb237d1dbc8bdd9c0d9633c948ca4e33cd2dcff91cd65f653780c8f`. `CapacityContractError.cs` remains at pre-successor SHA-256 `a618a18674859d8e23b032576e022c0544dc0f5e219aa978dd48fe0715b5b591`, rather than successor target `c55ad1616576bf73c062e16a8e745bd15e652c9ff4cf1ef575fc59b123c9cd7e`.
- Normal Claims registers `IClaimCommitProbe` as `NoOpClaimCommitProbe`; no ClaimsEvidence product registration appears in `Program.cs` or Claims persistence registration.
- No gateway, UI, shared permission, pack, guard, contract, live producer or publisher source was added by this writer.

## Fresh validation

The controlling runtime is native .NET SDK `8.0.417` with ASP.NET Core `8.0.23`.

| Gate | Result |
|---|---|
| Fresh restore | PASS; all SupplyChain test-project dependencies restored. |
| Native .NET 8 build | PASS; 0 warnings, 0 errors. |
| CapacityPlans | **36/36 PASS**, including X01, all five later-read X07 cases and separate-process restart. TRX SHA-256 is recorded in `SHA256SUMS`. |
| SandopPlans | **19/19 PASS**, including the accepted committed-ack oracle. |
| Selected cross-module seams | **128/128 PASS**: Shipment root HTTP, Carrier contract, Load reference, Returns R01/reference and Claims strict-header/reference groups. |
| Capacity composed HTTP | PASS: 401 unauthenticated, 403 permission denial, 404 foreign tenant, plan/scenario/evaluation create and replay, changed-payload 409, terminal read, one Pending terminal event, one terminal audit and active-slot release. |
| Capacity restart | PASS: restarted process read the persisted plan and terminal evaluation and replayed the original Accepted receipt without creating a second evaluation. |
| S&OP composed HTTP | PASS: create, same-key replay, 403 permission denial, 404 foreign tenant, capture/replay/list, sign-off/replay/list. |
| S&OP restart | PASS: restarted process read `InReview`, returned the original Draft create receipt for the same key, and listed the one persisted snapshot and sign-off. |

The API DLL SHA-256 was `44682180b0b17eacab25c1f5bf8f94e27eae8c16465a84022b45aaf20ffa7147`; the controlling test DLL SHA-256 was `4f6777ae544642cfa5406189a218ef03171914ba19469c94649d2268c15bbb51`. The observed API process started after the API DLL timestamp, satisfying the runtime-freshness gate. Lane-owned API port `56922` and Mongo port `57900` were stopped after capture.

## Diagnostic runs retained separately

The first sandboxed VSTest attempt aborted because the sandbox denied its loopback socket. A system-.NET-10 diagnostic then produced Capacity 35/36 and selected seams 90/128; the seam failures were the ASP.NET 8 TestHost incompatibility `ResponseBodyPipeWriter does not implement PipeWriter.UnflushedBytes`, and the restart test also failed under that non-controlling runtime. These are not relabeled as passing. Native .NET 8 rebuilt the same source and produced the controlling green results above.

## SOP §22 fields

- **Agent verdict:** PASS for the authorized integration-owner scope; writer-complete.
- **Branch / HEAD:** detached / `4a8d4d4b339528a88e6220fb8402e5a2c771136c`.
- **Worktree:** `/private/tmp/mvp6-integration-baseline-422-01`; selected source and this evidence directory are intentionally uncommitted.
- **Changed files:** exact 422 selected source paths plus this new audit handoff directory. Actual source delta relative to HEAD is five modified and 262 added; 155 selected paths are identical to HEAD.
- **Golden/contract flow:** S&OP and Capacity flows above; test-only DEMAND/constraint fixtures only.
- **Failure paths:** permission, tenant isolation, idempotency conflict, Returns malformed producer mapping, Claims strict UTF-8/header and root mismatch, X01 and five later-read X07 cases.
- **Persistence:** real local replica sets, persisted replay after restart, Pending-only outbox and released Capacity active slot.
- **Security:** direct-service JWT only; no bearer or signing secret is stored in this package.
- **Observability:** response correlation and persisted audit/outbox were observed; no gateway claim.
- **Migration / rollback:** no migration. Rollback is removal of the 267 source deltas from this isolated checkout only; no rollback action was taken.
- **Blockers:** none for writer completion. Independent VER and CT acceptance remain open.
- **Known gaps:** E5/G5, gateway/UI, live publisher/producer, rollout and full-module acceptance remain outside authority.
- **Out-of-scope changes:** none.

