# Hash bindings

## Exact 422-row source

- Manifest: `cdc6228aa3d215f34f2f2f9d5b784cf57ac20b6eb8f2c2f26bdcace9dcd4d76c`
- Pre-run snapshot rehash: 422 rows, zero mismatches.
- Post-run snapshot rehash: 422 rows, zero mismatches.
- Program.cs: `50c48a2b895804162f36740703bca20d3f0c3f96f2511133e843d75fcf7830f0`
- CapacityAtomicityTests.cs: `2c133ac1b6b431db074b0054b0337bbc3957fce5869c7aca9291454a53681c43`
- SandopAtomicityTests.cs: `eba2da6f47a4935b61857a95534b3d1697635910190e3838494d96d956af7f43`

## Recovery evidence

- Capacity TRX: `584dc72d2310e57c095a68311f98848598a2dc072fd3ca0812658afa7a58ea8c`
- S&OP foreign-scope HTTP JSON: `5de42471739e051025596cc79be0f3bdd709c71828d1a869dd8d8164e2ef9fac`
- S&OP API log: `d13e7dff73b17bd267bb882180b76bdaf39bf0d5c3f83cabb7a6a41cb3a7b674`
- HTTP harness: `b14da3e697461f3b84dd54c3d136632ba2b011dc0e15651ac314575b8c840352`
- Existing test assembly used without rebuild: `4f6777ae544642cfa5406189a218ef03171914ba19469c94649d2268c15bbb51`
- Existing API assembly used without rebuild: `44682180b0b17eacab25c1f5bf8f94e27eae8c16465a84022b45aaf20ffa7147`

## Prior green evidence, rebound read-only

- Prior PARTIAL SOP §22 report: `6f3ff3bfd7184b4403d0a0774b6525794924f0869e5a994bbb87948c1fe10009`
- Prior composed HTTP/restart JSON: `d5b52fbabdfb132270ea4953b596023f8e951cb0f2d9dcdf6a46259ff2d7f923`
- Prior first API log: `df1f00cd90090b0fbd1adfa39d107f242295d98d1414f13f1d87512e6a4b462f`
- Prior restart API log: `a8f85ed7a1ed55c01aae8df5da52d4fa9eb5ff6b3300c2cc6ec4597cd3285d99`
- Prior green S&OP TRX: `c77e27f3e18aec10f566eb83e3cbff7ac67b2ee37e58a035a711ee4b75b502ef`
- Prior command record: `43b26f7a7ead6a2ad7c999ca2bfe11f9c2f43b2a8b5e39a4deb672f089abdf5b`
- Prior cleanup record: `aca1c333979500d2fda8a6c8b52634efa991095950cae8cb5522ba6b222c62a1`

The prior fresh-build and green HTTP/restart results are incorporated by these immutable hashes. This recovery did not repeat those closed gates.
