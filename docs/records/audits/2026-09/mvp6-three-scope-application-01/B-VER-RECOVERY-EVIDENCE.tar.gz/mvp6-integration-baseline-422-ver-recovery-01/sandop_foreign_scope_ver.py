#!/usr/bin/env python3
import base64
import hashlib
import hmac
import json
import os
import pathlib
import subprocess
import time
import urllib.error
import urllib.request
import uuid

SNAP = pathlib.Path("/private/tmp/mvp6-integration-baseline-422-ver-recovery-snapshot-01")
RAW = pathlib.Path("/private/tmp/mvp6-integration-baseline-422-ver-recovery-01/raw")
DLL = SNAP / "services/Diten.SupplyChainService/src/Diten.SupplyChainService.Api/bin/Debug/net8.0/Diten.SupplyChainService.Api.dll"
DOTNET = "/Users/natig/.dotnet/dotnet"
BASE = "http://127.0.0.1:56943"
MONGO = "mongodb://127.0.0.1:57192/?replicaSet=rsmod192&serverSelectionTimeoutMS=5000"
DB = "DitenSupplyChain_Ver422_Recovery"
SECRET = "independent-ver-recovery-only-secret-422-abcdefghijklmnopqrstuvwxyz"
ISSUER = "mvp6-ver-recovery"
AUDIENCE = "mvp6-ver-recovery-api"
OWNER_TENANT = "19200000-0000-4000-8000-000000000001"
OWNER_LE = "19200000-0000-4000-8000-000000000002"
FOREIGN_TENANT = "19200000-0000-4000-8000-000000000099"
FOREIGN_LE = "19200000-0000-4000-8000-000000000098"
ACTOR = "19200000-0000-4000-8000-000000000003"
PERMISSIONS = ["supplychain.sandop-plans.read", "supplychain.sandop-plans.create"]


def b64(value):
    return base64.urlsafe_b64encode(value).rstrip(b"=")


def token(tenant, legal_entity):
    header = b64(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = b64(json.dumps({
        "sub": ACTOR,
        "tenant_id": tenant,
        "legal_entity_id": legal_entity,
        "permission": PERMISSIONS,
        "iss": ISSUER,
        "aud": AUDIENCE,
        "exp": int(time.time()) + 3600,
    }, separators=(",", ":")).encode())
    signature = b64(hmac.new(SECRET.encode(), header + b"." + payload, hashlib.sha256).digest())
    return b".".join((header, payload, signature)).decode()


def request(method, path, jwt, tenant, legal_entity, body=None, key=None):
    headers = {
        "Authorization": "Bearer " + jwt,
        "X-Correlation-Id": str(uuid.uuid4()),
        "X-Tenant-Id": tenant,
        "X-Legal-Entity-Id": legal_entity,
    }
    if body is not None:
        headers["Content-Type"] = "application/json"
    if key:
        headers["Idempotency-Key"] = key
    req = urllib.request.Request(
        BASE + path,
        data=None if body is None else json.dumps(body, separators=(",", ":")).encode(),
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read()
            return response.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as error:
        raw = error.read()
        return error.code, json.loads(raw) if raw else None


def drop_database():
    subprocess.run(
        ["mongosh", "--quiet", MONGO, "--eval", f'db.getSiblingDB("{DB}").dropDatabase()'],
        check=True,
        capture_output=True,
        text=True,
    )


drop_database()
environment = os.environ.copy()
environment.update({
    "ASPNETCORE_ENVIRONMENT": "Testing",
    "ASPNETCORE_URLS": BASE,
    "Mongo__ConnectionString": MONGO,
    "Mongo__DatabaseName": DB,
    "JwtSettings__Secret": SECRET,
    "JwtSettings__Issuer": ISSUER,
    "JwtSettings__Audience": AUDIENCE,
    "Sandop__DemandFixtures__0__TenantId": OWNER_TENANT,
    "Sandop__DemandFixtures__0__LegalEntityId": OWNER_LE,
    "Sandop__DemandFixtures__0__PlanId": "dp-ver-recovery",
    "Sandop__DemandFixtures__0__Version": "1",
    "Sandop__DemandFixtures__0__Checksum": "sha256:ver-recovery",
    "Sandop__DemandFixtures__0__Published": "true",
})
log = open(RAW / "sandop-foreign-scope-api.log", "wb")
process = subprocess.Popen([DOTNET, str(DLL)], cwd=SNAP, env=environment, stdout=log, stderr=subprocess.STDOUT)
result = {
    "apiDllSha256": hashlib.sha256(DLL.read_bytes()).hexdigest(),
    "connectionString": MONGO,
    "foreignTokenScope": {"tenantId": FOREIGN_TENANT, "legalEntityId": FOREIGN_LE},
    "foreignHeaderScope": {"tenantId": FOREIGN_TENANT, "legalEntityId": FOREIGN_LE},
}
try:
    for _ in range(100):
        try:
            with urllib.request.urlopen(BASE + "/health", timeout=0.5) as response:
                if response.status == 200:
                    break
        except Exception:
            time.sleep(0.1)
    else:
        raise RuntimeError("API did not become ready")

    owner_jwt = token(OWNER_TENANT, OWNER_LE)
    create_status, create_body = request(
        "POST",
        "/api/supply-chain/sandop-plans",
        owner_jwt,
        OWNER_TENANT,
        OWNER_LE,
        {
            "name": "S&OP foreign-scope VER",
            "horizonStart": "2027-01-01",
            "horizonEnd": "2027-12-31",
            "demandPlanId": "dp-ver-recovery",
            "demandPlanVersion": "1",
        },
        "sandop-ver-recovery-create",
    )
    if create_status != 201:
        raise RuntimeError(f"owner create returned {create_status}: {create_body}")
    plan_id = create_body["sandopPlanId"]
    foreign_status, foreign_body = request(
        "GET",
        f"/api/supply-chain/sandop-plans/{plan_id}",
        token(FOREIGN_TENANT, FOREIGN_LE),
        FOREIGN_TENANT,
        FOREIGN_LE,
    )
    result.update({
        "ownerCreateStatus": create_status,
        "sandopPlanId": plan_id,
        "foreignReadStatus": foreign_status,
        "foreignReadBody": foreign_body,
        "expectedStatus": 404,
        "passed": foreign_status == 404,
    })
    if foreign_status != 404:
        raise RuntimeError(f"foreign-scope read returned {foreign_status}: {foreign_body}")
finally:
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
    log.close()
    drop_database()

(RAW / "SANDOP-FOREIGN-SCOPE-HTTP.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, indent=2, sort_keys=True))
