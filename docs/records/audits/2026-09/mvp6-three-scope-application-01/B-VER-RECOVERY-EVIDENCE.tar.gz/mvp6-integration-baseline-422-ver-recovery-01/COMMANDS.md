# Independent VER recovery commands

The writer checkout remained read-only. Commands ran from the disposable snapshot unless stated otherwise.

```bash
mongod --dbpath /private/tmp/mvp6-integration-baseline-422-ver-recovery-mongo-01 --port 57192 --replSet rsmod192 --bind_ip 127.0.0.1 --nounixsocket --setParameter enableTestCommands=1
mongosh --quiet --host 127.0.0.1 --port 57192 --eval 'rs.initiate({_id:"rsmod192",members:[{_id:0,host:"127.0.0.1:57192"}]})'
mongosh --quiet 'mongodb://127.0.0.1:57192/?replicaSet=rsmod192&serverSelectionTimeoutMS=5000' --eval 'db.hello()'

/Users/natig/.dotnet/dotnet test services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj -c Debug --no-build --no-restore --filter 'FullyQualifiedName~CapacityPlans' --logger 'trx;LogFileName=capacity-plans-ver-recovery.trx' --results-directory /private/tmp/mvp6-integration-baseline-422-ver-recovery-01/raw

PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/mvp6-integration-baseline-422-ver-recovery-01/sandop_foreign_scope_ver.py
```

No restore, build, static gate, S&OP suite, seam suite, CT action, commit, push, or stash command was run.
