# MVP6-INTEGRATION-BASELINE-422-INDEPENDENT-VER-RECOVERY-01 — SOP §22 VER

**Verification verdict: PASS for the bounded independent VER recovery.** Both gaps recorded by the predecessor PARTIAL report are **CLOSED**. CapacityPlans passed 36/36 against the exact source-pinned Mongo fixture, and the S&OP matching-foreign-scope HTTP read reached repository isolation and returned the required `404 UNKNOWN_SANDOP_PLAN`. This report grants no CT acceptance.

## Identity and boundary

- Independent verifier recovery lane; no writer action was used as verification.
- Writer checkout, read-only: `/private/tmp/mvp6-integration-baseline-422-01`.
- Disposable snapshot: `/private/tmp/mvp6-integration-baseline-422-ver-recovery-snapshot-01`.
- Base HEAD: `4a8d4d4b339528a88e6220fb8402e5a2c771136c`.
- Manifest: 422 rows, SHA-256 `cdc6228aa3d215f34f2f2f9d5b784cf57ac20b6eb8f2c2f26bdcace9dcd4d76c`.
- Pre-run and post-run rehash: zero mismatches across all 422 selected paths.
- Excluded and untouched: CT acceptance, gateway/UI, shared permissions, live producer/publisher/Event Bus, rollout, E5/G5, pack/status, canonical/guard, Capacity successor uptake, commit, push, and stash.

## Gap 1 — CapacityPlans controlling suite

**CLOSED.** A lane-owned MongoDB 8.0.18 process was started with:

- port `57192`;
- replica-set name exactly `rsmod192`;
- `enableTestCommands=1`;
- exact fixture URI `mongodb://127.0.0.1:57192/?replicaSet=rsmod192&serverSelectionTimeoutMS=5000`.

Before testing, `db.hello()` proved `isWritablePrimary=true`, `setName=rsmod192`, and primary `127.0.0.1:57192`. The affected controlling suite was invoked exactly once with `--no-build --no-restore`.

- Result: **36 passed, 0 failed, 0 skipped**.
- Duration: 2m 8s.
- TRX: `raw/capacity-plans-ver-recovery.trx`.
- TRX SHA-256: `584dc72d2310e57c095a68311f98848598a2dc072fd3ca0812658afa7a58ea8c`.

## Gap 2 — S&OP foreign-scope HTTP contract

**CLOSED.** The narrow runtime harness created one owner-scope S&OP plan, then performed only the open foreign read case:

- owner create: `201`;
- foreign JWT tenant: `19200000-0000-4000-8000-000000000099`;
- foreign JWT legal entity: `19200000-0000-4000-8000-000000000098`;
- request `X-Tenant-Id` and `X-Legal-Entity-Id`: exact matches to those foreign claims;
- foreign read: **`404 UNKNOWN_SANDOP_PLAN`**.

The matching headers prove the request passed the signed-context/header equality gate. The returned plan-not-found contract proves repository scope isolation without disclosing the owner plan. Evidence: `raw/SANDOP-FOREIGN-SCOPE-HTTP.json`, SHA-256 `5de42471739e051025596cc79be0f3bdd709c71828d1a869dd8d8164e2ef9fac`.

## Prior green gates rebound by hash

The predecessor lane's closed fresh build, S&OP regression, selected seams, and Capacity/S&OP HTTP restart-persistence flow were not rerun. They are rebound through:

- predecessor report: `6f3ff3bfd7184b4403d0a0774b6525794924f0869e5a994bbb87948c1fe10009`;
- composed HTTP/restart JSON: `d5b52fbabdfb132270ea4953b596023f8e951cb0f2d9dcdf6a46259ff2d7f923`;
- first/restart API logs: `df1f00cd90090b0fbd1adfa39d107f242295d98d1414f13f1d87512e6a4b462f` / `a8f85ed7a1ed55c01aae8df5da52d4fa9eb5ff6b3300c2cc6ec4597cd3285d99`;
- prior green S&OP TRX: `c77e27f3e18aec10f566eb83e3cbff7ac67b2ee37e58a035a711ee4b75b502ef`.

See `HASH-BINDINGS.md` for the complete binding set.

## SOP §22 fields

- **Agent verdict:** writer claimed PASS / writer-complete.
- **Predecessor VER verdict:** PARTIAL / fail-closed with two explicit gaps.
- **Recovery VER verdict:** PASS for the bounded independent verification; both predecessor gaps CLOSED.
- **CT status:** unchanged; no CT acceptance issued.
- **Changed files:** no writer/common source files; only this standalone `/private/tmp` evidence package.
- **Golden/contract flow:** exact 422-row source, CapacityPlans 36/36, S&OP matching-foreign-scope 404, and prior green HTTP/restart evidence by hash.
- **Failure paths:** X01/X07 and all Capacity failure-path tests included in the 36/36 controlling suite; foreign-scope S&OP read returned 404.
- **Persistence:** prior green restart evidence rebound by hash; no duplicate restart run.
- **Security:** valid signed JWT with claim/header equality; test secret stayed inside the disposable verifier harness.
- **Migration/rollback:** none.
- **Out-of-scope changes:** none.

## Handoff

The independent VER gaps are closed. CT may assess acceptance separately; this report does not grant it.

## Cleanup

- The temporary API exited after the HTTP assertion.
- The lane-owned Mongo process exited cleanly.
- No listener remained on ports `56943` or `57192`.
- The disposable snapshot and Mongo data directory were removed.
- The writer checkout still rehashed at 422 rows with zero mismatches after cleanup.
