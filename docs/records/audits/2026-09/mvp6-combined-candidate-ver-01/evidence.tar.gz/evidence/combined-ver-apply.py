from pathlib import Path
import json,hashlib,tarfile,subprocess,shutil,yaml,copy
w=Path(Path('/private/tmp/combined-ver-current.txt').read_text());a=w/'author/evidence';raw=w/'raw';repo=Path.cwd();H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();checks=[]
for line in (a/'MANIFEST.sha256').read_text().splitlines():h,p=line.split('  ',1);assert H(a/p)==h,p
pins=json.loads((a/'input-pins.json').read_text());ars={}
for x in pins:
 if x['type']=='ARCHIVE':assert H(repo/x['path_or_member'])==x['sha256'];ars[x['module']]=repo/x['path_or_member']
 else:
  with tarfile.open(ars[x['module']]) as t:data=t.extractfile(x['path_or_member']).read()
  assert hashlib.sha256(data).hexdigest()==x['sha256'];assert (a/'inputs'/x['module']/x['path_or_member']).read_bytes()==data
base=a/'inputs/root/r2pack/baseline-2.0.0.yaml';original={'root':a/'inputs/root/r2pack/root-r2.patch','returns':a/'inputs/returns/returns-r2/candidate.patch','claims':a/'inputs/claims/claims-r2/candidate.patch'}
expected='d763b571a1c6b88cbfadc56af2c51da1c0009589e3b82bcbe122329b17213c88';events=[]
def apply(target,patch,label):
 cmd=['patch','--batch','--fuzz=0',str(target),str(patch)];p=subprocess.run(cmd,cwd=target.parent,capture_output=True,text=True);events.append({'label':label,'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'resultSha256':H(target)});return p.returncode
for suffix,order in [('rc',['root','returns','claims']),('cr',['root','claims','returns'])]:
 d=w/('original-'+suffix);d.mkdir();f=d/'candidate.yaml';shutil.copyfile(base,f)
 for i,m in enumerate(order):rc=apply(f,original[m],'original-'+suffix+'-'+m);assert (rc==0)==(i<2)
 d=w/('rebased-'+suffix);d.mkdir();f=d/'candidate.yaml';shutil.copyfile(base,f);assert apply(f,original['root'],'rebased-'+suffix+'-root')==0
 for m in order[1:]:assert apply(f,a/('rebased-'+'-'.join(order))/(m+'-context-rebased.patch'),'rebased-'+suffix+'-'+m)==0
 assert H(f)==expected
assert (w/'rebased-rc/candidate.yaml').read_bytes()==(w/'rebased-cr/candidate.yaml').read_bytes()
d=w/'single';d.mkdir();f=d/'candidate.yaml';shutil.copyfile(base,f);assert apply(f,a/'candidate/combined.patch','single-exact-combined')==0;assert H(f)==expected
# Independently derive expected union by AST ownership; reject any other field change.
b=yaml.safe_load(base.read_text());d=yaml.safe_load(f.read_text());sources={k:yaml.safe_load((a/p).read_text()) for k,p in {'root':'inputs/root/r2pack/shipment-bundle-2.0.0-root-r2-candidate.yaml','returns':'inputs/returns/returns-r2/shipment-bundle.returns-r2.yaml','claims':'inputs/claims/claims-r2/claims-r2.openapi.yaml'}.items()}
u=copy.deepcopy(sources['root']);owned=['/returns','/returns/{returnId}/transition','/claims','/claims/{claimId}/transition']
for p in owned:u['paths'][p]=sources['returns' if p.startswith('/returns') else 'claims']['paths'][p]
assert d==u
# Verify consumer whole-document delta never extends beyond their path blocks.
for m in ['returns','claims']:
 x=copy.deepcopy(b)
 for p in owned:
  if p.startswith('/'+m):x['paths'][p]=sources[m]['paths'][p]
 assert x==sources[m]
nonowned=[p for p in b['paths'] if p not in owned and p!='/shipments/{shipmentId}'];assert all(d['paths'][p]==b['paths'][p] for p in nonowned)
assert d['components']==sources['root']['components'];assert d['webhooks']==b['webhooks'];assert d['info']['version']=='2.0.0' and d['info']['x-status']=='CANDIDATE'
# Byte-block equivalence independently matches original consumer operation text, not only AST.
def block(text,m):
 start=text.index('  /'+m+':\n');end=text.index('  /claims:\n',start) if m=='returns' else text.index('webhooks:\n',start);return text[start:end]
for m,p in [('returns','inputs/returns/returns-r2/shipment-bundle.returns-r2.yaml'),('claims','inputs/claims/claims-r2/claims-r2.openapi.yaml')]:assert block(f.read_text(),m)==block((a/p).read_text(),m)
(raw/'application-results.json').write_text(json.dumps(events,indent=2));(raw/'ownership-results.json').write_text(json.dumps({'verdict':'PASS','nonownedPaths':nonowned,'ownedPaths':owned,'wholeDocumentExactUnion':True,'consumerOperationBytesExact':True,'rootComponentsExact':True,'webhooksUnchanged':True,'finalSha256':H(f)},indent=2));print('PASS original third-patch textual conflicts reproduced; both rebased orders and exact combined patch yield',H(f))
