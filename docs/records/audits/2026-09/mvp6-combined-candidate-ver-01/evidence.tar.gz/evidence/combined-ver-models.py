from pathlib import Path
import json,hashlib,subprocess,shutil,yaml
w=Path(Path('/private/tmp/combined-ver-current.txt').read_text());a=w/'author/evidence';raw=w/'raw';r=w/'models/returns/returns-r2-uuid-rework-pack';cl=w/'models/claims/claims-stateful-rework';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
for line in (r/'SHA256SUMS').read_text().splitlines():h,p=line.split('  ',1);assert H(r/p)==h
for p,h in json.loads((cl/'manifest.json').read_text())['files'].items():assert H(cl/p)==h,p
for name,path,expected in [('returns','docs/records/audits/2026-09/mvp6-returns-r2-uuid-rework-01/returns-r2-uuid-rework-01-evidence.tar.gz','e4a5e5c80fe3b306898abe50d632525f94794765e07d927b4dbbf52644d78eb9'),('claims','docs/records/audits/2026-09/mvp6-claims-r2-stateful-rework-01/claims-stateful-rework.tar.gz','bd533a4da51657e0e6eb6736e07e603bdf849dda82dd85a99ed0b715c489da60')]:assert H(Path(path))==expected
v=w/'fresh-author-check';shutil.copytree(a,v);shutil.copy2(w/'single/candidate.yaml',v/'candidate/shipment-bundle-combined-candidate.yaml')
for order,suffix in [('root-returns-claims','rc'),('root-claims-returns','cr')]:shutil.copy2(w/('rebased-'+suffix)/'candidate.yaml',v/('rebased-'+order)/'combined.yaml')
ret=w/'fresh-returns';shutil.copytree(a/'inputs/returns/returns-r2',ret);shutil.copy2(r/'returns_model.reworked.py',ret/'returns_model.py')
# Original standalone harness executes unchanged with accepted successor model; exact combined operation equality established separately.
for name,script in [('combined-refs-examples',v/'verify_combined.py'),('returns-model-schema',ret/'verify_r2.py'),('claims-stateful',cl/'test_stateful.py'),('claims-mutants',cl/'mutation_checks.py')]:
 p=subprocess.run(['python3',str(script)],cwd=script.parent,capture_output=True,text=True);(raw/(name+'.log')).write_text(p.stdout+p.stderr);results.append({'name':name,'command':['python3',str(script)],'exit':p.returncode,'stdout':p.stdout});assert p.returncode==0,results[-1]
(raw/'fresh-model-command-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
