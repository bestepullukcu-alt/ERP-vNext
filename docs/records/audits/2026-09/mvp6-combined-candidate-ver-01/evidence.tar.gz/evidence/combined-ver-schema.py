from pathlib import Path
import sys,json,hashlib,copy,traceback
w=Path(Path('/private/tmp/combined-ver-current.txt').read_text());sys.path.insert(0,str(w/'tooldeps'))
import yaml,openapi_spec_validator
from openapi_spec_validator import OpenAPIV31SpecValidator
from openapi_spec_validator.schemas.utils import get_schema_content
schema_v31=get_schema_content("3.1")
from jsonschema import Draft202012Validator
p=w/'single/candidate.yaml';d=yaml.safe_load(p.read_text());errors=list(OpenAPIV31SpecValidator(d).iter_errors());raw=w/'raw'
(raw/'openapi31-results.json').write_text(json.dumps({'validatorVersion':openapi_spec_validator.__version__,'yamlSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'schemaId':schema_v31.get('$id'),'schemaSha256':hashlib.sha256(json.dumps(schema_v31,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'errors':[{'path':list(x.absolute_path),'message':x.message} for x in errors]},indent=2));(raw/'openapi31-metaschema.json').write_text(json.dumps(schema_v31,indent=2));print('full OpenAPI3.1 errors',len(errors))
for e in errors:print(list(e.absolute_path),e.message[:900])
mutants=[]
for name,edit in [('bad-openapi-version',lambda x:x.update(openapi='2.0')),('missing-info-title',lambda x:x['info'].pop('title')),('invalid-response-object',lambda x:x['paths']['/returns']['post']['responses'].update({'201':{'description':14}}))]:
 x=copy.deepcopy(d);edit(x);errs=list(OpenAPIV31SpecValidator(x).iter_errors());mutants.append({'name':name,'rejected':bool(errs),'firstError':errs[0].message if errs else None})
(raw/'metaschema-negative-controls.json').write_text(json.dumps(mutants,indent=2));assert all(x['rejected'] for x in mutants)
assert not errors
