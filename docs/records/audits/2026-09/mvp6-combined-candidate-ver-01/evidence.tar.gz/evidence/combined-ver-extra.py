from pathlib import Path
import json,yaml,copy,re,importlib.util,hashlib
from jsonschema import Draft202012Validator,RefResolver,FormatChecker
w=Path(Path('/private/tmp/combined-ver-current.txt').read_text());d=yaml.safe_load((w/'single/candidate.yaml').read_text());b=yaml.safe_load((w/'author/evidence/inputs/root/r2pack/baseline-2.0.0.yaml').read_text());rows=[]
def ck(name,ok):rows.append({'name':name,'pass':bool(ok)});assert ok,name
def load(name,path):s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
ret=load('ret',w/'fresh-returns/returns_model.py');cl=load('cl',w/'models/claims/claims-stateful-rework/stateful_model.py')
policy=json.loads(d['paths']['/claims']['post']['description'].split('\n')[1]);ck('Claims executable model policy equals combined inline policy',cl.POLICY==policy)
validator=Draft202012Validator(d['components']['schemas']['ShipmentDetail'],resolver=RefResolver.from_schema(d),format_checker=FormatChecker());example=d['paths']['/shipments/{shipmentId}']['get']['responses']['200']['content']['application/json']['example']
for name,value,valid in [('null',None,True),('nil','00000000-0000-0000-0000-000000000000',True),('upper','ABCDEFAB-1234-4ABC-8DEF-ABCDEFABCDEF',True),('bad','not-a-uuid',False),('number',1,False),('empty','',False)]:
 x=copy.deepcopy(example);x['lifecycleCorrelationId']=value;ck('combined root '+name,validator.is_valid(x)==valid)
x=copy.deepcopy(example);x.pop('lifecycleCorrelationId');ck('combined root missing optional',validator.is_valid(x))
# Observe actual model transitions for every canonical pair, including invalid-state no-write behavior.
root='abcdefab-1234-4abc-8def-abcdefabcdef';scope=('t','le');src={'root':root,'status':'Delivered','lines':{'1':{'quantity':'10','uomId':'EA'}}};body={'shipmentId':root,'lines':[{'shipmentLineNumber':'1','quantity':'1','uomId':'EA'}]}
for module,model,statusname in [('returns',ret,'ReturnStatus'),('claims',cl,'ClaimStatus')]:
 desc=b['paths']['/'+module+'/{'+('returnId' if module=='returns' else 'claimId')+'}/transition']['post']['description'];edges={(s,t) for s,ts in re.findall(r'(\w+)->([\w|]+)',desc) for t in ts.split('|')};states=b['components']['schemas'][statusname]['enum']
 for fr in states:
  for to in states:
   store=model.Store()
   if module=='returns':
    store.mutate(scope,'a',body,root,source=src,grants={'create'});store.records[(*scope,'a')]['state']=fr;before=copy.deepcopy(store.__dict__)
    result=store.mutate(scope,'transition',{'targetStatus':to,'occurredAt':'2026-09-20T00:00:00Z','dispositionCode':'ok'},root,target='a',grants={'transition',*model.GRANTS.values()});status=result[0];unchanged=store.__dict__==before
   else:
    create=store.command('t','le','create',None,'a',root,{'shipmentId':root,'claimedAmount':'1','currency':'USD'},grants={'create'});aid=create['claimId'];store.aggregates[('t','le',aid)]['status']=fr;before=store.state()
    result=store.command('t','le','transition',aid,'tr',root,{'targetStatus':to,'occurredAt':'2026-09-20T00:00:00Z','approvedAmount':'0','resolutionCode':'ok'},grants=set(policy['permissions'].values()));status=result['status'];unchanged=store.state()==before
   allowed=(fr,to) in edges;ck(module+' actual transition '+fr+'->'+to,status==(200 if allowed else 422) and (allowed or unchanged))
# Successor Returns UUID behavior, plus deliberately break comparator to ensure same oracle fails.
def uuid_probe():
 s=ret.Store();a=s.mutate(scope,'a',body,root,source=src,grants={'create'});replay=s.mutate(scope,'a',body,root.upper(),source=src,grants={'create'});return a==(201,None) and replay==(201,'REPLAY')
ck('Returns successor UUID replay',uuid_probe());old=ret.same_root;ret.same_root=lambda a,b:a==b
try:ck('Returns lexical comparator mutant caught',not uuid_probe())
finally:ret.same_root=old
# Combined-specific semantics mutations must violate exact source-union oracle.
def union_ok(candidate):
 expected=copy.deepcopy(yaml.safe_load((w/'author/evidence/inputs/root/r2pack/shipment-bundle-2.0.0-root-r2-candidate.yaml').read_text()))
 for module,filename in [('returns','shipment-bundle.returns-r2.yaml'),('claims','claims-r2.openapi.yaml')]:
  original=yaml.safe_load((w/'author/evidence/inputs'/module/(module+'-r2')/filename).read_text())
  for p in original['paths']:
   if p=='/'+module or p.startswith('/'+module+'/'):expected['paths'][p]=original['paths'][p]
 return candidate==expected
for name,edit in [('root-required',lambda x:x['components']['schemas']['ShipmentDetail']['allOf'][1]['required'].append('lifecycleCorrelationId')),('claims-conflict-code',lambda x:x['paths']['/claims']['post'].update(description=x['paths']['/claims']['post']['description'].replace('IDEMPOTENCY_KEY_REUSED','CLAIM_REPLAY_CONFLICT'))),('shared-decimal',lambda x:x['components']['schemas']['Decimal'].update(type='number'))]:
 mutant=copy.deepcopy(d);edit(mutant);ck('combined mutant rejected '+name,not union_ok(mutant))
(w/'raw/independent-extra-results.json').write_text(json.dumps(rows,indent=2));print('PASS',len(rows),'independent checks including113 actual model transitions; no runtime claims')
