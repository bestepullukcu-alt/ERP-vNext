#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1
U="mongodb://127.0.0.1:57192/?replicaSet=rsmod192"
export CLAIMS_TEST_MONGO=$U MOD0183_TEST_MONGO=$U MOD0184_TEST_MONGO=$U MOD0185_TEST_MONGO=$U MVP6_MOD0190_MONGO_URI=$U RETURNS_MONGO_URI=$U
L=~/mvp6-env/q119/logs/test; mkdir -p $L; S=$L/TEST-SUMMARY.tsv; printf "tree\tsuite\tfilter\texit\tsummary\n" > $S
SC=services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj
t() { tree=$1; n=$2; proj=$3; filt=$4; shift 4; cd ~/mvp6-env/q119/$tree
  if [ -n "$filt" ]; then dotnet test $proj --no-build --disable-build-servers --filter "$filt" --results-directory $L --logger "trx;LogFileName=$tree--$n.trx" "$@" > $L/$tree--$n.log 2>&1
  else dotnet test $proj --no-build --disable-build-servers --results-directory $L --logger "trx;LogFileName=$tree--$n.trx" "$@" > $L/$tree--$n.log 2>&1; fi; rc=$?
  printf "%s\t%s\t%s\t%s\t%s\n" $tree $n "${filt:--}" $rc "$(grep -E '(Passed|Failed)!' $L/$tree--$n.log | tail -1 | sed 's/^ *//')" >> $S; }
N=Diten.SupplyChainService.Tests
# V5 first (negative control, then fixed), order logged
Q119_ORDER_LOG=$L/ORDER-build-base-ordered.txt t build-base-ordered supplychain-single-capacity-first $SC ""
Q119_ORDER_LOG=$L/ORDER-build-fix-ordered.txt t build-fix-ordered supplychain-single-capacity-first $SC ""
# V4
t build-fix supplychain-single $SC ""
t build-fix supplychain-single-serial $SC "" -- xUnit.ParallelizeTestCollections=false
t build-fix split-shipments-root $SC "FullyQualifiedName~$N.Shipment|FullyQualifiedName~$N.SourceIntake|FullyQualifiedName~$N.SourceClient"
for m in Carriers Loads Returns Claims SandopPlans CapacityPlans; do t build-fix split-$m $SC "FullyQualifiedName~$N.$m."; done
t build-fix architecture tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj ""
t build-fix gateway gateway/Diten.ApiGateway.Tests/Diten.ApiGateway.Tests.csproj ""
t build-fix web frontend/Diten.Web.Tests/Diten.Web.Tests.csproj ""
t build-fix secrets services/Diten.Building.Blocks/Diten.BuildingBlocks.Security.Secrets.Tests/Diten.BuildingBlocks.Security.Secrets.Tests.csproj ""
t build-fix mdm-application services/Diten.MdmService/tests/Diten.MdmService.Application.Tests/Diten.MdmService.Application.Tests.csproj ""
echo TEST-DONE
