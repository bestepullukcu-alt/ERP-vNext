import os,re,sys,tarfile,hashlib,csv
Q="/Users/natig/Projects/ERP-vNext-recovery/docs/records/audits/2026-09/mvp6-q117-test-guard-fixes-01"
B=os.path.expanduser("~/mvp6-env/base/src/"); S=os.path.expanduser("~/mvp6-env/q119/src/")
PAT="/private/tmp/claude-501/-Users-natig-Projects-ERP-vNext-recovery/83760972-cc6e-460e-ab88-7974ecd80729/scratchpad/f02.pat"
MARK="<REDACTED: Q101-F02 exposed value, never reproduced>"
sec=open(PAT).read().strip()
sha=lambda b: hashlib.sha256(b).hexdigest()
# 1) extract overlay onto the base clone
t=tarfile.open(Q+"/q117-fixes-overlay.tar.gz"); ov={}
for m in t.getmembers():
    if not m.isfile(): continue
    p=m.name.lstrip("./"); data=t.extractfile(m).read(); ov[p]=data
    os.makedirs(os.path.dirname(S+p),exist_ok=True); open(S+p,"wb").write(data)
print("overlay extracted files",len(ov))
# 2) strict in-memory unified-diff apply
lines=open(Q+"/FIXES.patch",encoding="utf-8").read().split("\n")
files={}; i=0
while i<len(lines):
    if lines[i].startswith("--- ") and i+1<len(lines) and lines[i+1].startswith("+++ "):
        a=lines[i][4:].split("\t")[0]; b=lines[i+1][4:].split("\t")[0]
        path=(b[2:] if b.startswith("b/") else b); cur=files.setdefault(path,{"a":a,"hunks":[]}); i+=2; continue
    m=re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@",lines[i])
    if m:
        ol=int(m.group(2) or 1); nl=int(m.group(4) or 1); body=[]; i+=1; o=n=0
        while o<ol or n<nl:
            l=lines[i]; i+=1
            if l.startswith("\\"): body.append(l); continue
            tag=l[:1]; body.append(l)
            if tag in (" ",""): o+=1;n+=1
            elif tag=="-": o+=1
            elif tag=="+": n+=1
            else: raise SystemExit(f"bad hunk line in {path}: {tag!r}")
        while i<len(lines) and lines[i].startswith("\\"): body.append(lines[i]); i+=1
        cur["hunks"].append((int(m.group(1)),ol,body)); continue
    i+=1
res=[]; swapped=0
for path,f in sorted(files.items()):
    src=b"" if f["a"]=="/dev/null" else open(B+path,"rb").read()
    txt=src.decode("utf-8"); endnl=txt.endswith("\n") or txt==""
    old=txt.split("\n")
    if endnl: old=old[:-1]
    out=[]; pos=0; noeol_new=False
    for (start,ol,body) in f["hunks"]:
        s0=start-1 if ol>0 else start
        out.extend(old[pos:s0]); pos=s0; prev=None
        for l in body:
            if l.startswith("\\"):
                if prev=="+" : noeol_new=True
                continue
            tag,content=l[:1],l[1:]
            if tag in ("-"," ") and MARK in content: content=content.replace(MARK,sec); swapped+=1
            if tag in (" ","-"):
                if old[pos]!=content: raise SystemExit(f"CONTEXT MISMATCH {path} line {pos+1}")
                pos+=1
            if tag in (" ","+"): out.append(content)
            prev=tag
    out.extend(old[pos:])
    new="\n".join(out)+("" if noeol_new else "\n")
    ok= new.encode()==ov.get(path)
    res.append((path,ok,sha(new.encode())))
    del new
print("patch files",len(files),"marker swaps in memory",swapped)
for p,ok,h in res: print(("MATCH " if ok else "DIFF  ")+h[:12]+"  "+p)
print("V2 byte-for-byte", sum(ok for _,ok,_ in res),"/",len(ov), "patch∖overlay",sorted(set(files)-set(ov)),"overlay∖patch",sorted(set(ov)-set(files)))
