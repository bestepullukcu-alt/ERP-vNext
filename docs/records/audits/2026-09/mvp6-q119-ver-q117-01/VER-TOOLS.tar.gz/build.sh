#!/bin/zsh
export DOTNET_CLI_TELEMETRY_OPTOUT=1 MSBUILDDISABLENODEREUSE=1 DOTNET_NOLOGO=1
L=~/mvp6-env/q119/logs/build; mkdir -p $L; S=$L/BUILD-SUMMARY.tsv; printf "tree\ttarget\texit\twarnings\terrors\n" > $S
b() { tree=$1; t=$2; n=$tree--${${t:t}:r}; cd ~/mvp6-env/q119/$tree
  dotnet build $t -c Debug --disable-build-servers -p:UseSharedCompilation=false > $L/$n.log 2>&1; rc=$?
  w=$(grep -E '^ *[0-9]+ Warning\(s\)' $L/$n.log | tail -1 | awk '{print $1}'); e=$(grep -E '^ *[0-9]+ Error\(s\)' $L/$n.log | tail -1 | awk '{print $1}')
  printf "%s\t%s\t%s\t%s\t%s\n" $tree $t $rc "$w" "$e" >> $S; }
for t in services/Diten.SupplyChainService/Diten.SupplyChainService.sln services/Diten.MdmService/Diten.MdmService.sln \
  services/Diten.HumanCapitalService/src/Diten.HumanCapitalService.Api/Diten.HumanCapitalService.Api.csproj \
  services/Diten.TalentEcosystemService/src/Diten.TalentEcosystemService.Api/Diten.TalentEcosystemService.Api.csproj \
  services/Diten.Building.Blocks/Diten.BuildingBlocks.Security.Secrets.Tests/Diten.BuildingBlocks.Security.Secrets.Tests.csproj \
  frontend/Diten.Web.Tests/Diten.Web.Tests.csproj gateway/Diten.ApiGateway.Tests/Diten.ApiGateway.Tests.csproj \
  tests/architecture/TenantArchitecture.ArchitectureTests/TenantArchitecture.ArchitectureTests.csproj; do b build-fix $t; done
T=services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj
b build-fix-ordered $T; b build-base-ordered $T
echo BUILD-DONE
