import os,sys,base64,urllib.parse,tarfile,gzip,io
PAT="/private/tmp/claude-501/-Users-natig-Projects-ERP-vNext-recovery/83760972-cc6e-460e-ab88-7974ecd80729/scratchpad/f02.pat"
v=open(PAT).read().strip().encode()
forms={"raw":v,"urlenc":urllib.parse.quote(v.decode(),safe="").encode(),"urlenc+":urllib.parse.quote_plus(v.decode()).encode()}
for sh in range(3):   # base64 of the value at each byte alignment inside a larger stream; keep only full 4-char groups
    pre=b"\0"*sh; e=base64.b64encode(pre+v); u=base64.urlsafe_b64encode(pre+v)
    skip=((sh+2)//3)*4 if sh else 0; core=len(v)+sh; end=(core//3)*4
    forms[f"b64_a{sh}"]=e[skip:end]; forms[f"b64url_a{sh}"]=u[skip:end]
forms={k:x for k,x in forms.items() if len(x)>=16}
units=0; hits=[]
def check(name,data):
    global units; units+=1
    for k,x in forms.items():
        if x in data: hits.append((name,k))
def walk_blob(name,data,depth=0):
    check(name,data)
    if depth>3: return
    try:
        if data[:2]==b"\x1f\x8b":
            try:
                with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as t:
                    for m in t.getmembers():
                        if m.isfile(): walk_blob(name+"::"+m.name,t.extractfile(m).read(),depth+1)
                return
            except tarfile.TarError: walk_blob(name+"::gunzip",gzip.decompress(data),depth+1)
    except Exception as ex: hits.append((name,"UNREADABLE:"+type(ex).__name__))
for root in sys.argv[1:]:
    for d,dn,fs in os.walk(os.path.expanduser(root)):
        for f in fs:
            p=os.path.join(d,f)
            if os.path.islink(p) or not os.path.isfile(p): continue
            walk_blob(p,open(p,"rb").read())
print("forms_checked",len(forms),"(raw, url-encoded x2, base64 and base64url at 3 alignments)")
print("scanned_units",units); print("hits",len(hits))
for h in hits: print("HIT",h[1],h[0])
print("result","PASS" if not hits else "FAIL")
