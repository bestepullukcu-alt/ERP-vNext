// Q119 VER-ONLY HARNESS — not part of Q117, never to be integrated. Added identically to the negative-control tree
// (plain BASE) and to the BASE+Q117 tree, to force Q103's Capacity-first collection order deterministically.
using Xunit;
using Xunit.Abstractions;

[assembly: TestCollectionOrderer("Diten.SupplyChainService.Tests.Q119VerHarness.CapacityFirstOrderer", "Diten.SupplyChainService.Tests")]

namespace Diten.SupplyChainService.Tests.Q119VerHarness;

public sealed class CapacityFirstOrderer : ITestCollectionOrderer
{
    public IEnumerable<ITestCollection> OrderTestCollections(IEnumerable<ITestCollection> testCollections)
    {
        var all = testCollections.ToList();
        static int Rank(ITestCollection c) =>
            c.DisplayName == "CapacityMongo" ? 0 : c.DisplayName.Contains(".CapacityPlans.", StringComparison.Ordinal) ? 1 : 2;
        var ordered = all.Select((c, i) => (c, i)).OrderBy(x => Rank(x.c)).ThenBy(x => x.i).Select(x => x.c).ToList();
        var log = Environment.GetEnvironmentVariable("Q119_ORDER_LOG");
        if (!string.IsNullOrEmpty(log))
            File.AppendAllLines(log, ordered.Select((c, i) => $"{i + 1}\t{c.DisplayName}"));
        return ordered;
    }
}
