#!/usr/bin/env python3
import json, os, signal, subprocess, time
from pathlib import Path

root=Path('/private/tmp/mvp6-mod0187-malformed-map-rework-01-evidence')
dbpath=root/'claims-test-mongo-final'; dbpath.mkdir(parents=True,exist_ok=True)
port=27955; repl='claims_malformed_map_tests_final'; uri=f'mongodb://127.0.0.1:{port}/?replicaSet={repl}'
log=open(root/'raw'/'claims-final-mongod.log','wb')
mongo=subprocess.Popen(['mongod','--dbpath',str(dbpath),'--bind_ip','127.0.0.1','--port',str(port),'--replSet',repl,'--oplogSize','64','--nounixsocket'],stdout=log,stderr=subprocess.STDOUT)
def run(args,**kw): return subprocess.run(args,text=True,capture_output=True,**kw)
try:
 deadline=time.time()+30
 while time.time()<deadline:
  if run(['mongosh','--quiet',f'mongodb://127.0.0.1:{port}/','--eval','db.adminCommand({ping:1}).ok']).returncode==0:break
  time.sleep(.25)
 else: raise RuntimeError('mongo ping timeout')
 init=run(['mongosh','--quiet',f'mongodb://127.0.0.1:{port}/','--eval',f'JSON.stringify(rs.initiate({{_id:{json.dumps(repl)},members:[{{_id:0,host:"127.0.0.1:{port}"}}]}}))'])
 (root/'raw'/'claims-final-replica-init.json').write_text(json.dumps({'exit':init.returncode,'stdout':init.stdout,'stderr':init.stderr},indent=2))
 deadline=time.time()+30
 while time.time()<deadline:
  state=run(['mongosh','--quiet',uri,'--eval','db.hello().isWritablePrimary'])
  if state.returncode==0 and state.stdout.strip()=='true':break
  time.sleep(.25)
 else: raise RuntimeError('PRIMARY timeout')
 env=dict(os.environ,CLAIMS_TEST_MONGO=uri,DOTNET_ROLL_FORWARD='Major')
 command=['dotnet','test','services/Diten.SupplyChainService/tests/Diten.SupplyChainService.Tests/Diten.SupplyChainService.Tests.csproj','-c','Debug','--no-restore','--filter','FullyQualifiedName~Diten.SupplyChainService.Tests.Claims.&FullyQualifiedName!~Receipt_TwoIndependentTestProcesses_DurableRecovery','--logger','trx;LogFileName=malformed-map-claims-final.trx','--results-directory',str(root/'results')]
 with open(root/'raw'/'claims-final-tests.log','wb') as output:
  test=subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT)
 (root/'raw'/'claims-final-tests.exit').write_text(str(test.returncode)+'\n')
 raise SystemExit(test.returncode)
finally:
 if mongo.poll() is None:
  mongo.send_signal(signal.SIGTERM)
  try:mongo.wait(timeout=15)
  except subprocess.TimeoutExpired:
   mongo.kill();mongo.wait(timeout=5)
 log.close()
 check=run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'])
 (root/'raw'/'claims-final-cleanup.json').write_text(json.dumps({'port':port,'closed':check.returncode!=0,'output':check.stdout},indent=2))
