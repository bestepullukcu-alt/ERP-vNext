'use strict';

const ShipmentDetails = (function () {
    const host = document.getElementById('shipment-details');
    const shipmentId = host?.dataset.shipmentId;
    const L = window.L10n || {};
    let permissions = { canDispatch: false, canCancel: false, canCapturePod: false };
    let shipment = null;
    const intents = new Map();
    const transitions = { Draft: ['Planned', 'Cancelled'], Planned: ['Dispatched', 'Cancelled'],
        Dispatched: ['InTransit', 'Delivered', 'Exception'], InTransit: ['Delivered', 'Exception'],
        Exception: ['InTransit', 'Cancelled'], Delivered: ['Closed'], Closed: [], Cancelled: [] };
    const uuid = () => crypto.randomUUID();
    const token = (form) => form.querySelector('input[name="__RequestVerificationToken"]')?.value || '';
    const text = (id, value) => { document.getElementById(id).textContent = value ?? L.unavailable; };
    const date = (value) => value ? new Intl.DateTimeFormat(document.documentElement.lang || 'en', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : L.unavailable;
    const readPermissions = () => { try { permissions = Object.assign(permissions, JSON.parse(document.getElementById('shipment-permissions')?.textContent || '{}')); } catch (_) { } };
    const showError = (message, id = 'detailsAlert') => { const el = document.getElementById(id); el.textContent = message; el.classList.remove('d-none'); el.focus?.(); };
    const error = async (response, alertId) => {
        let body = null; try { body = await response.json(); } catch (_) { }
        const code = body?.error?.code || '';
        const message = ({ SHIPMENT_NOT_FOUND: L.notFound, INVALID_SHIPMENT_TRANSITION: L.invalidTransition,
            POD_ALREADY_CAPTURED: L.podAlreadyCaptured, IDEMPOTENCY_KEY_REUSED: L.idempotencyKeyReused,
            PERSISTENCE_UNAVAILABLE: L.persistenceUnavailable, INTERNAL_ERROR: L.internalError })[code]
            || (response.status === 404 ? L.notFound : response.status === 403 ? L.accessDenied : L.validationError);
        const correlation = body?.error?.correlationId || response.headers.get('X-Correlation-Id');
        showError(`${message}${correlation ? ` ${L.supportReference}: ${correlation}` : ''}`, alertId);
        return code;
    };
    const renderLines = (lines) => {
        const body = document.getElementById('detailLines'); body.replaceChildren();
        (lines || []).forEach((line) => { const row = body.insertRow();
            [line.lineNumber, line.itemId, line.skuId, line.quantity, line.uomId, line.inventoryReferenceId || L.unavailable]
                .forEach((item) => { const cell = row.insertCell(); cell.textContent = item; }); });
    };
    const renderPod = (pod) => {
        document.getElementById('podEmpty').classList.toggle('d-none', !!pod);
        document.getElementById('podDetails').classList.toggle('d-none', !pod);
        if (!pod) return;
        text('podRecipient', pod.recipientName); text('podReceived', date(pod.receivedAt));
        text('podEvidence', (pod.evidenceReferenceIds || []).join(', ')); text('podNote', pod.note);
    };
    const allowedTargets = (status) => (transitions[status] || []).filter((target) =>
        target === 'Cancelled' ? permissions.canCancel : permissions.canDispatch);
    const renderActions = () => {
        const actions = document.getElementById('shipmentActions'); actions.replaceChildren();
        if (allowedTargets(shipment.status).length) {
            const button = document.createElement('button'); button.className = 'btn btn-primary'; button.textContent = L.transition;
            button.addEventListener('click', () => { const select = document.getElementById('targetStatus');
                select.replaceChildren(...allowedTargets(shipment.status).map((target) => new Option(target, target)));
                document.getElementById('occurredAt').value = new Date().toISOString().slice(0, 16);
                bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('offcanvasTransition')).show(); }); actions.appendChild(button);
        }
        if (permissions.canCapturePod && ['Dispatched', 'InTransit'].includes(shipment.status)) {
            const button = document.createElement('button'); button.className = 'btn btn-success'; button.textContent = L.capturePod;
            button.addEventListener('click', () => { document.getElementById('receivedAt').value = new Date().toISOString().slice(0, 16);
                bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('offcanvasPod')).show(); }); actions.appendChild(button);
        }
    };
    const render = (data) => {
        shipment = data; text('shipmentNumber', data.shipmentNumber); text('detailStatus', data.status);
        text('detailSource', data.sourceDocumentId); text('detailWarehouse', data.warehouseReferenceId); text('detailShipTo', data.shipToReference);
        text('detailRoot', data.lifecycleCorrelationId); text('detailPlannedShip', date(data.plannedShipAt)); text('detailPlannedDeliver', date(data.plannedDeliverAt));
        text('detailCarrier', data.carrierId); text('detailLoad', data.loadId); renderLines(data.lines); renderPod(data.pod); renderActions();
    };
    const load = async () => {
        try { const response = await fetch(`/SupplyChain/Shipments/api/${shipmentId}`, { credentials: 'same-origin', headers: { 'X-Correlation-Id': uuid() } });
            if (!response.ok) { await error(response); return; } render(await response.json()); }
        catch (_) { showError(L.persistenceUnavailable); }
    };
    const send = async (kind, payload, form, alertId) => {
        const body = JSON.stringify(payload); const previous = intents.get(kind);
        const intent = previous?.body === body ? previous : { body, key: uuid() }; intents.set(kind, intent);
        const execute = async () => {
            try { const response = await fetch(`/SupplyChain/Shipments/api/${shipmentId}/${kind}`, { method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'RequestVerificationToken': token(form), 'Idempotency-Key': intent.key, 'X-Correlation-Id': uuid() }, body: intent.body });
                if (!response.ok) { const code = await error(response, alertId); if (code === 'IDEMPOTENCY_KEY_REUSED') intents.delete(kind); await load(); return; }
                const result = await response.json(); window.showToast?.(result.idempotentReplay ? L.replay : L.success, 'success');
                bootstrap.Offcanvas.getInstance(form.closest('.offcanvas'))?.hide(); await load();
            } catch (_) { showError(L.persistenceUnavailable, alertId); }
        };
        window.showConfirm?.(L.confirmTitle, execute, { confirmButtonText: L.confirmAction });
    };
    const init = () => {
        if (!host) return; readPermissions();
        document.getElementById('formTransition')?.addEventListener('submit', (event) => { event.preventDefault();
            send('transition', { targetStatus: document.getElementById('targetStatus').value,
                occurredAt: new Date(document.getElementById('occurredAt').value).toISOString(),
                reasonCode: document.getElementById('reasonCode').value || null, note: document.getElementById('transitionNote').value || null }, event.currentTarget, 'transitionAlert'); });
        document.getElementById('formPod')?.addEventListener('submit', (event) => { event.preventDefault();
            send('pod', { recipientName: document.getElementById('recipientName').value,
                receivedAt: new Date(document.getElementById('receivedAt').value).toISOString(),
                evidenceReferenceIds: document.getElementById('evidenceReferenceIds').value.split(/\r?\n|,/).map((v) => v.trim()).filter(Boolean),
                note: document.getElementById('podNote').value || null }, event.currentTarget, 'podAlert'); });
        load();
    };
    document.addEventListener('DOMContentLoaded', init);
    return { init, allowedTargets };
})();
