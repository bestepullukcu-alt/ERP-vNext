'use strict';

const ShipmentCreate = (function () {
    const L = window.L10n || {};
    let intent = null;
    const uuid = () => crypto.randomUUID();
    const value = (id) => document.getElementById(id)?.value || '';
    const toUtc = (input) => input ? new Date(input).toISOString() : null;
    const token = () => document.querySelector('#formShipment input[name="__RequestVerificationToken"]')?.value || '';
    const showError = (message) => {
        const alert = document.getElementById('formShipmentAlert');
        alert.textContent = message; alert.classList.remove('d-none'); alert.focus();
    };
    const addLine = () => {
        const fragment = document.getElementById('shipmentLineTemplate').content.cloneNode(true);
        fragment.querySelector('.remove-line').addEventListener('click', (event) => {
            if (document.querySelectorAll('.shipment-line').length > 1) event.target.closest('.shipment-line').remove();
        });
        document.getElementById('shipmentLines').appendChild(fragment);
    };
    const linePayload = (line) => Object.fromEntries(['lineNumber', 'itemId', 'skuId', 'quantity', 'uomId', 'inventoryReferenceId']
        .map((name) => [name, line.querySelector(`[data-field="${name}"]`).value]));
    const payload = () => ({
        sourceModule: value('sourceModule'), sourceType: value('sourceType'), sourceDocumentId: value('sourceDocumentId'),
        warehouseReferenceId: value('warehouseReferenceId'), shipToReference: value('shipToReference'),
        plannedShipAt: toUtc(value('plannedShipAt')), lines: Array.from(document.querySelectorAll('.shipment-line')).map(linePayload),
        plannedDeliverAt: value('plannedDeliverAt') ? toUtc(value('plannedDeliverAt')) : null
    });
    const validate = (body) => body.sourceModule && body.sourceType && body.sourceDocumentId && body.warehouseReferenceId
        && body.shipToReference && body.plannedShipAt && body.lines.length > 0 && body.lines.every((line) =>
            line.lineNumber && /^[0-9a-f-]{36}$/i.test(line.itemId) && /^[0-9a-f-]{36}$/i.test(line.skuId)
            && /^-?[0-9]+(\.[0-9]+)?$/.test(line.quantity) && line.uomId);
    const failure = async (response) => {
        let body = null; try { body = await response.json(); } catch (_) { }
        const code = body?.error?.code || '';
        const message = ({ IDEMPOTENCY_KEY_REUSED: L.idempotencyKeyReused, PERSISTENCE_UNAVAILABLE: L.persistenceUnavailable,
            INTERNAL_ERROR: L.internalError })[code] || L.validationError;
        const correlation = body?.error?.correlationId || response.headers.get('X-Correlation-Id');
        showError(`${message}${correlation ? ` ${L.supportReference}: ${correlation}` : ''}`);
        if (code === 'IDEMPOTENCY_KEY_REUSED') intent = null;
    };
    const submit = async (event) => {
        event.preventDefault();
        const body = payload();
        if (!validate(body)) { showError(L.validationError); return; }
        const serialized = JSON.stringify(body);
        if (!intent || intent.payload !== serialized) intent = { payload: serialized, key: uuid() };
        const button = document.getElementById('btnSaveShipment'); button.disabled = true;
        try {
            const response = await fetch('/SupplyChain/Shipments/api', {
                method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json',
                    'RequestVerificationToken': token(), 'Idempotency-Key': intent.key, 'X-Correlation-Id': uuid() }, body: intent.payload
            });
            if (!response.ok) { await failure(response); return; }
            const result = await response.json();
            window.showToast?.(result.idempotentReplay ? L.replay : L.success, 'success');
            window.location.assign(`/SupplyChain/Shipments/Details/${encodeURIComponent(result.shipmentId)}`);
        } catch (error) { showError(L.persistenceUnavailable); }
        finally { button.disabled = false; }
    };
    const init = () => {
        document.getElementById('btnAddLine')?.addEventListener('click', addLine);
        document.getElementById('formShipment')?.addEventListener('submit', submit);
        addLine();
        window.DitenDateField?.enhance(document);
    };
    document.addEventListener('DOMContentLoaded', init);
    return { init, payload };
})();
