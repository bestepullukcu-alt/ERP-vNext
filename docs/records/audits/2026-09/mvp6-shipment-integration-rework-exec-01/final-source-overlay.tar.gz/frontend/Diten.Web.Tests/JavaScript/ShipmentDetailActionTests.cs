using Xunit;

namespace Diten.Web.Tests.JavaScript;

public sealed class ShipmentDetailActionTests
{
    private readonly string _details = Read("frontend/Diten.Web/wwwroot/assets/js/SupplyChain/Shipments/details.js");
    private readonly string _create = Read("frontend/Diten.Web/wwwroot/assets/js/SupplyChain/Shipments/create.js");
    [Fact] public void LifecycleMatrixAndPermissionSplitAreExact() { Assert.Contains("Draft: ['Planned', 'Cancelled']", _details); Assert.Contains("Delivered: ['Closed']", _details); Assert.Contains("target === 'Cancelled' ? permissions.canCancel : permissions.canDispatch", _details); Assert.Contains("['Dispatched', 'InTransit'].includes", _details); }
    [Fact] public void StableIntentPreservesPayloadAndKey() { Assert.Contains("previous?.body === body", _details); Assert.Contains("'Idempotency-Key': intent.key", _details); Assert.Contains("intent.payload !== serialized", _create); Assert.Contains("body: intent.payload", _create); }
    [Fact] public void UsesSharedModalAndDoesNotUploadOrStoreSecrets() { Assert.Contains("window.showConfirm?.", _details); Assert.Contains("window.showToast?.", _details); Assert.DoesNotContain("Swal.fire", _details); Assert.DoesNotContain("window.confirm", _details); Assert.DoesNotContain("FormData", _details); Assert.DoesNotContain("localStorage", _details + _create); Assert.DoesNotContain(":5061", _details + _create); }
    [Fact] public void CorrelationAndLifecycleRootRemainSeparate() { Assert.Contains("data.lifecycleCorrelationId", _details); Assert.Contains("body?.error?.correlationId", _details); Assert.DoesNotContain("lifecycleCorrelationId ||", _details); }
    private static string Read(string path) => File.ReadAllText(Path.Combine(Root(), path));
    private static string Root() { var dir = new DirectoryInfo(AppContext.BaseDirectory); while (dir is not null && !File.Exists(Path.Combine(dir.FullName, "AGENTS.md"))) dir = dir.Parent; return dir?.FullName ?? throw new DirectoryNotFoundException(); }
}
