from pathlib import Path
import yaml,json,copy,re,hashlib
from jsonschema import Draft202012Validator,FormatChecker,RefResolver
W=Path(__file__).parent;P=W/'candidate';I=W/'inputs';b=yaml.safe_load((I/'root/r2pack/baseline-2.0.0.yaml').read_text());r=yaml.safe_load((I/'root/r2pack/shipment-bundle-2.0.0-root-r2-candidate.yaml').read_text());ret=yaml.safe_load((I/'returns/returns-r2/shipment-bundle.returns-r2.yaml').read_text());cl=yaml.safe_load((I/'claims/claims-r2/claims-r2.openapi.yaml').read_text());d=yaml.safe_load((P/'shipment-bundle-combined-candidate.yaml').read_text());results=[]
def ck(n,v):results.append({'id':n,'pass':bool(v)})
for key,source in [('/returns',ret),('/returns/{returnId}/transition',ret),('/claims',cl),('/claims/{claimId}/transition',cl)]:ck('owned-exact-'+key,d['paths'][key]==source['paths'][key]);ck('owned-changed-'+key,d['paths'][key]!=b['paths'][key])
expected=copy.deepcopy(r)
for key in ['/returns','/returns/{returnId}/transition']:expected['paths'][key]=ret['paths'][key]
for key in ['/claims','/claims/{claimId}/transition']:expected['paths'][key]=cl['paths'][key]
ck('exact-union-no-extra-business',d==expected);ck('orders-byte-identical',(W/'rebased-root-returns-claims/combined.yaml').read_bytes()==(W/'rebased-root-claims-returns/combined.yaml').read_bytes());ck('shared-root-only',d['components']==r['components']);ck('not-FROZEN',d['info']['x-status']=='CANDIDATE');ck('wire-v1',d['components']['schemas']['ContractVersion']==b['components']['schemas']['ContractVersion'])
resolver=RefResolver.from_schema(d);stats={'refs':0,'examples':0};errors=[]
def walk(x,p=''):
 if isinstance(x,dict):
  if '$ref' in x:
   v=d
   for k in x['$ref'][2:].split('/'):v=v[k.replace('~1','/').replace('~0','~')]
   stats['refs']+=1
  if 'schema' in x:
   for val in ([x['example']] if 'example' in x else [])+[e['value'] for e in x.get('examples',{}).values() if 'value' in e]:
    es=list(Draft202012Validator(x['schema'],resolver=resolver,format_checker=FormatChecker()).iter_errors(val));stats['examples']+=1
    if es:errors.append({'pointer':p,'errors':[e.message for e in es]})
  for k,v in x.items():walk(v,p+'/'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,p+'/'+str(i))
walk(d);ck('all-examples',not errors)
prop=d['components']['schemas']['ShipmentDetail']['allOf'][1]['properties']['lifecycleCorrelationId'];ck('nullable-uuid',set(prop['type'])=={'string','null'} and prop['format']=='uuid');ck('root-optional','lifecycleCorrelationId' not in d['components']['schemas']['ShipmentDetail']['allOf'][1]['required'])
pol=json.loads(d['paths']['/claims']['post']['description'].split('\n')[1]);ck('claims-withdrawn',pol['permissions']['Withdrawn']=='investigate');ck('claims-errors',pol['errors']['lifecycle']==[422,'INVALID_CLAIM_TRANSITION'] and pol['errors']['payload']==[409,'IDEMPOTENCY_KEY_REUSED'] and pol['errors']['root']==[409,'CLAIM_CORRELATION_MISMATCH'])
# New combined subject: extract canonical lifecycle edges and verify Claims policy against them.
edges=set()
for s,ts in re.findall(r'(\w+)->([\w|]+)',b['paths']['/claims/{claimId}/transition']['post']['description']):
 for t in ts.split('|'):edges.add((s,t))
for s in b['components']['schemas']['ClaimStatus']['enum']:
 for t in b['components']['schemas']['ClaimStatus']['enum']:ck('combined-claims-edge-'+s+'-'+t,([s,t] in pol['edges'])==((s,t) in edges))
ck('returns-lifecycle-owned-preserved',d['paths']['/returns/{returnId}/transition']==ret['paths']['/returns/{returnId}/transition'])
# AST leaf diff is evidence that actual mutations, not dry runs, are present.
def diff(a,z,p=''):
 if type(a)!=type(z):return [p]
 if isinstance(a,dict):
  out=[]
  for k in a.keys()|z.keys():out+=diff(a[k],z[k],p+'/'+str(k)) if k in a and k in z else [p+'/'+str(k)]
  return out
 if isinstance(a,list):return [p] if a!=z else []
 return [p] if a!=z else []
(P/'baseline-ast-diff.json').write_text(json.dumps(sorted(diff(b,d)),indent=2))
(P/'validation-results.json').write_text(json.dumps({'checks':results,'counts':stats,'exampleErrors':errors,'passed':sum(x['pass'] for x in results),'failed':sum(not x['pass'] for x in results),'scope':'fresh combined contract checks; not full OpenAPI meta-schema validator or runtime'},indent=2));print(stats,'checks',len(results),'failures',sum(not x['pass'] for x in results));assert all(x['pass'] for x in results)
