from pathlib import Path
import yaml,json,hashlib,difflib,subprocess,shutil
W=Path(__file__).parent;I=W/'inputs';base=(I/'root/r2pack/baseline-2.0.0.yaml').read_text();b=yaml.safe_load(base)
texts={'root':(I/'root/r2pack/shipment-bundle-2.0.0-root-r2-candidate.yaml').read_text(),'returns':(I/'returns/returns-r2/shipment-bundle.returns-r2.yaml').read_text(),'claims':(I/'claims/claims-r2/claims-r2.openapi.yaml').read_text()}
# Prove each consumer delta is entirely contained by exact operation block boundaries.
def block(s,m):
 start=s.index('  /'+m+':\n');end=s.index('  /claims:\n',start) if m=='returns' else s.index('webhooks:\n',start);return start,end,s[start:end]
for m in ['returns','claims']:
 x,y,_=block(base,m);a,z,_=block(texts[m],m);assert base[:x]==texts[m][:a] and base[y:]==texts[m][z:]
logs=[]
for order in [('root','returns','claims'),('root','claims','returns')]:
 D=W/('rebased-'+'-'.join(order));D.mkdir();f=D/'combined.yaml';f.write_text(texts['root'])
 for m in order[1:]:
  old=f.read_text();a,z,_=block(old,m);_,_,newblock=block(texts[m],m);new=old[:a]+newblock+old[z:]
  patch=D/(m+'-context-rebased.patch');patch.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='combined.yaml',tofile='combined.yaml')))
  r=subprocess.run(['patch','--batch','--fuzz=0',str(f),str(patch)],cwd=D,capture_output=True,text=True);assert r.returncode==0 and f.read_text()==new;logs.append({'order':order,'module':m,'exit':r.returncode,'stdout':r.stdout})
a=W/'rebased-root-returns-claims/combined.yaml';c=W/'rebased-root-claims-returns/combined.yaml';assert a.read_bytes()==c.read_bytes()
P=W/'candidate';P.mkdir();shutil.copyfile(a,P/'shipment-bundle-combined-candidate.yaml')
for src,name in [(I/'root/r2pack/semantics-r2.md','shipment-root-semantics-candidate.md'),(I/'returns/returns-r2/semantics-candidate.md','returns-semantics-candidate.md'),(I/'claims/claims-r2/claims-semantics-r2.md','claims-semantics-r2.md')]:shutil.copyfile(src,P/name)
# Preserve linked Returns annex basename; root/other annexes remain unchanged original content.
shutil.copyfile(I/'returns/returns-r2/semantics-candidate.md',P/'semantics-candidate.md')
(P/'combined.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),a.read_text().splitlines(True),fromfile='a/docs/analysis/contracts/shipment-bundle.openapi.yaml',tofile='b/docs/analysis/contracts/shipment-bundle.openapi.yaml')))
(P/'release-proposal.md').write_text('Version proposal ONLY: 3.0.0 / wire v1. Not approved/published. Candidate retains info.version2.0.0 and Root R2 CANDIDATE status; no FROZEN promotion. Release owner must decide final version and exact annex destination paths, then rehash final bytes. No consent/guard/rollout implied. Annex originals retained byte-identical; historical proposal labels/paths remain provenance, not publication authority.\n')
(W/'rebased-application-log.json').write_text(json.dumps(logs,indent=2));print(hashlib.sha256(a.read_bytes()).hexdigest())
