import copy,hashlib,json,re,subprocess,sys,tempfile
from pathlib import Path
from decimal import Decimal
import yaml,jsonschema
P=Path(__file__).parent
read=lambda n:json.loads((P/n).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=yaml.safe_load((P/'baseline.openapi.yaml').read_text()); d=yaml.safe_load((P/'claims-r2.openapi.yaml').read_text());oracle=read('policy-oracle.json')
policy=json.loads(d['paths']['/claims']['post']['description'].split('\n')[1]);results=[]
def check(i,ok,level='candidate-model'):results.append({'id':i,'pass':bool(ok),'level':level})
check('AST-shared',b['components']==d['components'],'AST')
check('AST-nonclaims', {k:v for k,v in b['paths'].items() if not k.startswith('/claims')}=={k:v for k,v in d['paths'].items() if not k.startswith('/claims')},'AST')
check('AST-top', {k:v for k,v in b.items() if k!='paths'}=={k:v for k,v in d.items() if k!='paths'},'AST')
check('MODEL-exact',sha(P/'rework-model.py')=='c8b3c3bbd2a0f17558f1b1811a65aae9823f760a9cd17ac662a2aa75d4f10e57','hash')
check('POLICY-bound',policy==oracle,'contract-binding')
resolver=jsonschema.RefResolver.from_schema(d)
for path in ['/claims','/claims/{claimId}/transition']:
 for op in d['paths'][path].values():
  check('POLICY-'+op['operationId'],json.loads(op['description'].split('\n')[1])==policy,'contract-binding')
  for status,r in op['responses'].items():
   for media in r.get('content',{}).values():
    examples=[media['example']] if 'example' in media else [x['value'] for x in media.get('examples',{}).values()]
    for i,e in enumerate(examples):
     jsonschema.Draft202012Validator(media['schema'],resolver=resolver,format_checker=jsonschema.FormatChecker()).validate(e)
     check(f'SCHEMA-{op["operationId"]}-{status}-{i}',True,'schema')
  for media in op.get('requestBody',{}).get('content',{}).values():jsonschema.Draft202012Validator(media['schema'],resolver=resolver,format_checker=jsonschema.FormatChecker()).validate(media['example'])
# New adapter executes policy extracted from YAML; independent fixed oracles below.
def root(p,value,request,changed=False):
 if value is None or value=='':return p['errors']['missing']
 if not re.fullmatch(r'[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}',value):return p['errors']['malformed']
 if changed and not p['rootBeforePayload']:return p['errors']['payload']
 if value.lower()!=request.lower():return p['errors']['root']
 return p['errors']['payload'] if changed else [200,'OK']
def transition(p,source,target,grants,claimed='250',stored=None,amount=None):
 if p['permissions'][target] not in grants:return [403,'FORBIDDEN',stored]
 if [source,target] not in p['edges']:return p['errors']['lifecycle']+[stored]
 if target=='Approved':
  if amount is None or Decimal(amount)<0 or Decimal(amount)>Decimal(claimed) or (not p['zeroApproval'] and Decimal(amount)==0):return [422,'CLAIM_APPROVAL_AMOUNT_INVALID',stored]
  stored=amount
 elif amount is not None:return [422,'CLAIM_APPROVED_AMOUNT_NOT_ALLOWED',stored]
 elif not p['retainAmount']:stored=None
 return [200,'OK',stored]
legal={('Open','Investigating'),('Open','Withdrawn'),('Investigating','Approved'),('Investigating','Rejected'),('Approved','Settled'),('Rejected','Closed'),('Settled','Closed')}
states=b['components']['schemas']['ClaimStatus']['enum']; fixtures=[]
for s in states:
 for t in states:
  expected=200 if (s,t) in legal else 422
  got=transition(policy,s,t,{'create','investigate','decide','settle'},amount='0' if t=='Approved' else None)
  check('LIFE-'+s+'-'+t,got[0]==expected and (expected==200 or got[1]=='INVALID_CLAIM_TRANSITION'))
  fixtures.append({'from':s,'to':t,'expectedStatus':expected,'expectedCode':'OK' if expected==200 else 'INVALID_CLAIM_TRANSITION'})
(P/'lifecycle-fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
r='aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa';other='bbbbbbbb-1111-4111-8111-aaaaaaaaaaaa';nil='00000000-0000-0000-0000-000000000000'
rootcases=[('missing',None,r,False,503,'CLAIM_REFERENCE_INCOMPLETE'),('null',None,r,False,503,'CLAIM_REFERENCE_INCOMPLETE'),('empty','',r,False,503,'CLAIM_REFERENCE_INCOMPLETE'),('malformed','r',r,False,502,'CLAIM_REFERENCE_INVALID'),('same',r,r,False,200,'OK'),('different',r,other,False,409,'CLAIM_CORRELATION_MISMATCH'),('changed',r,r,True,409,'IDEMPOTENCY_KEY_REUSED'),('both',r,other,True,409,'CLAIM_CORRELATION_MISMATCH'),('nil-same',nil,nil,False,200,'OK'),('nil-different',nil,r,False,409,'CLAIM_CORRELATION_MISMATCH')]
for n,v,req,changed,status,code in rootcases:check('ROOT-'+n,root(policy,v,req,changed)==[status,code])
(P/'root-fixtures.json').write_text(json.dumps(rootcases,indent=2)+'\n')
check('PERM-withdraw-create',transition(policy,'Open','Withdrawn',{'create'})[0]==403)
check('PERM-withdraw-investigate',transition(policy,'Open','Withdrawn',{'investigate'})[0]==200)
check('PERM-close-settle',transition(policy,'Settled','Closed',{'settle'})[0]==403)
check('AMOUNT-zero',transition(policy,'Investigating','Approved',{'decide'},amount='-0')[0]==200)
check('AMOUNT-over',transition(policy,'Investigating','Approved',{'decide'},amount='250.01')[0]==422)
stored=transition(policy,'Investigating','Approved',{'decide'},amount='125.00')[2]
stored=transition(policy,'Approved','Settled',{'settle'},stored=stored)[2]
stored=transition(policy,'Settled','Closed',{'decide'},stored=stored)[2]
check('STATE-retention',stored=='125.00')
check('AMOUNT-other',transition(policy,'Approved','Settled',{'settle'},amount='1')[1]=='CLAIM_APPROVED_AMOUNT_NOT_ALLOWED')
def fp(p,amount,time):
 a=amount if p['lexicalAmount'] else str(Decimal(amount).normalize())
 return json.dumps([a,time if p['lexicalTime'] else time.replace('12:00:00+03:00','09:00:00Z')])
check('FP-amount',fp(policy,'250','t')!=fp(policy,'250.00','t'))
check('FP-time',fp(policy,'250','2026-09-20T09:00:00Z')!=fp(policy,'250','2026-09-20T12:00:00+03:00'))
class Store:
 def __init__(self,p):self.p=p;self.docs=[];self.receipts={};self.audits=[];self.events=[]
 def create(self,tenant,key,amount,actor='a',unknown=False,fail=None):
  k=(tenant,'le','create','create',key) if self.p['scopeReceipt'] else key
  if k in self.receipts:return self.receipts[k]
  if self.docs and not self.p['duplicatesAllowed']:return 409
  before=copy.deepcopy((self.docs,self.receipts,self.audits,self.events))
  self.docs.append({'tenant':tenant,'amount':amount});self.receipts[k]=201;self.audits.append(actor);self.events.append('Pending')
  if fail is not None:self.docs,self.receipts,self.audits,self.events=before;return 503
  if unknown:return self.receipts[k] if self.p['unknownCommitRecovery'] else 503
  return 201
s=Store(policy);s.create('t','a','1');s.create('t','a','1',actor='b');check('STATE-replay',len(s.docs)==len(s.audits)==len(s.events)==1 and s.audits==['a'])
s.create('other','a','1');check('STATE-scope',len(s.docs)==2)
s.create('t','b','1');check('STATE-duplicates',len(s.docs)==3)
check('STATE-unknown',s.create('t','c','1',unknown=True)==201 and s.create('t','c','1')==201 and len(s.docs)==4)
for i in range(4):
 x=Store(policy);x.create('t','a','1',fail=i);check('STATE-precommit-'+str(i),not(x.docs or x.receipts or x.audits or x.events))
# Actual policy mutations; each must be killed by a fixed oracle.
witnesses=[('withdraw',lambda p:p['permissions'].update(Withdrawn='create'),lambda p:transition(p,'Open','Withdrawn',{'investigate'})[0]==200),('lifecycle',lambda p:p['errors'].update(lifecycle=[409,'INVALID_CLAIM_TRANSITION']),lambda p:transition(p,'Open','Closed',{'decide'})[0]==422),('root-precedence',lambda p:p.update(rootBeforePayload=False),lambda p:root(p,r,other,True)==[409,'CLAIM_CORRELATION_MISMATCH']),('amount',lambda p:p.update(lexicalAmount=False),lambda p:fp(p,'250','t')!=fp(p,'250.00','t')),('retention',lambda p:p.update(retainAmount=False),lambda p:transition(p,'Approved','Settled',{'settle'},stored='1')[2]=='1'),('zero',lambda p:p.update(zeroApproval=False),lambda p:transition(p,'Investigating','Approved',{'decide'},amount='0')[0]==200),('worker',lambda p:p.update(worker=True),lambda p:not p['worker'])]
for n,mut,assertion in witnesses:
 p=copy.deepcopy(policy);mut(p);check('MUTATION-'+n,assertion(policy) and not assertion(p),'mutation-policy')
# All declarations must bind exact approved profile, not mere presence.
for k in policy:check('BOUND-'+k,policy[k]==oracle[k],'contract-binding')
subprocess.run([sys.executable,str(P/'rework-model.py')],check=True,cwd=P)
check('RECOVERED-run',read('rework-results.json')['failed']==0,'historical-model-rerun')
(P/'r2-results.json').write_text(json.dumps({'checks':results,'passed':sum(x['pass'] for x in results),'failed':sum(not x['pass'] for x in results),'lifecycle':{'total':49,'allowed':7,'rejected':42},'runtime':False,'limitations':['in-memory candidate adapter; no HTTP/JWT/Mongo/concurrency evidence','recovered model includes declarative and constant witnesses; not sufficient by itself']},indent=2)+'\n')
print('R2',sum(x['pass'] for x in results),'PASS',sum(not x['pass'] for x in results),'FAIL')
assert all(x['pass'] for x in results)
