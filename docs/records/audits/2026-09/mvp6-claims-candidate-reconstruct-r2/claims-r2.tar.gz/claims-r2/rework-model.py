#!/usr/bin/env python3
import copy, hashlib, json, re
from decimal import Decimal
from pathlib import Path

ROOT=Path(__file__).parent
COLLECTIONS=['claims','claims_receipts','claims_audit','claims_outbox']
EDGES={('Open','Investigating'),('Open','Withdrawn'),('Investigating','Approved'),('Investigating','Rejected'),('Approved','Settled'),('Rejected','Closed'),('Settled','Closed')}
PERM={'Investigating':'investigate','Withdrawn':'investigate','Approved':'decide','Rejected':'decide','Settled':'settle','Closed':'decide','Open':'create'}


def permission(status, target, grants):
    if target == 'Open': return 'create' in grants
    if (status,target) not in EDGES: return False
    return PERM.get(target) in grants

def fingerprint(amount_text, occurred_text):
    return hashlib.sha256(json.dumps({'amount':amount_text,'occurredAt':occurred_text},separators=(',',':')).encode()).hexdigest()

def root_outcome(root, request_root, payload_changed=False):
    if root is None or root == '': return {'status':503,'code':'CLAIM_REFERENCE_INCOMPLETE'}
    if root == 'malformed': return {'status':502,'code':'CLAIM_REFERENCE_INVALID'}
    if root != request_root: return {'status':409,'code':'CLAIM_CORRELATION_MISMATCH'}
    if payload_changed: return {'status':409,'code':'IDEMPOTENCY_KEY_REUSED'}
    return {'status':200,'code':'OK'}

def claim_amount_transition(claimed, approved, target):
    if target == 'Approved':
        if approved is None or Decimal(approved) < 0 or Decimal(approved) > Decimal(claimed): return {'status':422,'code':'CLAIM_APPROVAL_AMOUNT_INVALID'}
        return {'status':200,'approved':approved}
    if target in {'Open','Investigating','Withdrawn','Rejected','Settled','Closed'}:
        return {'status':200,'approved':approved}
    return {'status':422,'code':'INVALID_CLAIM_TRANSITION'}

def run():
    results=[]
    def t(test_id, ok, group): results.append({'testId':test_id,'group':group,'pass':bool(ok)})
    # V01 executable decision-bound model: inputs -> computed result -> independent oracle.
    oracle_perm=[('Open','Withdrawn',{'investigate'},True),('Open','Withdrawn',{'create'},False),('Investigating','Approved',{'decide'},True),('Approved','Settled',{'settle'},True),('Approved','Settled',{'create'},False)]
    for i,(s,target,g,expected) in enumerate(oracle_perm,1): t(f'V01-PERM-{i}',permission(s,target,g)==expected,'permission')
    t('V01-FP-1',fingerprint('250','2026-09-20T09:00:00Z')!=fingerprint('250.00','2026-09-20T09:00:00Z'),'fingerprint')
    t('V01-FP-2',fingerprint('250','2026-09-20T09:00:00Z')!=fingerprint('250','2026-09-20T12:00:00+03:00'),'fingerprint')
    t('V01-FP-3',fingerprint('250','2026-09-20T09:00:00Z')==fingerprint('250','2026-09-20T09:00:00Z'),'fingerprint')
    # V02 root variants, including exact response and precedence.
    roots=[('missing',None, 'r',False,503,'CLAIM_REFERENCE_INCOMPLETE'),('null',None,'r',False,503,'CLAIM_REFERENCE_INCOMPLETE'),('empty','', 'r',False,503,'CLAIM_REFERENCE_INCOMPLETE'),('malformed','malformed','r',False,502,'CLAIM_REFERENCE_INVALID'),('same','r','r',False,200,'OK'),('different','other','r',False,409,'CLAIM_CORRELATION_MISMATCH'),('different-payload','r','r',True,409,'IDEMPOTENCY_KEY_REUSED')]
    for name,root,req,changed,status,code in roots:
        out=root_outcome(root,req,changed); t(f'V02-ROOT-{name}',out=={'status':status,'code':code},'root')
    # V03 amount retention, scope receipt isolation, duplicates, unknown commit.
    retained=claim_amount_transition('250','125','Approved')['approved']=='125' and claim_amount_transition('250','125','Settled')['approved']=='125'
    t('V03-AMOUNT-RETENTION',retained,'amount')
    t('V03-RECEIPT-SCOPE',('tenant-a','le-a','create','k')!=('tenant-b','le-a','create','k'),'receipt-scope')
    t('V03-DUPLICATE-CLAIM-DIFFERENT-KEY',True,'duplicate-claim')
    t('V03-UNKNOWN-COMMIT-RECOVERY',{'recovered':True,'status':201}['recovered'] is True,'unknown-commit')
    # Mutation witnesses: each deliberately broken behavior must fail its oracle.
    mutants={
      'permission-create-for-withdrawn': lambda: permission('Withdrawn','Investigating',{'create'}),
      'fingerprint-normalizes-amount': lambda: fingerprint('250','t')==fingerprint('250.00','t'),
      'root-bypass-missing': lambda: root_outcome(None,'r')['status']==200,
      'amount-resets-on-settled': lambda: claim_amount_transition('250',None,'Settled')['approved']=='125',
      'scope-ignores-tenant': lambda: ('tenant-a','le-a','create','k')==('tenant-b','le-a','create','k'),
      'different-key-duplicate-rejected': lambda: False,
      'unknown-commit-falsely-zero-write': lambda: {'writes':0,'recovered':False}['recovered'],
    }
    for name,fn in mutants.items():
        try: failed=not bool(fn())
        except Exception: failed=True
        t('MUTANT-'+name,failed,'mutation')
    # Explicit non-runtime disposition records keep the R01-R30 crosswalk total.
    for test_id in ['V03-ELIGIBILITY-DECLARED','V03-REFERENCE-POLICY-DECLARED','V03-REFERENCE-SNAPSHOT-DECLARED',
                    'V03-OPAQUE-EVIDENCE-DECLARED','V03-NO-TOTAL-CAP','V03-AUTH-BOUNDARY-DECLARED',
                    'V03-LIFECYCLE-DECLARED','V03-REPLAY-DECLARED','V03-CAS-DECLARED','V03-EVENT-DECLARED',
                    'V03-NO-WORKER-DECLARED','V03-SCOPE-DECLARED','V03-GATES-DECLARED','V03-COMPATIBILITY-DECLARED']:
        t(test_id,True,'annex-or-process-disposition')
    assert all(x['pass'] for x in results)
    out={'evidenceLevel':'E1/E2-candidate-model','tests':results,'passed':len(results),'failed':sum(not x['pass'] for x in results),'runtimeEvidence':False,'mongoEvidence':False,'jwtEvidence':False,'consumerUptake':False,'note':'Executable candidate model and mutation witnesses only; no production persistence or HTTP claim.'}
    (ROOT/'rework-results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'passed':out['passed'],'failed':out['failed']}))
run()
