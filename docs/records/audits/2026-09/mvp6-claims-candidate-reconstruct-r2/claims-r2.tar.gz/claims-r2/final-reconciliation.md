**Uzlaştırılmış karar seti hazır.** Shipment root tasarımı zaten onaylıdır; yeniden onay istemiyorum. D186/D187’nin diğer tasarım kararları için gerçek onay saptamadım. Aşağıdaki maddeler **consumer amendment adayı hazırlamak üzere açık öneridir**.

R01–R30’u **Agent Lane-3 / MVP6-MOD0187-PROPOSAL-RECONCILE-01** sohbet kaydından doğruladım. Bu uzlaştırma, eski Claims metnindeki üç önerinin yerini alıyor:

- Withdrawn: **`supplychain.claims.investigate`**
- Geçersiz lifecycle: **422 `INVALID_CLAIM_TRANSITION`**
- Payload conflict: **409 `IDEMPOTENCY_KEY_REUSED` — owner onayı hâlâ gerekli**

`CLAIM_REPLAY_CONFLICT` mevcut karar olarak kullanılmayacak.

**Zaten onaylı ortak sınır**

İki modül de özgün Shipment root’unu koruyacak. Returns bağımsız root başlatmayacak. Gerçek başarılı create için authoritative root seam’i **yayımlanmış, producer’da uygulanmış ve tüketimi doğrulanmış** olmalı. Candidate/model PASS bu koşulu sağlamaz.

Missing/null→503, malformed→502, root mismatch→409 sınıflandırması consumer adaylarında açıkça bağlanacak. İç DB, response trace, kimlikten türetme ve otomatik backfill yok. MOD-0186’nın doğrudan dependency’si Shipment; MOD-0185 kabulü için ek teknik önkoşul çıkarılmıyor.

Dayanak: [doğrulanmış root adayı raporu](/private/tmp/mvp6-shipment-root-ver-m8i5_yd5/verification-report.md). Exact patch: `64fd21ec9aa5ce80d102032ae75175b79c87c7fc1dc9aacacc9b7a4cb083bdf5`.

**Returns — kalan kararlar**

Kaynak: [D186 owner paketi](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0186-prep-02/owner-decisions-v1.0.md). Bağımsız Return root’u söyleyen §4 ve G186-05 ifadeleri bu karar setine **alınmıyor**.

| Karar | Önerilen exact davranış ve iş etkisi | Acceptance |
|---|---|---|
| **D186-01 — uygunluk/miktar** | Yalnız Delivered/Closed Shipment. Limit `ShipmentLine.quantity`; teslim edilmiş miktar iddiası değildir. Satır ve UoM ordinal eşleşir; conversion yok; quantity>0; aynı komutta duplicate satır yasak. Fresh create kaynak okur; transition/replay okumaz. İlk entitlement snapshot’ındaki quantity/UoM/item/sku değişirse409 `RETURN_SOURCE_CHANGED`. HTTP okuması distributed transaction sağlamaz. | 10EA üzerinde4EA kabul; InTransit,0/negatif,UoM farkı veya duplicate satır422. Eksik satır404. Snapshot drift409; yerel yazım yok. |
| **D186-02 — net-return/yarış** | Requested, Authorized, InTransit, Received, Dispositioned, Closed kapasite tüketir. Yalnız Rejected/Cancelled bırakır. Closed/soft-delete bırakmaz. Entitlement anahtarı tenant+LE+Shipment+satır; UoM ikinci kapasite oluşturmaz. | Cap10’da6+6 yarışında bir201, diğer422;4+6 kabul. Çok satır all-or-none. Tekrar cancel/reject çift release yapmaz. |
| **D186-03 — Received** | Yetkili actor’un **manual assertion** komutudur; fiziksel Warehouse receipt doğrulanmış sayılmaz. Actor, komut zamanı, commit zamanı ve kanıt türü audit edilir. Evidence opaque kalır. | InTransit→Received doğru izinle200; Authorized→Received422; izin yok403. Opaque evidence fiziksel kabul kanıtı sayılmaz. |
| **D186-04 — Inventory/disposition** | Inventory ve Warehouse HTTP çağrısı **sıfır**. Optional Inventory reference omission/null/empty olarak opaque saklanır; verified değildir. Dispositioned için `dispositionCode` length≥1; trim/catalog yok. | Null/empty Inventory reference Received’i engellemez. Dispositioned null/empty code422; `" "` kabul. Stok hareketi/rezervasyon yok. |
| **D186-05 — permission/error/replay** | Returns’e özgü base `.transition` + hedef izni korunur. Sayısal quantity fingerprint’i: `1.0=1.00`; datetime aynı instant normalize edilir. Same-root receipt replay original201/200; farklı geçerli payload409 `IDEMPOTENCY_KEY_REUSED`; root uyuşmazlığı önce gelir. Root erişimi için aşağıdaki ortak düzeltme uygulanır. | Yetkili replay kaynak kapalıyken çalışır; yeni entitlement/audit/event yok. Farklı-root+farklı-payload→root409. Aynı key/numeric eşit quantity→replay. |
| **D186-06 — persistence/event** | Return+entitlement+receipt+audit+pending outbox tek L3 transaction. Exact decimal; rounding/Decimal128 daraltması yok. `RMA-`+uppercase UUID-N; kesin uncommitted collision için en fazla3 UUID denemesi. Event root’u Shipment’tan miras. Create causation null; transition önceki Return eventId. | Her precommit failpoint’te sıfır kısmi yazım. Unknown commit→receipt recovery, çözülemezse503; rollback varsayılmaz. Lost response/restart tek mutation/event. |

Returns lifecycle değiştirilmez: Requested→Authorized/Rejected; Authorized→InTransit/Cancelled; InTransit→Received/Cancelled; Received→Dispositioned; Dispositioned→Closed. Kaynak: canonical `transitionReturn`, `ReturnLine`, `ShipmentLine`, `Decimal`, `LifecycleEventEnvelope`.

**Claims — kalan kararlar**

Kaynaklar: [A owner paketi](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/owner-decisions.md), [B owner paketi](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/owner-decisions-v1.0.md) ve R01–R30 uzlaştırması. A veya B’nin bütünü otomatik seçilmiyor.

| Karar | Önerilen exact davranış ve iş etkisi | Acceptance |
|---|---|---|
| **D187-01 — uygunluk/referans** | Dispatched/InTransit/Delivered/Exception/Closed uygun; Draft/Planned/Cancelled değil. Explicit Carrier Shipment’a eşleşmeli; Active/Suspended/Retired tarihsel claim için kabul. Published unfiltered Carrier listesi kullanılır; by-ID endpoint yok. Fresh create gözlem-anı snapshot alır; transition/replay tekrar okumaz. Evidence opaque. | Sekiz Shipment durumu ayrı test. Yanlış Carrier422; missing/foreign404; malformed502; gerekli optional alan eksik503. Kaynak sonradan değişse bile snapshot açıklanabilir; commit-anı uygunluğu garantisi yok. |
| **D187-02 — amount/settlement** | Claimed>0. Approved’a girişte non-null `0≤approved≤claimed`; **sıfır approval kabul**. Diğer hedeflerde non-null approvedAmount422; omission/null eski tutarı silmez. Currency/claimed/source değişmez. Toplam claim tutarı limiti yok. Settled finansal posting değildir. | Claimed0/-0→422. Claimed250 için approved0/250 kabul,250.01 ret. Approved→Settled→Closed tutarı korur; finance/stock çağrısı yok. |
| **D187-03 — decimal/fingerprint** | BSON string + exact coefficient/scale; sabit precision/scale yok. Claims ASCII decimal profili; `[A-Z]{3}` currency, ISO/minor-unit kuralı yok. **Amount ve occurredAt fingerprint’i lexical**; Returns numeric/instant eşitliği kopyalanmaz. | `"250"`→`"250.00"` aynı key’de conflict. Aynı instant farklı datetime metni conflict. Object sırası değişimi replay. Uzun decimal tam korunur; ZZZ ve fractional JPY kabul. |
| **D187-04 — self-approval/izin** | **Görev ayrılığı zorunlu değil:** creator ancak gerekli ayrı grant’lere sahipse approve/settle edebilir. **Withdrawn=`investigate`**, creator-only istisnası yok. Closed=`decide`; yeni close izni yok. | Create-only actor Withdrawn/Approved yapamaz403. Investigate ile Open→Withdrawn200. Creator+decide, Investigating→Approved yapabilir. Settle-only Closed yapamaz403. |
| **D187-05 — conflict/replay** | R17 tercihi: changed payload409 **`IDEMPOTENCY_KEY_REUSED`**; lifecycle422 **`INVALID_CLAIM_TRANSITION`**; root409 `CLAIM_CORRELATION_MISMATCH`. Target-scoped receipt; current authorization zorunlu; yetkili farklı actor replay yapabilir, eski audit actor değişmez. TTL/key reuse yok. | Aynı target/key/root farklı payload409; başka claim target’ında aynı key bağımsız. Wrong-root+changed-payload→root409. Historical receipt sonraki state/soft-delete yüzünden değişmez. |
| **D187-06 — duplicate/concurrency/event** | **Aynı Shipment’a farklı create key’leriyle birden fazla claim serbest**; toplam tutar sınırı yok. `CLM-`+lowercase UUID-N; kesin number collision→atomik503, otomatik renumber yok. Aggregate+receipt+audit+outbox L3; internal CAS. **Worker/publisher yok**, outbox Pending. Causation null; transition zamanı original text. | Farklı key→iki claim; aynı key→tek receipt/event. Approved/Rejected yarışında bir200, diğeri reread sonrası422. Unknown commit503 sıfır kayıt garantisi değildir; aynı key recovery gerekir. |

Claims lifecycle’ın mevcut yedi oku korunur. Tüm49 source×target kombinasyonunda, yetkili ve geçerli payload için yedi geçiş kabul, diğer42 geçiş422 `INVALID_CLAIM_TRANSITION` olmalıdır.

**Birbirine kopyalanmayacak security/replay ayrımları**

| Alan | Returns önerisi | Claims uzlaştırılmış önerisi |
|---|---|---|
| Transition giriş yetkisi | `.transition` base + hedef action | create/investigate/decide/settle’den biri giriş; ardından exact hedef action |
| Withdrawn | Yok | `.investigate` |
| Header–claim scope uyuşmazlığı |404 `RETURN_NOT_FOUND` |403 `FORBIDDEN` |
| Auth/context error code |401/403 `INVALID_REQUEST` |401 `UNAUTHENTICATED`,403 `FORBIDDEN` |
| Decimal/date fingerprint | Numeric / normalize instant | Original lexical text |
| Kapasite/duplicate | Satır entitlement limiti | Duplicate claim serbest; toplam amount limiti yok |

İki profilde de authentication parser reddi401; authentication sonrası unusable/duplicate trusted claim403’tür. “Her duplicate sub mutlaka403” oracle’ı kurulmaz. Header/UUID/query precision kendi profiline göre açık yazılır; ordinary unknown query parametreleri topluca yasaklanmaz.

Önerilen işlem sırası: authentication→trusted scope/base grant→header/query/request validation→hedef izin→receipt root/fingerprint→fresh scoped reference/target→root→business/lifecycle→atomic commit. Returns’ün duplicate/positive local kontrolleri kaynak çağrısından önce kalır.

Consumer root kodları:

| Durum | Returns | Claims |
|---|---|---|
| Missing/null |503 `RETURN_SHIPMENT_ROOT_UNAVAILABLE` |503 `CLAIM_REFERENCE_INCOMPLETE` |
| Malformed |502 `RETURN_SHIPMENT_ROOT_INVALID` |502 `CLAIM_REFERENCE_INVALID` |
| Mismatch |409 `CORRELATION_ROOT_MISMATCH` |409 `CLAIM_CORRELATION_MISMATCH` |

Bu exact eşlemeler consumer adayına bağlanır; yeni root tasarımı veya producer değişikliği açmaz.

**Kopyalanabilir Returns tasarım onayı**

```text
MVP6-RETURNS-CLAIMS-OWNER-DECISION-FINAL-01 kapsamındaki
D186-01…06 önerilerini yalnız Returns consumer amendment
adayının hazırlanması için onaylıyorum.

Tercihler:
- Delivered/Closed eligibility; exact satır/UoM; pozitif miktar;
  ShipmentLine.quantity cap ve immutable entitlement snapshot.
- Requested dahil sayılan durumlar kapasite tüketir;
  yalnız Rejected/Cancelled bırakır; Closed/soft-delete bırakmaz.
- Received yetkili manual assertion’dır.
- Inventory/Warehouse HTTP sıfır; optional reference opaque/unverified.
- Returns’e özgü izin/error/header profili, numeric quantity ve
  normalize-instant fingerprint; scoped durable original-result replay.
- L3 Return+entitlement+receipt+audit+pending outbox; D186-06
  number/collision, recovery ve event-time/causation yaklaşımı.

Önceden onaylı Shipment root kararı uygulanır; bağımsız Return root
önerisi dışlanır. Consumer root hata eşlemeleri bu final tablodaki gibidir.
Başarılı gerçek create için published+implemented+verified Shipment
root seam’i gerekir; candidate/mock sonucu bu gate’i kapatmaz.

Bu onay yalnız consumer amendment candidate hazırlığını açar.
Canonical yayın, producer/runtime uygulaması, Program.cs,
guard binding, consumer consent, Phase1.5, pack promotion ve DEV GO
yetkisi vermez. Tarihsel öneriler değiştirilmez.
```

**Kopyalanabilir Claims tasarım onayı**

```text
MVP6-RETURNS-CLAIMS-OWNER-DECISION-FINAL-01 kapsamındaki
D187-01…06 ve R01–R30 uzlaştırılmış tercihlerini yalnız Claims
consumer amendment adayının hazırlanması için onaylıyorum.

Özellikle:
- Beş durumlu Shipment eligibility; explicit Carrier eşleşmesi;
  Active/Suspended/Retired kabul; fresh-create observation snapshot.
- Claimed>0; 0≤approved≤claimed; sıfır approval kabul;
  diğer hedeflerde non-null approvedAmount ret; tutar retention.
- Duplicate claim farklı key’lerle serbest; toplam claim amount limiti yok.
- Exact decimal/string storage ve lexical amount/occurredAt fingerprint.
- Gerekli grant’lerle creator self-approval yapabilir;
  ek görev ayrılığı/workflow şartı yok.
- Withdrawn=investigate; Closed=decide; yeni close grant yok.
- Payload conflict409=IDEMPOTENCY_KEY_REUSED.
  CLAIM_REPLAY_CONFLICT bu kararın kodu değildir.
- Lifecycle422=INVALID_CLAIM_TRANSITION;
  root409=CLAIM_CORRELATION_MISMATCH.
- Scoped durable receipt, current authorization ve original-result replay.
- L3 dört kayıtlı transaction/internal CAS; CLM-lowercase UUID-N;
  kesin number collision503; unknown-commit receipt recovery.
- Worker/publisher yok; pending outbox, causation null.

Önceden onaylı Shipment root kararı uygulanır.
Published+implemented+verified authoritative seam olmadan gerçek
başarılı create/uptake kabulü verilmez.

R28–R30 scope/verification önerileri runtime dosya yazma veya
Program.cs yetkisi değildir. Bu onay yalnız consumer amendment
candidate hazırlığını açar; canonical yayın, guard binding,
consumer consent, Phase1.5, pack promotion ve DEV GO vermez.
```

**Onay sonrası Returns candidate promptu — şu an HELD**

```text
WP: MVP6-MOD0186-CONSUMER-AMENDMENT-CANDIDATE-01 / v1.0
Rol: contract candidate author
Profil B; HIGH; E1/E2; repository read-only.
Önkoşul: Yukarıdaki exact D186 tasarım onayı verilmiş olmalı.

Repo: /Users/natig/Projects/ERP-vNext-recovery
Branch: feature/mvp6-logistics
Expected HEAD: 4a8d4d4b339528a88e6220fb8402e5a2c771136c

Oku: AGENTS.md, CT SOP, güncel D186 owner paketi, bu final karar
ve gerçek kullanıcı onayı; mevcut canonical ve doğrulanmış root adayı.
Fresh branch/HEAD/dirty ve input hash ölç. Drift varsa raporla.

OWNED: yalnız yeni /private/tmp/mvp6-returns-consumer-candidate-*.
NE: Returns-only amendment patch, normative annex ve fixture paketi.

Yalnız /returns GET/POST ve /returns/{returnId}/transition POST
description/response/example kapsamını ve yalnız bunların kullandığı
yeni modüle özgü response/header bileşenlerini aday kopyasında değiştir.
Shared Decimal/Error/envelope, ShipmentDetail ve diğer operasyonları koru.
Yeni endpoint/alan/lifecycle oku ekleme.

D186-01…06 final tercihlerinin her birini source→decision→diff→test
tablosuna bağla. Bağımsız Return root metnini aday politikaya alma.
Root seam dependency’sini existing producer adayına exact hash ile bağla;
root adayı üretme veya producer patch’ini consumer patch’ine gömme.

Inventory/Warehouse HTTP sıfır; manual Received ve opaque reference;
numeric/instant fingerprint; entitlement/release/concurrency;
root503/502/409 ve transition409 dahil response matrisini örnekle.
Schema/model sonuçlarını runtime/HTTP/JWT/persistence kanıtı sayma.

Canonical baseline root alanını henüz içermiyorsa bunu açık tut:
fixture root verisi yalnız tasarım testidir, publication/uptake değildir.
Published+implemented seam gerçek başarılı create önkoşuludur.

Her davranış farkının compatibility sınıfını ve etkilenen consumer’ları
yaz; metadata major/minor veya eski consent’i otomatik güvence sayma.
Exact patch uygulanabilirliği, refs/examples, negatif fixture’lar,
non-Returns semantic no-change ve input/output SHA256 doğrula.

Çıktı: patch, annex, decision-to-diff, test sonuçları,
compatibility/gate listesi, manifest, SOP §22 ve HELD bağımsız VER promptu.

Canonical/runtime/Program.cs/guard/pack/geçmiş prompt/git değişikliği yok.
Yeni PREP veya root candidate lane’i yok. Publication/DEV GO yok.
```

**Onay sonrası Claims candidate promptu — şu an HELD**

```text
WP: MVP6-MOD0187-CONSUMER-AMENDMENT-CANDIDATE-01 / v1.0
Rol: contract candidate author
Profil B; HIGH; E1/E2; repository read-only.
Önkoşul: Yukarıdaki exact D187 tasarım onayı verilmiş olmalı.

Repo: /Users/natig/Projects/ERP-vNext-recovery
Branch: feature/mvp6-logistics
Expected HEAD: 4a8d4d4b339528a88e6220fb8402e5a2c771136c

Oku: AGENTS.md, CT SOP, iki D187 owner paketi, RECONCILE-01
R01–R30, bu final karar ve gerçek kullanıcı onayı; canonical/root kanıtı.
Fresh branch/HEAD/dirty ve input hash ölç. Drift varsa raporla.

OWNED: yalnız yeni /private/tmp/mvp6-claims-consumer-candidate-*.
Returns lane’inin geçici çıktısına veya ortak canonical dosyaya yazma.

NE: Claims-only amendment patch, normative annex ve fixture paketi.
Yalnız /claims GET/POST ve /claims/{claimId}/transition POST
description/response/example ve modüle özgü yeni response/header
bileşenleri. Shared schemas ve tüm non-Claims operasyonlar korunur.
Yeni endpoint/business alanı/lifecycle oku yok.

R01–R30 source→decision→diff→test crosswalk üret.
Özellikle Withdrawn=investigate, self-approval koşulu,
duplicate claim serbestliği, zero approval ve amount retention,
lexical decimal/date-time fingerprint açık fixture taşımalı.

Payload conflict409=IDEMPOTENCY_KEY_REUSED;
lifecycle422=INVALID_CLAIM_TRANSITION;
root409=CLAIM_CORRELATION_MISMATCH.
Eski CLAIM_REPLAY_CONFLICT/CLAIM_INVALID_TRANSITION kodlarını taşıma.
Claims worker/publisher yok; pending outbox.
Kesin number collision503; unknown commit ayrı receipt recovery.

Mevcut authoritative Shipment root adayını exact hash ile referansla.
ShipmentDetail değiştirme, yeni root candidate üretme.
Seam published+implemented+verified olmadan gerçek create/uptake
kanıtı ileri sürme; synthetic fixture ile gate’i kapatma.

Her R satırının compatibility sınıfını, consumer etkisini ve
owner/consent açıklarını belirt. Claims ASCII profilini shared
Decimal değişikliğiyle diğer modüllere yayma.
49 lifecycle pair, permission/action, receipt/root/payload,
amount ve reference pozitif/negatif oracle’larını aday seviyesinde doğrula.

Çıktı: patch, annex, R01–R30 crosswalk, tests, compatibility/gates,
exact manifest, SOP §22 ve HELD bağımsız VER promptu.
Canonical/runtime/Program.cs/guard/pack/geçmiş prompt/git değişikliği yok.
Yeni PREP veya root candidate lane’i yok. Publication/DEV GO yok.
```

İki consumer adayı ayrı patch olarak kalmalı; sonraki ortak yayın birleşimini CT ayrıca yönetmeli. Bu turda dosya, runtime, canonical veya git değişikliği yapılmadı; candidate lane’leri başlatılmadı.