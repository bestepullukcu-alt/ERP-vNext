Karşılaştırma tamamlandı. **Dosya değiştirilmedi; iki geçmiş set de korundu.** Pack bağlantısı, dosya tarihi veya ayrıntı düzeyi owner onayı sayılmadı.

Aşağıda:

- **A:** [owner-decisions.md](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/owner-decisions.md), SHA-256 `c0e7f0f62cfb4de5e48a25b5bd7fbcdd2e36bd74bdcd88bb44c3176d07c46545`
- **B:** [owner-decisions-v1.0.md](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/owner-decisions-v1.0.md), SHA-256 `8c2022f336e4f7a672f77a2e938a80cd5303b8dd315ccd083d109e150bc0eb72`
- **F:** [Frozen SHIPMENT-BUNDLE](/Users/natig/Projects/ERP-vNext-recovery/docs/analysis/contracts/shipment-bundle.openapi.yaml), metadata `2.0.0`, wire `v1`, SHA-256 `93c696e2fba13dbc8fbfcf2cd1ae0ae0bd93cd9d0935b3ee743229e810163571`

“Ayrıntı eksikliği” karşıt karar değildir; tabloda açıkça ayrıldı.

**1. Fark tablosu — RECONCILE-01 önerisi v1.0**

Uzlaşan hükümleri yeniden tasarlamıyorum: üç Claims operasyonu, frozen lifecycle, tenant/LE izolasyonu, opaque evidence, pozitif claimed amount, `0 ≤ approved ≤ claimed`, kayıpsız decimal yaklaşımı, dört kayıtlı atomik işlem ve finansal posting üretmeyen settlement korunuyor. Bunların draft business önerileri hâlâ onaysızdır.

| No / karar | Frozen hüküm | A / B farkı | İş veya güvenlik etkisi | Önerilen tercih | Exact acceptance |
|---|---|---|---|---|---|
| **R01 / D01 — Shipment uygunluğu** | Shipment status enum’u var; Claims eligibility kümesi yok. | **A:** Dispatched/InTransit/Delivered/Exception/Closed kabul. **B:** “eligible” bırakılmış. | Hangi sevkiyata claim açılabileceği belirlenir. | A’nın beşli kümesi; draft business kararı olarak açık onay. | Sekiz durum ayrı denenir: beşi kabul; Draft/Planned/Cancelled → `422 CLAIM_SHIPMENT_INELIGIBLE`, dört koleksiyonda sıfır yeni kayıt. |
| **R02 / D01 — Carrier eşleşmesi ve tarihsel durum** | Nullable carrier; Carrier listesi mevcut, by-ID GET yok. | **A:** tam eşleşme, Active/Suspended/Retired kabul. **B:** eşleşme veya ayrıca onaylanacak tarihsel istisna; retired sonucu açık. | Belirsiz istisna yanlış taşıyıcıya claim bağlayabilir. | A; eşleşmeme istisnası yok. Omitted/null carrier’dan taşıyıcı türetilmez. | Explicit matching üç Carrier durumunda kabul; farklı veya Shipment carrier=null → `422 CLAIM_CARRIER_MISMATCH`; gerekli alan yok → `503 CLAIM_REFERENCE_INCOMPLETE`. |
| **R03 / D01 — Referansın gözlem zamanı** | Okuma şemaları transaction/snapshot sınırı tanımlamıyor. | **A:** yalnız fresh create’te okuma, immutable snapshot/observedAt; transition/replay tekrar okumaz. **B:** karar setinde zaman sınırı yok; prompt replay reread’ini yasaklıyor. | Kaynak sonradan değiştiğinde sonuç deterministik kalır; commit-anı uygunluğu garantisi verilmez. | A’nın **gözlem-anı** politikası açıkça kabul edilsin. | Okumadan sonra Shipment değişse de kaydedilen snapshot açıklanabilir; kaynak kapalıyken mevcut claim transition/replay’i referans okumadan yürür. |
| **R04 / D01 — Referans hata ayrımı** | Create 404/409/422 tanımlı; 502/503 yok. | **A:** missing/foreign404, malformed veya yanlış kimlik502, eksik gerekli veri/timeout503. **B:** yalnız mevcut declared statüler. | Operasyonel arızanın business ret gibi sunulması önlenir; amendment gerekir. | A’nın ayrımı, Claims-only yeni deklarasyonlarla. | Foreign/missing aynı güvenli404; malformed502; incomplete/timeout503; hiçbirinde başarılı mutation kaydı oluşmaz. |
| **R05 / D01 — Evidence ayrıntıları** | Array optional fakat null değil; empty/duplicate string yasaklanmamış. | **A:** omission/[]/empty/duplicate/order açık. **B:** yalnız opaque immutable strings. | Sessiz validator daraltması engellenir. | A’daki şema açıklığı; yeni evidence doğrulama kuralı yok. | Omission ve `[]` kabul; `["","e1","e1"]` korunur; null→400; hiçbir ID “verified” sayılmaz. |
| **R06 / D02 — Approved dışındaki amount ve Closed** | `approvedAmount` optional/nullable; retention belirtilmiyor. | **A:** başka hedefte non-null422; eski amount Settled/Closed’da korunur. **B:** “command conflict”; Closed’ın “new approved amount” ifadesi retention açısından açık değil. | Onaylanan tutarın kapanışta silinmesi veya tekrar değiştirilmesi riski. | A; mevcut amount korunur, yeniden amount gönderilemez. | Approved `"200.00"` → Settled → Closed aynı metni korur. Diğer geçerli hedefe non-null amount → `422 CLAIM_APPROVED_AMOUNT_NOT_ALLOWED`; omission/null tutarı temizlemez. |
| **R07 / D02 — Resolution/note ve ek limitler** | Nullable strings; catalogue/minLength, toplam claim limiti yok. | **A:** empty/null/omission kabul, değişmez ana alanlar, toplam/tier limiti yok. **B:** açık hüküm yok. | Gizli zorunlu reason veya parasal limit yaratılması engellenir. | A’nın sınırlı politikası. | Empty resolution/note kabul ve audit’te korunur; ayrı key’lerle aynı Shipment claim’leri toplam tutar nedeniyle reddedilmez; settlement finance çağrısı yapmaz. |
| **R08 / D03 — Storage ve kapasite** | Decimal string; p/s sınırı yok. | **A:** BSON string + exact coefficient/scale; commit edilemeyen kapasite503. **B:** arbitrary precision fakat exact storage/capacity sonucu açık değil. | Decimal128/.NET decimal daralması ve sessiz rounding engellenir. | A; transport kapasitesi sınırsızmış gibi sunulmaz. | A/P01 uzun decimal restart sonrası birebir; kapasite-failpoint’te truncate/round/sahte success yok. Kesin precommit failure rollback; belirsiz commit R25’e göre çözülür. |
| **R09 / D03 — Decimal lexical profile** | `^-?\d+(\.\d+)?$`; ortak Decimal bileşeni. | **A:** ASCII digits, leading zero/negative zero açık. **B:** regex’e atıf, parser ayrımı açık değil. | Parser’lar arası Unicode/normalizasyon farkı. | Claims’e özgü açık ASCII profil; shared Decimal değiştirilmez. | `"000250.00"` metni korunur; exponent/plus/whitespace/JSON number/non-ASCII digit→400. Claimed `-0`→422; approved `-0` numeric zero olarak kabul. |
| **R10 / D03 — Fingerprint eşitliği** | Canonicalization tanımlı değil. | **A:** decimal/date-time lexical; JSON key/escape farkı önemsiz; nullable omission=null; evidence omission=[]; array sıra/duplicate anlamlı. **B:** imzalı lexical politikaya bırakıyor. | Aynı key’in hangi payload’da replay sayılacağı belirlenir. | A’nın açık kuralları. | `"250"`→`"250.00"` conflict; aynı instant farklı occurredAt metni conflict; object order değişikliği replay; evidence reorder conflict. |
| **R11 / D04 — Withdrawn izni** | `Open→Withdrawn` var; permission belirtilmiyor. | **A:** `supplychain.claims.create`. **B:** `supplychain.claims.investigate`. | A, yalnız create grant’i olan aktöre aynı scope’taki claim’i geri çekme yetkisi verir; creator-only sınırı yok. | **B: investigate.** Yeni creator-only istisna eklenmesin. | Open claim: yalnız create→403; yalnız investigate→200 Withdrawn; başka tenant/LE→404; retlerde sıfır mutation. |
| **R12 / D04 — Closed ve geçersiz Open hedefi** | Closed’a iki arrow var; Open’a geçiş yok. | **A:** Closed=decide; Open için create kontrolü ardından422. **B:** Closed=decide veya yeni close; Open map’i yok. | Yeni permission icadı ve kapsanmayan target belirsizliği. | A; yeni `close` key yok. Open map’i yalnız hata precedence içindir, geçiş yetkisi değildir. | settle-only aktör Closed→403; decide ile iki legal closure200. Create grant’iyle Open target→`422 INVALID_CLAIM_TRANSITION`. |
| **R13 / D04 — Self-approval** | Actor separation/workflow/tier yok. | **A:** gereken grant’ler varsa creator ilerletebilir. **B:** “self-approval ... invented değil” ifadesi izin/yasak sonucunu belirlemiyor. | Görev ayrılığı açısından gerçek business/security tercihi. | A’nın açık önerisi; business/security owner özellikle imzalamalı. | Creator + create-only approve edemez403; creator + decide, Investigating→Approved yapabilir. Ayrı workflow/rol/limit türetilmez. |
| **R14 / D05 — JWT/header/query parsing** | Bearer, server scope, UUID correlation ve key1–128 var; ayrıntılar yok. | **A:** exact claim adları, duplicate/nil, scope header, Unicode scalar/key, query enjeksiyon politikası var. **B:** owner parser kararına bırakıyor. | Kimlik/scope belirsizliği ve parser bypass riski. | A’nın D05 parser profili, explicit security onayıyla. | Invalid JWT401; duplicate trusted identity403; malformed scope header400/mismatch403; duplicate correlation/key400; 128 scalar kabul,129 ret; scalar comma korunur; altı scope-query alias’ı400. |
| **R15 / D05 — Hata önceliği ve trace** | Genel precedence/fallback response-header politikası yok. | **A:** ayrıntılı sıra; invalid header için rejection-only trace; body/header correlation eşit. **B:** sonuç owner’a bırakılmış. | Yetkisiz kullanıcıya referans varlığının sızması; replay/root karışması. | A’nın sırası; exact target grant’i R11 ile investigate olarak düzeltilir. | Invalid token+badbody401; yetkisiz action+mevcut/olmayan referans aynı403. Found receipt’te wrong-root+changed-body→root409. Error `error.correlationId` response header ile eşit. |
| **R16 / D05 — Transition conflict 422/409** | Transition yalnız200/404/422; create409 mevcut. Pack §23 de çatışmayı422’ye gizlememeyi söylüyor. | **A:** replay/root conflict409 amendment. **B:** transition conflict422. | Business lifecycle hatası ile idempotency/root çatışması ayrılır; yeni response yetkisi gerekir. | **A’nın409 amendment yaklaşımı.** Yayın öncesi runtime409 yetkisi yok. | Aynı root/key farklı payload→409; farklı root→409; fresh-key yasak lifecycle→422. Üç sonuç ayrı fixture. |
| **R17 / D05 — Error code uyumu** | Lifecycle description ve örnek: **`INVALID_CLAIM_TRANSITION`**. Conflict örneği: `IDEMPOTENCY_KEY_REUSED`. | **A:** `CLAIM_INVALID_TRANSITION`, `CLAIM_REPLAY_CONFLICT` ve18 mesajlık tablo. **B:** frozen code yaklaşımı, tam matrix yok. | A’da lifecycle kodu frozen hükümle doğrudan uyuşmuyor. | **Frozen lifecycle kodunu koru.** Replay için mevcut `IDEMPOTENCY_KEY_REUSED` örneğini Claims politikasına açıkça bağla. A’nın diğer güvenli mesaj/code önerileri candidate’ta kalsın. | Yasak arrow422/`INVALID_CLAIM_TRANSITION`; changed payload409/`IDEMPOTENCY_KEY_REUSED`; root409/`CLAIM_CORRELATION_MISMATCH`. Foreign modül business kodu yok. |
| **R18 / D05 — Tam response matrisi** | GET200; create201/404/409/422; transition200/404/422. | **A:** 400/401/403/415/500/502/503 kapsamı. **B:** mevcut deklarasyonlarla sınırlı. | Auth/dependency/storage arızalarını yanlış statüye sıkıştırmama; compatibility incelemesi gerekir. | A’nın operasyon bazlı matrisi, R17 kod düzeltmeleriyle candidate olarak. | GET:200/400/401/403/500/503. Create:201/400/401/403/404/409/415/422/500/502/503. Transition:200/400/401/403/404/409/415/422/500/503. Her dalın exact Error/header örneği doğrulanır. |
| **R19 / D05 — Receipt scope ve farklı target** | Key uzunluğu var; scope tuple yok. | **A:** tenant+LE+operation+target+key. **B:** farklı target’ı conflict kapsamına alıyor; tuple belirsiz. | Key’in modül genelinde mi target başına mı tekil olduğu değişir. | A’nın target-scoped tuple’ı. | Aynı key iki ayrı claim transition’ında bağımsızdır; aynı target/key değişen payload409. Create’te farklı shipmentId aynı create/key payload conflict409’dur. |
| **R20 / D05 — Actor, retention ve tarihsel replay** | Actor/TTL/deletion sonrası replay tanımlı değil. | **A:** current authorized farklı actor replay; eski actor korunur; TTL yok; state/deletion sonrası eski receipt. **B:** orijinal success var, ayrıntılar yok. | Yetki iptali ve geçmiş veriye erişim sınırı; audit bütünlüğü. | A; current auth/scope her replay’de zorunlu. | Grant’i kaldırılan actor403; yetkili farklı actor aynı receipt’i alır, audit actor değişmez; sonraki Closed/soft-delete original response’u değiştirmez; foreign scope receipt okuyamaz. |
| **R21 / D05 — Shipment root erişimi** | Webhook Shipment→Load→POD→Return/Claim boyunca aynı ilk root’u ister. ShipmentDetail/Summary root sunmaz. | **A:** GAP + önerilen `lifecycleCorrelationId` producer alanı. **B:** root korunur der, erişim seam’ini kapatmaz. | Claim root’unun uydurulması chain bütünlüğünü bozar. | GAP açık kalsın. **Producer alanı Claims-only candidate’a eklenmesin.** Ayrı Shipment owner seam kararı gerekir. | Mevcut contract ile authoritative root elde edilemiyorsa fresh create503/zero-write; iç DB/response trace/ID türetmesi kullanılmaz. Başarılı uptake ancak ayrıca yayımlanmış seam ile kanıtlanır. |
| **R22 / D06 — ClaimNumber/collision** | Server number string; `CLM-2026-001` örnek, zorunlu format değil. | **A:** `CLM-`+lowercase UUID-N, reuse yok. **B:** format ve collision retry açık. | Numara semantiği ve tekillik belirlenir. | A formatı. **Ek açık öneri:** kesin unique-number collision’da otomatik sessiz yeniden numaralama yerine atomik503; unknown commit ayrı R25. | Pattern `^CLM-[0-9a-f]{32}$`; scoped uniqueness; soft-delete sonrası reuse yok; forced number collision→503 ve yeni kısmi kayıt yok. |
| **R23 / D06 — Duplicate claim** | One-claim-per-Shipment kuralı yok. | **A:** farklı key’lerle serbest; no sum cap. **B:** owner başka kural seçmezse serbest. | Koşullu default yerine exact business kararı gerekir. | A: açıkça serbest. | Aynı shipment, farklı create key’leri→iki claim; aynı key→tek başarılı receipt/event. |
| **R24 / D06 — CAS ve mimari istisnalar** | Client version/If-Match yok; frozen açıklama idempotent command+current-state kontrolü öngörüyor. | **A:** internal CAS, exact indexes, specific repository ve immutable audit/versioning exception. **B:** transaction var, bu ayrıntılar yok. | Yarışların seri lifecycle sonucu vermesi; mimari approval gerekir. | A, yalnız internal atomiklik aracı; yeni public optimistic-concurrency protokolü yok. | Investigating’den concurrent Approved/Rejected: bir200, diğer reread sonrası422; bir yeni success receipt/event. DTO/header’a version eklenmez. |
| **R25 / D06 — Unknown commit** | HTTP durumunun tek başına atomiklik kanıtı olması öngörülmüyor. | **A:** receipt çözümü, çözülemezse503/same-key recovery. **B:** receipt lookup var; unresolved sonuç açık değil. | Belirsiz commit’i yanlış “rollback oldu” sunma riski. | A; **503, sıfır kayıt garantisi değildir** when commit outcome unknown. | Postcommit response loss sonrası replay tek receipt’i bulur. Unresolved outcome503; tekrar aynı key ile en çok bir mutation; kör insert yok. |
| **R26 / D06 — Event zamanı/causation** | Date-time offsets, event/root alanları var; server zamanı/causation seçimi yok. | **A:** create serverUTC; transition orijinal occurredAt; causation=null; ayrı audit zamanları. **B:** açık değil. | Zaman sıralaması/precision ve yanlış causation üretimi. | A; geçmiş/gelecek business cutoff eklenmez. | Offset/fractional text korunur; create serverUTC; stable eventId/root; causation null; replay yeni event oluşturmaz. |
| **R27 / D06 ve promptlar — Worker** | Event envelope, worker/transport yetkisi değildir. | **A:** dosya listesi/Phase1.5’te optional local worker, fake transport. **B:** açıkça publisher/worker yok; Pending outbox. | Bounded persistence scope’unun delivery scope’una genişlemesi. | **B: worker yok.** Pending outbox + test-only inspection/fault harness yeterli. | Hosted Claims worker kaydı veya `ClaimOutboxWorker.cs` implementation yok; restart sonrası outbox Pending; hiçbir remote publish yok. |
| **R28 / DEV — Exact scope/composition** | Frozen contract source dosya yetkisi vermez. | **A:**48 exact path, ayrıntılı Program sınırı. **B:** eski pack§25’te43 path; genel separate release. | İki prompt farklı dosya kapsamı açıyor; ikisinde de listelenen worker B’nin yasağıyla çelişiyor. | A’nın beş ek helper/test yolu korunabilir; **worker çıkarılarak47 prospective path**. Program için ayrı single writer, worker registration hariç A sınırı. | Onay sonrası scope diff’i yalnız beş ek path + worker çıkarılması; `/claimsXYZ` Claims’e girmez; Shipment/Carrier/Loads branch ve shared outbox değişmez. |
| **R29 / VER ve authority — Aktivasyon/evidence** | Pack draft; hiçbir metin tarih/bağlantıyla onaylanmaz. | **A:** exact baseline/hash,31 scenario family,49 pair,20-way race, explicit regressions. **B:** A01–A12/general edges; explicit no operational Mongo27017. | Eski baseline ile dispatch veya sınırlı testin acceptance sayılması. | A’nın somut test/manifest kapsamı + B’nin explicit operational-DB yasağı; no worker ve R11/R17 düzeltmeleriyle. | Yeni sürüm prompt fresh exact hashes alır; iki eski set HELD kalır;49 pair/20-way race ve Shipment/Carrier/Loads regresyonları izlenir; disposable isolated DB dışında bağlantı yok. |
| **R30 / amendment disposition** | Frozen statü/code/schema ve davranışlar authority’dir; ortak örnekler her modüle otomatik policy vermez. | **A:** signed semantics/amendment/publication/uptake açık gate. **B:** bazı wire-visible business/number/duplicate değişikliklerini “clarification” kabul etmeye yatkın. | Davranış güçlendirmesinin compatibility incelemesinden kaçması. | Her fark için **clarification/additive/behavioral strengthening** ayrı disposition; field değişmedi diye risksiz sayılmaz. | Her R satırı old→proposed oracle ve etkilenen consumer listesi taşır; sınıflandırılmamış fark publication’a ilerleyemez. |

R22’deki collision sonucu iki eski metinde de tamamlanmış değildi; yukarıdaki503 tercihi **yeni ve açık bir uzlaştırma önerisidir**, mevcut karar diye sunulmuyor.

**Shipment root GAP’i ayrıca:** Mevcut F root zincirini zorunlu tutuyor fakat okuma erişimini sağlamıyor. `lifecycleCorrelationId` yalnız A’nın alan önerisidir. Claims-only candidate root gereksinimini ve fail-closed davranışı belgeleyebilir; Shipment schema/producer değiştiremez, GAP’i kapatamaz. Bu eksiklik runtime GO’yu bloke eder; Claims-only adayın hazırlanmasını tek başına engellemez.

**2. Altı kararı kapsayan tek önerilen owner onay metni**

Aşağıdaki metin **imzasız taslaktır; mevcut owner consent değildir**:

> **MVP6-MOD0187-PROPOSAL-RECONCILE-01 v1.0 — karar taslağı**
>
> İnceleme girdileri yukarıdaki exact A/B/F hash’leridir. Tercihler bu sohbetin R01–R30 satırlarına bağlıdır; A veya B bütünü otomatik onaylanmaz.
>
> - **D187-01:** R01–R05: Shipment eligibility kümesi, istisnasız Carrier eşleşmesi/tarihsel durumlar, gözlem-anı snapshot, güvenli referans hata ayrımı ve opaque evidence politikası.
> - **D187-02:** İki setin ortak amount sınırları ve finansal posting üretmeyen settlement yaklaşımı korunarak R06–R07: approved amount retention, diğer hedeflerde non-null amount reddi, resolution/note ve ek limit politikası.
> - **D187-03:** R08–R10: kayıpsız BSON string/exact comparison, Claims ASCII lexical profili ve exact fingerprint eşitlikleri. Yeni precision/scale veya ISO/minor-unit kısıtı yok.
> - **D187-04:** R11–R13: Withdrawn=`supplychain.claims.investigate`; Closed=`supplychain.claims.decide`; yeni close key yok. Creator yalnız gerekli grant’lere sahipse ilerleyebilir; ek görev ayrılığı/workflow kuralı bu bounded scope’a eklenmez.
> - **D187-05:** R14–R21: parser/precedence/trace/receipt politikası, transition conflict için amendment sonrası409; invalid lifecycle için422/**INVALID_CLAIM_TRANSITION**; changed payload için409/**IDEMPOTENCY_KEY_REUSED**. Shipment root erişimi ayrı owner GAP’i olarak açık kalır.
> - **D187-06:** R22–R27: exact number/collision ve duplicate politikası, dört kayıtlı atomiklik/internal CAS, unknown-commit recovery ve event-time politikası. **Claims worker/publisher yok; outbox Pending kalır.**
>
> R28–R30 gelecekteki kapsam/verification/amendment disposition önerisidir; bu kararlar tek başına Phase1.5, repository exception, Program.cs lease veya runtime dosya yazma yetkisi sağlamaz.
>
> Bu tercihler açıkça onaylandığında yalnız aşağıdaki **Claims-only amendment-candidate** çalışması başlatılabilir. Canonical yayın, guard binding aktivasyonu, Shipment producer değişikliği, pack promotion ve DEV/VER dispatch ayrıca yetkilendirilir. Eski iki set değiştirilmez.
>
> Her D187 satırı için karar: **[APPROVED / REJECTED / NEEDS-AMENDMENT]**.  
> Yetkili ad/rol, kapsadığı D187 satırları, tarih ve kanıt referansı: **[owner tarafından doldurulur]**.

Business/finance, security, contract/Shipment ve data/architecture yetkileri aynı kişide değilse ilgili satırlar ayrı yetkili tarafından sahiplenilmelidir; CT adına imza varsayılmıyor.

**3. Onay sonrası Claims-only amendment-candidate promptu**

```text
WP: MVP6-MOD0187-CLAIMS-AMENDMENT-CANDIDATE-01
Prompt: v1.0 — OWNER DECISIONS PENDING / NOT DISPATCHED
Rol: contract candidate author
Profil: candidate-only; repository ve frozen girdiler salt-okunur
Risk: HIGH

ÖNKOŞUL
RECONCILE-01 v1.0 R01–R30’a bağlı D187-01…06 için
attributable owner kararları mevcut olmalı.
Eksik/koşullu/reddedilmiş kararın davranışını varsayma.
Bu promptun sohbette bulunması dispatch veya consent değildir.

GİRDİ
A owner-decisions.md:
c0e7f0f62cfb4de5e48a25b5bd7fbcdd2e36bd74bdcd88bb44c3176d07c46545
B owner-decisions-v1.0.md:
8c2022f336e4f7a672f77a2e938a80cd5303b8dd315ccd083d109e150bc0eb72
Frozen YAML:
93c696e2fba13dbc8fbfcf2cd1ae0ae0bd93cd9d0935b3ee743229e810163571

Fresh branch/HEAD/dirty baseline, pack ve iki HELD setinin hash’lerini al.
Drift varsa önce exact input disposition yap; eski hash’e onay taşıma.

NE
Yalnız onaylanan Claims davranışları için reviewable amendment adayı üret.
Canonical dosyaya uygulama; runtime geliştirme yapma.

OWNED
Yalnız yeni /private/tmp/mvp6-mod0187-amendment-candidate-* dizini.
Repo, geçmiş PREP dosyaları ve frozen girdilere yazma.

İZİNLİ ADAY DIFF
- /claims GET ve POST operation açıklamaları/responses/examples.
- /claims/{claimId}/transition POST açıklamaları/responses/examples.
- Yalnız bu operasyonların kullandığı yeni Claims-specific response/header
  bileşenleri; mevcut shared bileşenleri değiştirme.
- Ayrı Claims normative semantics annex adayı.
- Decision-to-diff, compatibility, test ve unresolved GAP kayıtları.

Shared Decimal/Error/LifecycleEventEnvelope, ShipmentDetail/Summary,
Shipment/Carrier/Loads/Returns operasyonları ve eski annex’ler değişmez.
Yeni request/response business alanı, route veya lifecycle arrow ekleme.
Root alanını Shipment schema’ya bu WP içinde ekleme.

NASIL
1. İmzalı D187 kararlarını R01–R30’a ve exact proposal hash’lerine bağla.
2. Claims response matrix, parser/precedence, amount/reference semantics,
   permissions ve replay politikasını candidate açıklama/annex’ine işle.
3. Withdrawn=investigate.
   Lifecycle422=INVALID_CLAIM_TRANSITION.
   Payload conflict409=IDEMPOTENCY_KEY_REUSED.
   Root conflict409=CLAIM_CORRELATION_MISMATCH.
   Worker/publisher yok; outbox Pending.
4. Shipment authoritative root erişimini ayrı OPEN/BLOCKED dependency
   GAP olarak tut. İç DB, trace header veya başka alandan root türetme.
   lifecycleCorrelationId’yi yayımlanmış alanmış gibi kullanma.
5. Her davranış farkını clarification/additive/behavioral strengthening
   olarak gerekçelendir; metadata/release version önerisini ayrı raporla.
   Wire v1’i değiştirme; release-specific eski onayı tekrar kullanma.
6. Affected consumer listesi ve named owner boşluklarını kaydet.
   Draft design review’u runtime acceptance veya external inventory
   tamamlanması sayma.

DOĞRULA
- OAS3.1 refs ve Claims request/response/error/header örnekleri.
- R01–R30 için old/proposed positive ve negative oracle’lar.
- Frozen invalid-lifecycle code korunması; transition409’un yalnız
  candidate deklarasyonu olması.
- Root seam yokluğu: dependency BLOCKED; synthetic root verisi
  gerçek producer/mock uptake kanıtı değildir.
- Claims dışı AST kapsamı ve özgün frozen dosyaların hash değişmezliği.
- Exact candidate diff ve artifact SHA-256 manifest’i.

ÇIKTI
candidate.patch
claims-semantics-candidate.md
decision-to-diff.md
compatibility-and-consumer-gaps.md
verification-report.md
manifest.sha256
SOP §22 raporu

YAPMA
Canonical yayın/activation, gerçek guard/policy/manifest binding,
insan onayı yaratma, pack veya HELD prompt değiştirme,
Program.cs/runtime/scaffold, Shipment producer/ingress,
diğer modüller, finance posting, git mutation/commit/push/stash.

VERDICT
Yalnız candidate validation sonucu.
Publication, root seam closure, production gate PASS,
pack promotion veya runtime GO değildir.
```

**4. Eski taslakların hangi maddeleri değişecek?**

Buradaki “değişecek”, **ileride yeni sürümde yerini alacak** anlamındadır; mevcut dosyalara uygulanmadı.

| Eski taslak | Yeni önerinin yerini alacağı maddeler |
|---|---|
| **A karar seti** | D04 Withdrawn/S01 → **investigate**. D04 S03 ve D05 error tablosundaki lifecycle code → **INVALID_CLAIM_TRANSITION**. D05 replay code → **IDEMPOTENCY_KEY_REUSED**. D06 collision sonucu R22 ile kesinleşir. Worker ihtimali kalkar. Root alanı önerisi Claims candidate dışındaki ayrı GAP olarak kalır. Diğer ayrıntılar tabloda açıkça seçildiği ölçüde korunur. |
| **B karar seti** | D01’deki eligible/historical-exception açıklıkları → R01–R05. D02 amount-retention/“command conflict” → R06–R07. D03 storage/fingerprint açıklıkları → R08–R10. D04 optional close/self-approval açıklıkları → R12–R13; **Withdrawn=investigate korunur**. D05 transition422-conflict ve farklı-target yaklaşımı → R16/R19; parser/root/receipt açıklıkları → R14–R21. D06 format/collision/CAS/time açıklıkları → R22–R26; **no-worker korunur**. |
| [A DEV](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/dev-held-v1.0.md) ve bağlı scope |48 yol yerine worker çıkarılmış47 prospective yol; düzeltilmiş permission/code oracle’ları; local worker registration yok. Root producer çalışması ayrı ve engelleyici kalır. |
| [A VER](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/ver-held-v1.0.md) | R11/R17/R22/R25/R27 oracle’ları güncellenir; fake delivery doğrulaması yerine Pending durability; operational DB yasağı açıklaştırılır. |
| [B DEV](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/dev-prompt-v1.0-HELD.md) | Eski §25-only dosya referansı yerine gelecekte onaylanacak47 exact yol; “yeni status icat etme” korunur fakat **onaylı/yayımlanmış amendment409** açıkça ayrılır; exact karar/hash ve root GAP gates eklenir. |
| [B VER](/Users/natig/Projects/ERP-vNext-recovery/docs/roadmap/plans/mod-0187-prep-02/ver-prompt-v1.0-HELD.md) | Genel coverage, A’nın49 pair/20-way race/exact snapshot kapsamıyla somutlaştırılır; düzeltilmiş kod/izin/receipt sonuçları bağlanır. “Malformed evidence” testi evidence-record doğrulamasına dönüşmez: opaque request shape ve test manifest bütünlüğü ayrı tutulur. |
| [MOD-0187 pack](/Users/natig/Projects/ERP-vNext-recovery/execution/domains/supply-chain-execution/module-packs/MOD-0187-claims-management.md) | §28’in A’ya bağlantısı onay değildir. İleride yeni decision referansı gerekebilir; §25/26/27 worker/scope ve tarihsel readiness ifadeleri yeni yetkili sürümde uzlaştırılır. Bu salt-okunur görevde değiştirilmez. |

**Mevcut durum:** İki set UNAPPROVED; tüm DEV/VER taslakları HELD; pack draft. Owner consent, canonical yayın, promotion veya runtime GO üretilmedi.