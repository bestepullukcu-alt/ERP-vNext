using MongoDB.Bson;using MongoDB.Driver;
namespace Diten.SupplyChainService.Persistence.Features.SandopPlans;
public static class SandopSchema
{ public static async Task EnsureAsync(IMongoDatabase db,CancellationToken ct=default)
{
 static CreateIndexModel<BsonDocument> Ix(string name,bool unique,params string[] fields)=>new(Builders<BsonDocument>.IndexKeys.Combine(fields.Select(x=>Builders<BsonDocument>.IndexKeys.Ascending(x))),new CreateIndexOptions{Name=name,Unique=unique,Collation=Collation.Simple});
 await db.GetCollection<BsonDocument>("sandop_plans").Indexes.CreateOneAsync(Ix("sandop_active_horizon_demand",true,"TenantId","LegalEntityId","IsDeleted","HorizonStart","HorizonEnd","DemandPlanId","DemandPlanVersion"),cancellationToken:ct);
 await db.GetCollection<BsonDocument>("sandop_snapshots").Indexes.CreateOneAsync(Ix("sandop_snapshot_sequence",true,"TenantId","LegalEntityId","PlanId","Sequence"),cancellationToken:ct);
 await db.GetCollection<BsonDocument>("sandop_sign_offs").Indexes.CreateOneAsync(Ix("sandop_role_snapshot",true,"TenantId","LegalEntityId","IsDeleted","SnapshotId","Role"),cancellationToken:ct);
 await db.GetCollection<BsonDocument>("sandop_receipts").Indexes.CreateOneAsync(Ix("sandop_receipt_identity",true,"TenantId","LegalEntityId","Operation","TargetId","Key"),cancellationToken:ct);
 await db.GetCollection<BsonDocument>("sandop_audit").Indexes.CreateOneAsync(Ix("sandop_audit_scope",false,"TenantId","LegalEntityId","PlanId"),cancellationToken:ct);
 await db.GetCollection<BsonDocument>("sandop_outbox").Indexes.CreateOneAsync(Ix("sandop_outbox_scope",false,"TenantId","LegalEntityId","Status"),cancellationToken:ct);
} }
