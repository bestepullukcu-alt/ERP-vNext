using MediatR;
using System.Text.Json.Nodes;
using Diten.SupplyChainService.Application.Common;
using Diten.SupplyChainService.Application.Features.Shipments.Queries;
using Diten.SupplyChainService.Domain.Features.Shipments;
namespace Diten.SupplyChainService.Application.Features.Shipments.Handlers.QueryHandlers;
public sealed class GetShipmentByIdHandler(IShipmentRepository repository, RequestContext context) : IRequestHandler<GetShipmentByIdQuery, Response<JsonObject>>
{
    public async Task<Response<JsonObject>> Handle(GetShipmentByIdQuery request, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(request);
        var detail = await repository.GetDetailAsync(context.Scope, request.ShipmentId, ct);
        if (detail is null) return Response<JsonObject>.Fail("SHIPMENT_NOT_FOUND", 404);
        if (detail.RootState == RawRootState.InvalidStoredValue)
            return Response<JsonObject>.Fail("SHIPMENT_ROOT_INVALID", 500);
        return Response<JsonObject>.Success(ShipmentProjection.Detail(detail));
    }
}
