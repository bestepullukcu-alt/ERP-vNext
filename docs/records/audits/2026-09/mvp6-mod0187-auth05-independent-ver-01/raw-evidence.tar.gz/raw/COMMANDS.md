# Sanitized command ledger

Secrets and bearer tokens are intentionally omitted. The API launch commands read an ephemeral secret from `runtime.secret`; that file was deleted before archiving.

| Step | Command (sanitized) | Exit/result |
|---|---|---|
| Source | Copy writer source without `.git`/`bin`/`obj`/evidence; overlay `integration-source-baseline.tar.gz`; verify `source-manifest.tsv` | 97/97 match |
| Restore | `dotnet restore services/Diten.SupplyChainService/Diten.SupplyChainService.sln --disable-parallel -v minimal` | 0 |
| Build | `dotnet build services/Diten.SupplyChainService/Diten.SupplyChainService.sln -c Debug --no-restore -m:1 /nr:false` | 0 |
| Broad filter attempt | `dotnet test ... --filter FullyQualifiedName~Claims` | 1; filter also selected Carrier/Loads methods containing “Claims” and the explicit restart-only test; retained as harness evidence |
| Exact core | `dotnet test ... --filter 'FullyQualifiedName~Diten.SupplyChainService.Tests.Claims.&FullyQualifiedName!~Receipt_TwoIndependentTestProcesses_DurableRecovery'` | 0; 120/120 |
| Mongo | `mongod --config .../mongo/mongod.conf`; replica set `claims_auth05_ind`, port 27917 | primary true |
| First API | fresh API DLL; port 5067; DB `diten_claims_auth05_ind`; Claims reference base URL self | started/stopped cleanly |
| Main probe | `python3 authenticated_probe.py` | 0 |
| Concurrency probe | `python3 concurrency_probe.py` | 0 |
| Failure API | same DLL; Claims reference base URL `127.0.0.1:59998` | started/stopped cleanly |
| Failure probe | `python3 failure_probe.py` | 0 |
| Restart API | same DLL/DB; Claims reference base URL self | started/stopped cleanly |
| Restart probe | `python3 restart_probe.py` | 0 |
| JWT negative | missing Authorization and malformed bearer against GET `/claims` | 401 / 401 |
| Cleanup | stop API processes; `db.shutdownServer({force:true})`; delete ephemeral secret | listeners absent; secret absent |

