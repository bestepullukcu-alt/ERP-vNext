#!/usr/bin/env python3
import importlib.util,json,os
from pathlib import Path
from uuid import uuid4
spec=importlib.util.spec_from_file_location('base',Path(__file__).with_name('authenticated_probe.py'));base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
def main():
 db=os.environ['CLAIMS_TEST_DB'];t,l,a,s,r=uuid4(),uuid4(),uuid4(),uuid4(),uuid4();item,sku=uuid4(),uuid4()
 doc={"_id":str(s),"TenantId":str(t),"LegalEntityId":str(l),"IsDeleted":False,"CreatedAt":{"$date":"2026-09-21T12:00:00Z"},"Version":1,"ShipmentNumber":"SHP-FAIL","SourceModule":"MOD-0141","SourceType":"SALES_ORDER","SourceDocumentId":"SO-F","WarehouseReferenceId":"WH-F","ShipToReference":"C-F","Lines":[{"LineNumber":"1","ItemId":str(item),"SkuId":str(sku),"Quantity":"1","UomId":"EA"}],"PlannedShipAt":{"$date":"2026-09-20T08:00:00Z"},"Status":"Delivered","CorrelationId":str(uuid4()),"LifecycleCorrelationId":str(r)}
 text=json.dumps(doc).replace('{"$date": "2026-09-21T12:00:00Z"}','new Date("2026-09-21T12:00:00Z")').replace('{"$date": "2026-09-20T08:00:00Z"}','new Date("2026-09-20T08:00:00Z")');base.mongo(f'db.getSiblingDB({json.dumps(db)}).sce_shipments.insertOne({text})')
 tok=base.jwt(t,l,a,["supplychain.claims.read","supplychain.claims.create","supplychain.shipments.read"]);body={"shipmentId":str(s),"reasonCode":"DAMAGED","claimedAmount":"1.00","currency":"USD","evidenceReferenceIds":[]};resp=base.request('POST','/api/shipment-bundle/claims',tok,t,l,r,'auth05-failure',body)
 q=json.dumps({"TenantId":str(t),"LegalEntityId":str(l)});counts=json.loads(base.mongo(f'const d=db.getSiblingDB({json.dumps(db)});const q={q};JSON.stringify({{claims:d.claims.countDocuments(q),receipts:d.claims_receipts.countDocuments(q),audit:d.claims_audit.countDocuments(q),outbox:d.claims_outbox.countDocuments(q)}})'))
 code=((resp.get('body') or {}).get('error') or {}).get('code');ok=resp['status']==503 and code=='CLAIM_REFERENCE_UNAVAILABLE' and all(v==0 for v in counts.values());out={"status":"PASS" if ok else "FAIL","response":resp,"counts":counts,"tokenRecorded":False,"secretRecorded":False};Path(os.environ['CLAIMS_FAILURE_EVIDENCE']).write_text(json.dumps(out,indent=2));print(json.dumps({"status":out['status'],"http":resp['status'],"code":code,"counts":counts}));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
