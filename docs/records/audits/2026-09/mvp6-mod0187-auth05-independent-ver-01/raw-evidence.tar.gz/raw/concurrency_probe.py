#!/usr/bin/env python3
import importlib.util, json, os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from uuid import uuid4

spec=importlib.util.spec_from_file_location("base", Path(__file__).with_name("authenticated_probe.py")); base=importlib.util.module_from_spec(spec); spec.loader.exec_module(base)

def seed(db,tenant,le,shipment,root):
    item,sku=uuid4(),uuid4()
    doc={"_id":str(shipment),"TenantId":str(tenant),"LegalEntityId":str(le),"IsDeleted":False,"CreatedAt":{"$date":"2026-09-21T12:00:00Z"},"Version":1,"ShipmentNumber":"SHP-CONC-"+str(shipment)[:8],"SourceModule":"MOD-0141","SourceType":"SALES_ORDER","SourceDocumentId":"SO-CONC","WarehouseReferenceId":"WH-CONC","ShipToReference":"C-CONC","Lines":[{"LineNumber":"1","ItemId":str(item),"SkuId":str(sku),"Quantity":"1.000","UomId":"EA"}],"PlannedShipAt":{"$date":"2026-09-20T08:00:00Z"},"Status":"Delivered","CorrelationId":str(uuid4()),"LifecycleCorrelationId":str(root)}
    text=json.dumps(doc).replace('{"$date": "2026-09-21T12:00:00Z"}','new Date("2026-09-21T12:00:00Z")').replace('{"$date": "2026-09-20T08:00:00Z"}','new Date("2026-09-20T08:00:00Z")')
    base.mongo(f'db.getSiblingDB({json.dumps(db)}).sce_shipments.insertOne({text})')

def scoped(db,t,l):
    return json.loads(base.mongo(f'const d=db.getSiblingDB({json.dumps(db)});const q={{TenantId:{json.dumps(str(t))},LegalEntityId:{json.dumps(str(l))}}};JSON.stringify({{claims:d.claims.countDocuments(q),receipts:d.claims_receipts.countDocuments(q),audit:d.claims_audit.countDocuments(q),outbox:d.claims_outbox.countDocuments(q)}})'))

def scenario(unique):
    db=os.environ['CLAIMS_TEST_DB']; tenant,le,actor,shipment,root=uuid4(),uuid4(),uuid4(),uuid4(),uuid4(); seed(db,tenant,le,shipment,root)
    perms=["supplychain.claims.read","supplychain.claims.create","supplychain.claims.investigate","supplychain.claims.decide","supplychain.claims.settle","supplychain.shipments.read"]
    token=base.jwt(tenant,le,actor,perms); body={"shipmentId":str(shipment),"reasonCode":"DAMAGED","claimedAmount":"10.00","currency":"USD","evidenceReferenceIds":[]}
    def call(i): return base.request("POST","/api/shipment-bundle/claims",token,tenant,le,root,(f"auth05-unique-{i}" if unique else "auth05-same"),body)
    with ThreadPoolExecutor(max_workers=8) as pool: rows=list(pool.map(call,range(8)))
    ids={(r.get('body') or {}).get('claimId') for r in rows}; counts=scoped(db,tenant,le)
    expected=8 if unique else 1
    return {"statuses":[r['status'] for r in rows],"claimIds":sorted(x for x in ids if x),"counts":counts,"pass":all(r['status']==201 for r in rows) and len(ids)==expected and all(counts[k]==expected for k in counts)}

def permission():
    db=os.environ['CLAIMS_TEST_DB']; tenant,le,actor,shipment,root=uuid4(),uuid4(),uuid4(),uuid4(),uuid4(); seed(db,tenant,le,shipment,root)
    full=base.jwt(tenant,le,actor,["supplychain.claims.read","supplychain.claims.create","supplychain.claims.investigate","supplychain.shipments.read"])
    limited=base.jwt(tenant,le,actor,["supplychain.claims.read","supplychain.claims.create","supplychain.shipments.read"])
    body={"shipmentId":str(shipment),"reasonCode":"DAMAGED","claimedAmount":"10.00","currency":"USD","evidenceReferenceIds":[]}
    created=base.request("POST","/api/shipment-bundle/claims",full,tenant,le,root,"auth05-perm-create",body); cid=created['body']['claimId']; before=scoped(db,tenant,le)
    denied=base.request("POST",f"/api/shipment-bundle/claims/{cid}/transition",limited,tenant,le,root,"auth05-perm-transition",{"targetStatus":"Investigating","occurredAt":"2026-09-21T12:10:00Z"}); after=scoped(db,tenant,le)
    return {"createStatus":created['status'],"denied":denied,"before":before,"after":after,"pass":created['status']==201 and denied['status']==403 and before==after}

def main():
    out={"sameKey":scenario(False),"differentKeys":scenario(True),"missingActionPermission":permission(),"tokenRecorded":False,"secretRecorded":False};out['status']='PASS' if all(v['pass'] for k,v in out.items() if isinstance(v,dict) and 'pass' in v) else 'FAIL';Path(os.environ['CLAIMS_CONCURRENCY_EVIDENCE']).write_text(json.dumps(out,indent=2));print(json.dumps({"status":out['status'],"same":out['sameKey']['counts'],"different":out['differentKeys']['counts'],"permission":out['missingActionPermission']['denied']['status']}));return 0 if out['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
