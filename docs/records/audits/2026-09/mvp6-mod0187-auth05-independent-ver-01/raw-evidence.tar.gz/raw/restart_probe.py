#!/usr/bin/env python3
import base64, hashlib, hmac, json, os, subprocess, time, urllib.error, urllib.request
from pathlib import Path

def b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()

def jwt(source):
    header = b64(b'{"alg":"HS256","typ":"JWT"}')
    payload = b64(json.dumps({
        "sub": source["actorId"], "tenant_id": source["tenantId"],
        "legal_entity_id": source["legalEntityId"], "actor_type": "tenant_user",
        "permission": ["supplychain.claims.read", "supplychain.claims.create", "supplychain.claims.investigate", "supplychain.claims.decide", "supplychain.claims.settle", "supplychain.shipments.read"],
        "iss": os.environ["CLAIMS_JWT_ISSUER"], "aud": os.environ["CLAIMS_JWT_AUDIENCE"],
        "exp": int(time.time()) + 600
    }, separators=(",", ":")).encode())
    signature = b64(hmac.new(os.environ["CLAIMS_JWT_SECRET"].encode(), (header + "." + payload).encode(), hashlib.sha256).digest())
    return header + "." + payload + "." + signature

def request(method, path, token, source, correlation, key=None, body=None):
    headers = {
        "Authorization": "Bearer " + token,
        "X-Tenant-Id": source["tenantId"], "X-Legal-Entity-Id": source["legalEntityId"],
        "X-Correlation-Id": correlation
    }
    raw = None
    if key is not None:
        headers["Idempotency-Key"] = key
    if body is not None:
        raw = json.dumps(body, separators=(",", ":")).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(os.environ["CLAIMS_API_URL"] + path, method=method, data=raw, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            status, response_headers, data = response.status, dict(response.headers), response.read().decode()
    except urllib.error.HTTPError as error:
        status, response_headers, data = error.code, dict(error.headers), error.read().decode()
    return {"status": status, "correlation": response_headers.get("X-Correlation-Id"), "body": json.loads(data) if data else None}

def counts(source):
    database = source["db"]
    query = json.dumps({"TenantId": source["tenantId"], "LegalEntityId": source["legalEntityId"]})
    script = f'''const d=db.getSiblingDB({json.dumps(database)}); const q={query}; JSON.stringify({{claims:d.claims.countDocuments(q),receipts:d.claims_receipts.countDocuments(q),audit:d.claims_audit.countDocuments(q),outbox:d.claims_outbox.countDocuments(q)}})'''
    result = subprocess.run(["mongosh", "--quiet", os.environ["CLAIMS_MONGO_URI"], "--eval", script], text=True, capture_output=True)
    if result.returncode != 0:
        raise RuntimeError("mongo count failed")
    return json.loads(result.stdout)

def main():
    source = json.loads(Path(os.environ["CLAIMS_INITIAL_EVIDENCE"]).read_text())
    token = jwt(source)
    before = counts(source)
    rows = {
        "producer-detail": request("GET", f'/api/shipment-bundle/shipments/{source["shipmentId"]}', token, source, source["root"]),
        "list": request("GET", "/api/shipment-bundle/claims", token, source, source["root"]),
        "replay": request("POST", "/api/shipment-bundle/claims", token, source, source["root"], source["createIdempotencyKey"], source["createBody"])
    }
    after = counts(source)
    items = (rows["list"].get("body") or {}).get("items") or []
    detail = rows["producer-detail"].get("body") or {}
    expected_claim = source["rows"]["create"]["body"]["claimId"]
    checks = {
        "producerDetail200": rows["producer-detail"]["status"] == 200,
        "producerRootSame": detail.get("lifecycleCorrelationId") == source["root"],
        "list200": rows["list"]["status"] == 200,
        "claimPersisted": any(item.get("claimId") == expected_claim for item in items),
        "replay201": rows["replay"]["status"] == 201,
        "replayIdentitySame": (rows["replay"].get("body") or {}).get("claimId") == expected_claim,
        "noReplayWrites": before == after
    }
    output = {"status": "PASS" if all(checks.values()) else "FAIL", "api": os.environ["CLAIMS_API_URL"], "db": source["db"], "sourceEvidenceSha256": hashlib.sha256(Path(os.environ["CLAIMS_INITIAL_EVIDENCE"]).read_bytes()).hexdigest(), "before": before, "after": after, "rows": rows, "checks": checks, "tokenRecorded": False, "secretRecorded": False}
    Path(os.environ["CLAIMS_RESTART_EVIDENCE"]).write_text(json.dumps(output, indent=2))
    print(json.dumps({"status": output["status"], "statuses": {k:v["status"] for k,v in rows.items()}, "checks": checks}))
    return 0 if output["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
