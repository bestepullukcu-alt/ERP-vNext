import copy,hashlib,json,pathlib,subprocess,sys,tempfile,collections
root=pathlib.Path('/Users/natig/Projects/ERP-vNext-recovery')
work=pathlib.Path('/private/tmp/mvp6-sandop-r2-ver01-work')
base=root/'docs/analysis/contracts/sandop-capacity.openapi.yaml'
demand=root/'docs/analysis/contracts/demand.openapi.yaml'
decision=root/'docs/roadmap/plans/mod-0192-executor-exact-decisions-01/DECISION.md'
pkg=root/'docs/records/audits/2026-09/mvp6-sandop-capacity-amendment-r2-01'
yml=pkg/'sandop-capacity.openapi.candidate.yaml'; annex=pkg/'sandop-capacity-semantics-v2.0.0-rc.2.md';patch=pkg/'publication-candidate.patch'
tooldeps=pathlib.Path('/private/tmp/mvp6-combined-final-release-q16pebui/tooldeps');sys.path.insert(0,str(tooldeps))
import yaml,openapi_spec_validator
from openapi_spec_validator.schemas import openapi_v31_schema_validator
from jsonschema import Draft202012Validator,FormatChecker,RefResolver
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'baseline':('c255e92923ba91714cec8daf229262101b5d45648b7f714a03ab402811db683c',base),'demand':('3c77262e411976e311bcf9b65be131e2035fd18a33215d24075f87209f87bb9d',demand),'decision':('cfddf953a1a98107869417ef8afbcad5f578fcfde2a8cad8e1d2b6b05197cc5d',decision),'yaml':('5dc5e9750797ea687fce2e959b17d9b3312231b5701238815cab48e7ca3b661c',yml),'annex':('9f7d87fc72934dc204fb6dffba1a6646ef583dea3c24d996974e716a9add9b20',annex),'patch':('0e1aca53609c2cd137c50882615e65cf1870e37ddad212891decad6f2a0e8835',patch)}
assert all(sha(p)==h for h,p in expected.values())
a=yaml.safe_load(base.read_text());b=yaml.safe_load(yml.read_text())
assert b['openapi']=='3.1.0' and b['info']['version']=='2.0.0-rc.2' and b['info']['x-status']=='CANDIDATE'
assert b['info']['x-semantics-annex']==annex.name and b['info']['x-contract-version']=='v1'
meta=[str(x) for x in openapi_v31_schema_validator.iter_errors(b)]
full=[str(x) for x in openapi_spec_validator.OpenAPIV31SpecValidator(b).iter_errors()]
neg={}
for name,change in [('bad-version',lambda x:x.update(openapi='bad')),('missing-title',lambda x:x['info'].pop('title')),('bad-response-ref',lambda x:x['paths']['/sandop-plans']['post']['responses']['401'].update({'$ref':'#/components/responses/DoesNotExist'}))]:
 m=copy.deepcopy(b);change(m)
 
 try:
  full_count=len(list(openapi_spec_validator.OpenAPIV31SpecValidator(m).iter_errors()))
 except Exception as exc:
  full_count=1
 neg[name]={'meta':len(list(openapi_v31_schema_validator.iter_errors(m))),'full':full_count}
# candidate scope + old response preservation
assert a['servers']==b['servers'] and a['security']==b['security'] and set(a['paths'])==set(b['paths'])
for comp in ('schemas','parameters','headers','securitySchemes'):
 assert a['components'][comp]==b['components'][comp],comp
assert a['components'].get('examples')==b['components'].get('examples')
rows=[]
for path,methods in a['paths'].items():
 for method,old in methods.items():
  new=b['paths'][path][method]; id=old['operationId']; statuses=sorted(new['responses'])
  assert old['operationId']==new['operationId'] and old.get('requestBody')==new.get('requestBody') and old.get('parameters')==new.get('parameters')
  assert all(code in new['responses'] and new['responses'][code]==resp for code,resp in old['responses'].items())
  assert all(code in statuses for code in ('400','401','403','503'))
  assert new['responses']['401']['$ref']=='#/components/responses/Unauthenticated'
  assert new['responses']['503']['$ref']=='#/components/responses/'+('MutationUnavailable' if method=='post' else 'ReadUnavailable')
  rows.append({'id':id,'method':method.upper(),'path':path,'oldStatuses':sorted(old['responses']),'candidateStatuses':statuses,'addedStatuses':sorted(set(statuses)-set(old['responses'])),'response503':new['responses']['503']['$ref']})
assert len(rows)==12 and sum(r['method']=='POST' for r in rows)==6
assert a['components']['schemas']['CapacityEvaluationCompletedEvent']==b['components']['schemas']['CapacityEvaluationCompletedEvent']
assert b['components']['parameters']['IdempotencyKey']['schema']=={'type':'string','minLength':1}
resp=b['components']['responses']
assert resp['ReadUnavailable']['x-error-codes']==['DEPENDENCY_UNAVAILABLE']
assert resp['MutationUnavailable']['x-error-codes']==['DEPENDENCY_UNAVAILABLE','COMMIT_RESULT_UNRESOLVED']
assert {'WWW-Authenticate','X-Correlation-Id'}<=set(resp['Unauthenticated']['headers'])
for id in ('createCapacityScenario','evaluateCapacityScenario'):
 row=next(x for x in rows if x['id']==id);assert b['paths'][row['path']]['post']['responses']['422']['$ref']=='#/components/responses/InvalidConstraintReference'
for id in ('createSandopPlan','captureSandopSnapshot','createCapacityPlan'):
 row=next(x for x in rows if x['id']==id);assert b['paths'][row['path']]['post']['responses']['422']['$ref']=='#/components/responses/InvalidDemandReference'
assert 'checksumMismatch' in resp['InvalidDemandReference']['content']['application/json']['examples']
for key in ('PlanConflict','PlanStateConflict','SignOffConflict','CapacityPlanConflict','CapacityPlanStateConflict','EvaluationConflict'):
 assert 'IDEMPOTENCY_KEY_REUSED' in resp[key]['x-error-codes']
assert 'SANDOP_SIGN_OFF_STATE_CONFLICT' in resp['SignOffConflict']['x-error-codes']
# Independent targeted policy mutants. Each mutation removes one R2 proposition.
policy_mutants={}
for label,change,predicate in [
 ('evaluation-422-removed',lambda x:x['paths']['/capacity-plans/{capacityPlanId}/scenarios/{scenarioId}/evaluations']['post']['responses'].pop('422'),lambda x:'422' in x['paths']['/capacity-plans/{capacityPlanId}/scenarios/{scenarioId}/evaluations']['post']['responses']),
 ('GET-unknown-commit-added',lambda x:x['components']['responses']['ReadUnavailable']['x-error-codes'].append('COMMIT_RESULT_UNRESOLVED'),lambda x:x['components']['responses']['ReadUnavailable']['x-error-codes']==['DEPENDENCY_UNAVAILABLE']),
 ('401-correlation-removed',lambda x:x['components']['responses']['Unauthenticated']['headers'].pop('X-Correlation-Id'),lambda x:'X-Correlation-Id' in x['components']['responses']['Unauthenticated']['headers']),
 ('key-max-length-added',lambda x:x['components']['parameters']['IdempotencyKey']['schema'].update(maxLength=200),lambda x:x['components']['parameters']['IdempotencyKey']['schema']=={'type':'string','minLength':1}),
 ('checksum-example-removed',lambda x:x['components']['responses']['InvalidDemandReference']['content']['application/json']['examples'].pop('checksumMismatch'),lambda x:'checksumMismatch' in x['components']['responses']['InvalidDemandReference']['content']['application/json']['examples'])]:
 m=copy.deepcopy(b);change(m);policy_mutants[label]='REJECTED' if not predicate(m) else 'MISSED'
assert all(v=='REJECTED' for v in policy_mutants.values())
# refs and examples counted as encounters; uniqueness recorded separately
refs=[]
def point(ref):
 assert ref.startswith('#/');o=b
 for k in ref[2:].split('/'):o=o[k.replace('~1','/').replace('~0','~')]
 return o
def walk(o):
 if isinstance(o,dict):
  if '$ref' in o:refs.append(o['$ref']);point(o['$ref'])
  for v in o.values():walk(v)
 elif isinstance(o,list):
  for v in o:walk(v)
walk(b)
resolver=RefResolver.from_schema(b)
example_checks=[]
for path,methods in b['paths'].items():
 for method,op in methods.items():
  for status,response in op['responses'].items():
   resp=point(response['$ref']) if '$ref' in response else response
   for media in resp.get('content',{}).values():
    schema=media.get('schema')
    if not schema:continue
    vals=[('example',media['example'])] if 'example' in media else [(name,v['value']) for name,v in media.get('examples',{}).items()]
    for name,value in vals:
     Draft202012Validator(schema,resolver=resolver,format_checker=FormatChecker()).validate(value)
     example_checks.append({'operation':op['operationId'],'status':status,'name':name,'valueSha256':hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()})
with tempfile.TemporaryDirectory(prefix='sandop-r2-independent-') as td:
 d=pathlib.Path(td)/'docs/analysis/contracts';d.mkdir(parents=True)
 (d/base.name).write_bytes(base.read_bytes())
 check=subprocess.run(['git','apply','--unsafe-paths','-p1','--check',str(patch)],cwd=td,text=True,capture_output=True)
 app=subprocess.run(['git','apply','--unsafe-paths','-p1',str(patch)],cwd=td,text=True,capture_output=True)
 assert check.returncode==0 and app.returncode==0,(check.stderr,app.stderr)
 assert (d/base.name).read_bytes()==yml.read_bytes()
 assert (d/annex.name).read_bytes()==annex.read_bytes()
raw={'expectedHashes':{k:{'path':str(p),'sha256':sha(p),'matches':sha(p)==h} for k,(h,p) in expected.items()},'validator':{'packageVersion':openapi_spec_validator.__version__,'offlineSchemaSha256':sha(tooldeps/'openapi_spec_validator/resources/schemas/v3.1/schema.json'),'metaErrors':meta,'fullErrors':full,'negatives':neg},'patch':{'checkExit':check.returncode,'applyExit':app.returncode,'yamlByteEqual':True,'annexByteEqual':True},'operations':rows,'preservation':{'paths':len(a['paths']),'sharedSchemas':True,'sharedParameters':True,'sharedHeaders':True,'sharedSecuritySchemes':True,'oldRequestSuccessAndErrorResponses':True,'demandSha256':sha(demand)},'policyMutants':policy_mutants,'refs':{'encounters':len(refs),'unique':len(set(refs))},'examples':{'checks':len(example_checks),'uniqueValues':len(set(x['valueSha256'] for x in example_checks)),'uniqueOperationStatusName':len(set((x['operation'],x['status'],x['name']) for x in example_checks))}}
(work/'raw-results.json').write_text(json.dumps(raw,indent=2,ensure_ascii=False)+'\n')
(work/'operation-matrix.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'metaErrors':len(meta),'fullErrors':len(full),'negatives':neg,'operations':len(rows),'exampleChecks':len(example_checks),'uniqueValues':raw['examples']['uniqueValues'],'refEncounters':len(refs),'uniqueRefs':len(set(refs))},indent=2))
